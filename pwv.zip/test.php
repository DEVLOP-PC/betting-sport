<?php


$string ="";


?>