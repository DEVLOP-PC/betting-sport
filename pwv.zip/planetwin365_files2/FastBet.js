﻿// Stringa in cui vengono memorizzati i tasti durante la digitazione
var strTmp = "";
var timeoutFastBet = -1;

function getTQ() {
    //Chiamata al webservice che restituisce i dati per il codPub
    if (typeof  bFastBetRaggruppaOverUnder != 'undefined') {
        ISBets.WebPages.Controls.FastBetWS.GetTQRaggruppaOverUnder($('#txtCodPub').val(), $('#hCodConf').val(), OnFBWSRequestComplete);
    } else {
        ISBets.WebPages.Controls.FastBetWS.GetTQ($('#txtCodPub').val(), $('#hCodConf').val(), OnFBWSRequestComplete);
    }
}

function ClearStrTmp() {
    strTmp = "";
}

//Viene chiamata al termine della chiamata asincrona al webservice che restituisce i dati
function OnFBWSRequestComplete(results) {
    var cboTQ = $get("cboTQ");
    if (cboTQ == null) return;
    //Reset dellla cbo
    while (cboTQ.hasChildNodes()) {
        cboTQ.removeChild(cboTQ.firstChild);
    }
    var optBlank = document.createElement("option");
    optBlank.value = "-1|";
    cboTQ.appendChild(optBlank);
    
    if (results != null) {
        $("#FSdivSE").html(results.SE);

        var lunghezzaMax=0
        for (var i = 0; i < results.CQ.length; i++) {
            // Creazione gruppi per CQ
            var grpOpt = document.createElement("optgroup");
            grpOpt.label = results.CQ[i].CQ;

            // Creazione elementi per TQ
            for (var x = 0; x < results.CQ[i].TQ.length; x++) {
                var optTQ = document.createElement("option");
                var lung = results.CQ[i].TQ[x].CodCB.length;
                if (lung>lunghezzaMax) {lunghezzaMax=lung;}
                optTQ.value = results.CQ[i].TQ[x].IDTQ + "|" + results.CQ[i].TQ[x].CodCB + "|" + results.CQ[i].TQ[x].IDQuota;
                optTQ.appendChild(document.createTextNode(results.CQ[i].TQ[x].TQ));

                grpOpt.appendChild(optTQ);
            }
            cboTQ.appendChild(grpOpt);
        }
        $("#hLengthMax").val(lunghezzaMax);
        $('#cboTQ').focus();
        $('#txtCodPub').blur();
    } else {
        $("#hLengthMax").val(0);
        $("#FSdivSE").html("")
        $('#txtCodPub').focus();
    }
}
$(document).ready(function () {
 
    $('#txtCodPub').keyup(function(e) {
        // Quando sono stati digitati tutti e 4 le cifre chiamo il ws
        if (this.value.length == 4) { getTQ() };

    });

    $('#txtCodPub').focus(function(e) {
        var cboTQ = $get("cboTQ");
        if (cboTQ != null) {
            //Reset dellla cbo
            while (cboTQ.hasChildNodes()) {
                cboTQ.removeChild(cboTQ.firstChild);
            }
        }
        $("#FSdivSE").html("")
        this.value = "";
    });

    $('#txtCodPub').keypress(function(e) {
        //Click su spazio, mi sposto su importo
        if (e.which == 32) {
            __defaultFired = false;

            SetFocusImporto();

            return false;
        }

        //Se clicca invio e textbox vuota sposto il fuoco sull'importo della multipla
        if (e.which == 13) {
            __defaultFired = false;

            //Se è presnete la txtBox per inserire la uid sono loggato come agente per cui mi sposto li
            var objTxtUtente = $get(sTxtUtente);
            if (objTxtUtente != null)
                objTxtUtente.focus();
            else

            //Altrimenti sposto il fuoco sull'importo attivo per la scommessa
                SetFocusImporto();

            return false;
        }
    });

    $('#cboTQ').keydown(function (e) {
        if (e.which == 13) {
            SendToCoupon();
            return;
        }
    });

    //Nel caso in cui l'utente digiti Invio sull combo, aggiungo al coupon la quota
    $('#cboTQ').keyup(function (e) {

        if (e.which == 13) {
            return;
        }

        //Altri Caratteri speciali, non faccio nulla
        if (e.which < 48) return;

        //il codice dei numeri del keypad vanno da 96 a 105 (+48)
        if ((e.which > 95) && (e.which < 106)) {
            strTmp += String.fromCharCode(e.which - 48);
        } else {
            //il codice dei simboli del keypad (106-111) vanno diminuti invece di 64...
            if ((e.which > 105) && (e.which < 112)) {
                strTmp += String.fromCharCode(e.which - 64);
            } else {
                strTmp += String.fromCharCode(e.which);
            }
        }

        var lengthMax = $('#hLengthMax').val()
        var trovato = 0;
        if ((strTmp.length > 0) && (strTmp.length <= lengthMax)) {
            $('#cboTQ option').each(function(i) {
                var valoreCbo = $(this).val();
                var codCB = valoreCbo.split("|")[1];
                if (codCB == strTmp.toLowerCase()) {
                    $('#cboTQ').val(valoreCbo);
                    trovato = 1;
                    return;
                }
            });
        }

        //se non trovato nessun codice seleziono sempre il valore vuoto
       // if (trovato == 0) $('#cboTQ').val("-1|");

        //Codice completo, pulisco la stringa temporanea
        if (strTmp.length == lengthMax) {
            ClearStrTmp();
        } else {
            clearTimeout(timeoutFastBet);
            timeoutFastBet = setTimeout(ClearStrTmp, 600);
        }
        //console.log('lengthMax:' + lengthMax);
        //console.log('strTmp:' + strTmp);
    });
});

function SendToCoupon() {
    var TQ = $("#cboTQ option:selected").val();
    var IDTQ = TQ.split("|")[0];
    var IDQuota = TQ.split("|")[2];
    var CodPub = $('#txtCodPub').val();
    AddCoupon(sAsyncQBButtonAddClientID, sAsyncQBTextClientID, IDTQ + '|' + CodPub + '|' + '0' + '|' + IDQuota);

    setTimeout(function() {
        $('#txtCodPub').val("");
        $('#txtCodPub').focus();
    }, 100);
}

