﻿
function treeCheckAll(chk) {
    $('#menuSports :checkbox').attr('checked', chk.checked);
}


function TVCheckedHandler() {
    var checkedNodes = $('#menuSports .chkEvento:checked');

    if (checkedNodes.length > TVClientLimiteCampionati) {
        alert(TVClientLimiteCampionatiErr)
    } else {
        if (typeof (sTxtEventi) != "undefined") {
            ShowEvents(sTxtEventi, sBtnLoadEventi, checkedNodes);
        } else {
            GoTV(0);
        }
    }
    return false;
}


//GESTIONE QUOTE ASYNC
function ShowEventAsync(txtID, IDEvento, showGQ, showDate, IDGruppoQuota, IDTipoEvento, GruppiSep, mainDiv) {
    var txt = document.getElementById(txtID);
    var IDRiquadro;
    var IDmainDiv

    if (typeof (mainDiv) == "undefined") {
        IDmainDiv = "#divMainEvents"
    } else {
        IDmainDiv = "#" + mainDiv
    }

    //Prima di aggiungere l'IDEvento verifico che non sia già presente
    if (GruppiSep == 1) {
        IDRiquadro = IDEvento + 'G' + IDGruppoQuota
    } else {
        IDRiquadro = IDEvento
    }

    if (txt.value != "") {
        var IDs = new Array();
        IDs = txt.value.split(",");
        for (i = 0; i < IDs.length; i++) {
            if (IDs[i] == IDEvento) {
                //Se lo trovo rimuovo la selezione
                IDs.splice(i, 1);

                txt.value = IDs.join(",");
                if (IDTipoEvento == 10) {
                    $('#riqEL' + IDRiquadro).remove();
                    $.event.trigger('oddsAsyncRemoved', IDEvento);
                }
                else {
                    $('#riqE' + IDRiquadro).remove();
                    $.event.trigger('oddsAsyncRemoved', IDEvento);
                }
                if ($(IDmainDiv).children().length == 0) { ShowHideOddsMsg(txtID); }
                return
            }
        }

        var strIDEventoOld = txt.value
        txt.value = IDEvento + "," + strIDEventoOld;
    } else {
        txt.value = IDEvento;
    }

    //Seleziona la check
    //if (node != null) node.Check();

    if (IDGruppoQuota == null) {
        LoadEventAsync(IDEvento, null, txtID, showGQ, showDate, IDTipoEvento, GruppiSep, mainDiv);
    } else {
        LoadEventAsyncConIDGQ(IDEvento, IDGruppoQuota, txtID, showGQ, showDate, IDTipoEvento, GruppiSep, mainDiv);
    }
}
//aggiorna dati per evento e gruppoquota
function LoadEventAsyncConIDGQ(IDEvento, IDGruppoQuota, txtID, showGQ, showDate, IDTipoEvento, GruppiSep, mainDiv) {
    var objUpdate = '#' + sUpdateProgress;

    var IDmainDiv
    if (typeof (mainDiv) == "undefined") {
        IDmainDiv = "#divMainEvents"
    } else {
        IDmainDiv = "#" + mainDiv
    }

    //Se il parametro showGQ o showDate non vengono passati default = 1
    if (showGQ == null) showGQ = 1;
    if (showDate == null) showDate = 1;

    try {

        $(objUpdate).show();

        var srnd = String(Math.random())
        srnd = srnd.replace(".", "").replace(",", "");

        //Se il tipo evento è LIve devo utilizzare una pagina differete
        var nomePagina;
        if (IDTipoEvento == 10)
            nomePagina = "OddsEventLive";
        else
            nomePagina = "OddsEvent";

        $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&IDGruppoQuota=' + IDGruppoQuota + '&GroupSep=' + GruppiSep, function (data) { $(IDmainDiv).prepend(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); });

    } catch (ex) {
        $(objUpdate).hide();
    }
}
//aggiorna dati per evento e gruppoquota
function LoadEventAsync(IDEvento, IDGruppoQuota, txtID, showGQ, showDate, IDTipoEvento, GruppiSep, mainDiv) {
    var IDmainDiv
    if (typeof (mainDiv) == "undefined") {
        IDmainDiv = "#divMainEvents"
    } else {
        IDmainDiv = "#" + mainDiv
    }

    var objUpdate = '#' + sUpdateProgress;
    //Se il parametro showGQ o showDate non vengono passati default = 1
    if (showGQ == null) showGQ = 1;
    if (showDate == null) showDate = 1;

    try {
        $(objUpdate).show();

        var srnd = String(Math.random())
        srnd = srnd.replace(".", "").replace(",", "");

        //Se il tipo evento è LIve devo utilizzare una pagina differete
        var nomePagina;
        var nomeRiquadro = "riqE"
        if (IDTipoEvento == 10) {
            nomePagina = "OddsEventLive";
            nomeRiquadro = "riqEL"
        } else {
            nomePagina = "OddsEvent";
            nomeRiquadro = "riqE"
        }

        if (IDGruppoQuota == null) {
            $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&GroupSep=' + GruppiSep, function (data) { $(IDmainDiv).prepend(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); $.event.trigger('oddsAsyncAdded', IDEvento); });
        } else {
            //Verifico se ho chiesto il cambio gruppo quota di un evento live
            if (GruppiSep == 1) {
                if (document.getElementById(nomeRiquadro + IDEvento + 'G' + IDGruppoQuota) == null) return;
                $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&IDGruppoQuota=' + IDGruppoQuota + '&GroupSep=' + GruppiSep, function (data) { $('#' + nomeRiquadro + IDEvento + 'G' + IDGruppoQuota).replaceWith(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); $.event.trigger('oddsAsyncAdded', IDEvento); });

            } else {
                if (document.getElementById(nomeRiquadro + IDEvento) == null) return;
                $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&IDGruppoQuota=' + IDGruppoQuota + '&GroupSep=' + GruppiSep, function (data) {

                    addGQ(data, nomeRiquadro + IDEvento, IDGruppoQuota);

                    selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide();

                });
            }
        }
    } catch (ex) {
        $(objUpdate).hide();
    }
}

function addGQ(data, parentID, IDGruppoQuota) {

    if ($('#' + parentID + ' #riqGQ' + IDGruppoQuota).length > 0) {

        if ($('#' + parentID).children(".divQta").length == 1) {
            return;
        } else {
            $('#' + parentID + ' #riqGQ' + IDGruppoQuota).remove();

            $('#' + parentID + ' .divBtn' + ' #puls' + IDGruppoQuota).attr('class', 'OddsDetailsMenuItem');
            //default gruppiquota chiusi (invertire logica in CSS)
            // $('#' + parentID + ' .divBtn' + ' #puls' + IDGruppoQuota).show();
            if (($('#' + parentID + ' .divBtn .divBtnMaster').hasClass("sel"))) {$('#' + parentID + ' .divBtn' + ' #puls' + IDGruppoQuota).hide(); }
        }
    } else {
        $('#' + parentID + ' .clear').after('<div class="divQta" id="riqGQ' + IDGruppoQuota + '">' + $(data).find('.divQta').html() + "</div>");
        $('#' + parentID + ' .divBtn' + ' #puls' + IDGruppoQuota).attr('class', 'OddsDetailsMenuSelected');
    }
}


//Verifico il parametro che abilita il linkFB
function ShowLinkFB() {
    if (typeof (showLinkCodPub) == "undefined") {
        return 0;
    } else {
        return showLinkCodPub;
    }
}


function FirstLoadEventAsync(IDEvento, txtID, showGQ, showDate, IDTipoEvento, GruppiSep) {
    $.event.trigger('oddsAsyncAdded', IDEvento);
    var objUpdate = '#' + sUpdateProgress;

    //Se il parametro showGQ o showDate non vengono passati default = 1
    if (showGQ == null) showGQ = 1;
    if (showDate == null) showDate = 1;

    try {

        $(objUpdate).show();

        var srnd = String(Math.random())
        srnd = srnd.replace(".", "").replace(",", "");

        //Se il tipo evento è LIve devo utilizzare una pagina differete
        var nomePagina;
        if (IDTipoEvento == 10)
            nomePagina = "OddsEventLive";
        else
            nomePagina = "OddsEvent";

        //$.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&GroupSep=' + GruppiSep, function (data) { $('#divMainEvents').append(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); });

        if ($('#' + sTxtEventiIDGruppoQuota).val() != '') {
            $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&IDGruppoQuota=' + $('#' + sTxtEventiIDGruppoQuota).val() + '&GroupSep=' + GruppiSep, function (data) { $('#divMainEvents').append(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); });
        } else {
            $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&GroupSep=' + GruppiSep, function (data) { $('#divMainEvents').append(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); });
        }



    } catch (ex) {
        $(objUpdate).hide();
    }
}


function RefreshEventAsync(IDEvento, IDGruppoQuota, txtID, showGQ, showDate, IDTipoEvento, GruppiSep) {
    var srnd = String(Math.random())
    srnd = srnd.replace(".", "").replace(",", "");

    //Se il tipo evento è LIve devo utilizzare una pagina differete
    var nomePagina;
    var nomeRiquadro = "riqE"
    if (IDTipoEvento == 10) {
        nomePagina = "OddsEventLive";
        nomeRiquadro = "riqEL"
    } else {
        nomePagina = "OddsEvent";
        nomeRiquadro = "riqE"
    }
    var objUpdate = '#' + sUpdateProgress;

    //Se il parametro showGQ o showDate non vengono passati default = 1
    if (showGQ == null) showGQ = 1;
    if (showDate == null) showDate = 1;


    try {
        $(objUpdate).show();

        if (GruppiSep == 1) {
            $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&IDGruppoQuota=' + IDGruppoQuota + '&GroupSep=' + GruppiSep, function (data) { $('#' + nomeRiquadro + IDEvento + 'G' + IDGruppoQuota).replaceWith(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); });
        } else {
            $.get('../ControlsSkin/' + nomePagina + '.aspx?ShowLinkFastBet=' + ShowLinkFB() + '&showDate=' + showDate + '&showGQ=' + showGQ + '&rnd=' + srnd + '&EventID=' + IDEvento + '&IDGruppoQuota=' + IDGruppoQuota + '&GroupSep=' + GruppiSep, function (data) { $('#' + nomeRiquadro + IDEvento).replaceWith(data); selezionaQuote(); ShowHideOddsMsg(txtID); $(objUpdate).hide(); });

        }

    } catch (ex) {
        $(objUpdate).hide();
    }
}

//Visualizza/Nasconde il messaggio di errore e giocabilità
function ShowHideOddsMsg(txtID) {
    var txt = document.getElementById(txtID);

    if (txt.value == '') {
        $('#oddsAsyncMsg_Empty').show();
        $('#oddsAsyncLgnd').hide();
        return;
    } else {
        var IDs = new Array();
        IDs = txt.value.split(",");
        if (IDs.length > LimiteEventiVisualizzabili) {
            $('#oddsAsyncMsg_Many').show();
            $('#oddsAsyncLgnd').hide();
            return;
        }
    }
    $('#oddsAsyncMsg_Empty').hide();
    $('#oddsAsyncMsg_Many').hide();
    $('#oddsAsyncLgnd').show();
}

function setFBCode(codiceFB) {
    //Imposto il codicepub cliccato nella textbox
    $("#txtCodPub").val(codiceFB);

    //Chiamata al ws che compila la dropdown
    getTQ();
}

function CloseBoxOdds(IDE) {
    var tree = null

    //deseleziono l'eventuale checkbox dalla TreeView
    var nodoTV = $('#menuSports #chke' + IDE + '.chkEvento:checked ');
    if (nodoTV.attr('checked') == true) { nodoTV.attr('checked', false) }

    $.event.trigger('oddsAsyncRemoved', IDE);

    //nascondo quota    
    ShowEventAsync(sTxtEventi, IDE);
}

function ExpandOddsGroup(EventID, divClick) {
    $(".divBtn." + EventID).find(".OddsDetailsMenuItem").toggle();
    $(divClick).toggleClass("sel");
}

function SelOddsDet(IDQuota) {
    $('.SETQCon #div_' + IDQuota).toggleClass('sel')
}


function showEventDett(IDEvento, IDGruppoQuota, IDTipoEvento, divClicked) {
    var objUpdate = '#' + sUpdateProgress;

    if ($('#oddDet' + IDEvento).length > 0) {
        $('#oddDet' + IDEvento).remove();
        $(divClicked).removeClass("sel");
    } else {
        var srnd = String(Math.random())
        srnd = srnd.replace(".", "").replace(",", "");
        $(objUpdate).show();
        $.get('../ControlsSkin/OddsSubEvent.aspx?SubEventID=' + IDEvento + '&IDGruppoQuota=' + IDGruppoQuota + '&btnID=s_w_PC_cCoupon_btnAddCoupon&txtID=s_w_PC_cCoupon_txtIDQuota&rnd=' + srnd, function (data) {
            var colspan = $(divClicked).parent().parent().children().length
            var css = $(divClicked).parent().parent().attr("class")
            $('<tr class="' + css + ' dett" id="oddDet' + IDEvento + '" data-idtipoevento="' + IDTipoEvento + '"><td colspan="' + colspan + '">' + data + '</td></tr>').insertAfter($(divClicked).parent().parent());
            $(objUpdate).hide();
            $(divClicked).addClass("sel");
            selezionaQuoteDettaglio();
        });
    }
}

function openEventPerc(divclick, strValues, strMsg) {

    var arrVal = strValues.split(",");
    var arrNewVal = [];
    var arrHeader = [];
    var strOut = ""

    var sumOdds = 0;

    $.each(arrVal, function (index, value) {
        var element = $(divclick).parent().parent().siblings('.OddsDetailsQuote').find('.oddsQ').eq(index).find('a');
        if (element.length > 0) {
            //var header = $(divclick).parent().parent().parent().siblings('.dgHeader').find(".OddsQuotaHeaderStyle TD[class*='qtTbl']").eq(index);
            var header = $(divclick).parents('.divQt').find('.dgHeader').find(".OddsQuotaHeaderStyle TD[class*='qtTbl']").eq(index);
            sumOdds += 100 / getNumberFromString(element.html());
            arrHeader[index] = header.html();
            arrNewVal[index] = 100 / getNumberFromString(element.html());
        }
    });

    strOut = '<div class="oddsToolTip"><span>' + strMsg + '</span>'

    $.each(arrNewVal, function (index, value) {
        if (typeof (arrHeader[index]) != "undefined" && typeof (value) != "undefined") {
            strOut += "<div>" + "<span>" + arrHeader[index] + "</span>" + "<div class='graphCnt'><div class='graph' style='width:" + value + "%;'></div></div>" + (Math.round(100 / sumOdds * value)) + "%</div>"
        }
    });

    strOut += "</div>"

    $(divclick).parent().append(strOut)
}

function cancelEventPerc() { $(".oddsToolTip").remove(); }

function selezionaQuoteLessThan() {
    if ($('#oddsLessThanContent').length == 0) return;

    var objHidQuote = document.getElementById(sHidIDQuote);
    if (objHidQuote == null) return;
    var quote = objHidQuote.value.split("|");
    $('#oddsLessThanContent .odd').removeClass("sel");

    for (var i = 0; i < quote.length; i++) {
        var IDQuota = quote[i].split("&")[0];
        $('#oddsLessThanContent .odd[onclick*="' + IDQuota + '"]').addClass("sel")
    }
}

function selezionaQuoteLastMinute() {
    if ($('#LastMinutePage').length == 0) return;

    var objHidQuote = document.getElementById(sHidIDQuote);
    if (objHidQuote == null) return;
    var quote = objHidQuote.value.split("|");
    $('#LastMinutePage .odd').removeClass("sel");

    for (var i = 0; i < quote.length; i++) {
        var IDQuota = quote[i].split("&")[0];
        $('#LastMinutePage .odd[onclick*="' + IDQuota + '"]').addClass("sel")
    }
}