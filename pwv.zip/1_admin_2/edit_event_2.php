<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$score = $_POST['score'];
$status = $_POST['status'];
$eventId = $_POST['eventId'];
$players = $_POST['players'];
$signe = $_POST['signe'];
$codepub = $_POST['codepub'];
$timestamp = $_POST['timestamp'];

if($status == 3){
    $score = "void";
}

$signe = str_replace(array("&"), "&amp;", $signe);

$currentPage = $_POST['currentPage'];

mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE id = ".intval($eventId) );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE id = ". intval($eventId) );

//echo "UPDATE events SET status = '$status' WHERE id = ". intval($eventId);

/*mysqli_query($dbhandle, "UPDATE events SET score = '$score'  WHERE players = '".$players."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE players = '".$players."' AND signe = '".$signe."'" );*/

//mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );


//$uid = intval($_SESSION['pw_logged_user_admin']);
//
//mysqli_query($dbhandle, "UPDATE be_user SET nb_corr_jour = nb_corr_jour+1 WHERE id = '".$uid."'" );
//mysqli_query($dbhandle, "UPDATE be_user SET nb_corr_tot = nb_corr_tot+1 WHERE id = '".$uid."'" );


header("Location:index.php?page=".$currentPage);

?>