<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$couponDbId = $_GET['couponId'];

if(isset($_GET['page'])){
    $pageActuelle=intval($_GET['page']);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin - Paris</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="wrapper">

    <!-- Sidebar -->
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand" style="color: #ffffff;">
                Bonjour Mr. <?php echo $row['prenom'];?> <?php echo $row['nom'];?>
            </li>
            <li>
                <a href="index.php">Mise à jour events</a>
            </li>
            <?php if($row['type'] > 1){?>
                <li>
                    <a href="correction-events.php">Correction evenement</a>
                </li>
                <?php if($row['type'] > 2){?>
                    <li>
                        <a href="list-coupons.php">Mise à jour coupons</a>
                    </li>
                    <li>
                        <a href="correction-coupons.php">Correction coupons</a>
                    </li>
                <?php }}?>
            <li>&nbsp;</li>
            <li>
                <a href="logout.php">Déconnexion</a>
            </li>
        </ul>
        <br><br><br>
        <?php if($row['type'] > 2){?>
            <h4 style="color: #fff; padding-left: 10px;">Statistiques</h4>
            <table style="color: #ffffff; margin-left: 10px" width="100%">
                <tr>
                    <th width="50%">User</th>
                    <th width="25%">Today</th>
                    <th width="25%">All</th>
                </tr>
                <?php
                $resStat = mysqli_query($dbhandle, "SELECT * FROM be_user order by nb_corr_jour desc");
                while($rowStat = mysqli_fetch_assoc($resStat)){
                    ?>
                    <tr>
                        <td width="50%" style="<?php if($rowStat['id'] == $row['id']) echo 'color: #c7254e; font-weight: bold;';?>"><?php echo $rowStat['prenom']?></td>
                        <td width="25%" style="<?php if($rowStat['id'] == $row['id']) echo 'color: #c7254e; font-weight: bold;';?>"><?php echo $rowStat['nb_corr_jour']?></td>
                        <td width="25%" style="<?php if($rowStat['id'] == $row['id']) echo 'color: #c7254e; font-weight: bold;';?>"><?php echo $rowStat['nb_corr_tot']?></td>
                    </tr>
                <?php }?>
            </table>
        <?php }?>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Pari events</h1>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Event</th>
                            <th>Players</th>
                            <th>Date</th>
                            <th>Signe</th>
                            <th>Cote</th>
                            <th>Score</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php

                        $gidCoupon = mysqli_query($dbhandle, "SELECT * FROM coupon WHERE id = '$couponDbId'");
                        $rowCoupon = mysqli_fetch_assoc($gidCoupon);

                        $identificateur = $rowCoupon['usager'];
                        $gidUsager = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
                        $rowUsager = mysqli_fetch_assoc($gidUsager);

//                        $sqlIntgOcEvents = "SELECT * FROM events WHERE id IN (SELECT id_foreign FROM coupon_events WHERE id_local='$couponDbId') order by codepub";
                        $sqlIntgOcEvents = "SELECT e.* FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId' order by codepub";
                        $resIntgOcEvents = mysqli_query($dbhandle, $sqlIntgOcEvents) or die(mysqli_error($dbhandle));
                        if(mysqli_num_rows ($resIntgOcEvents) > 0){
                            while($rowIntgOcEvents = mysqli_fetch_assoc($resIntgOcEvents)){
                                ?>
                                <tr>
                                    <form action="edit_event.php" method="post">
                                        <td><?php echo $rowIntgOcEvents['event']; ?></td>
                                        <td><?php echo $rowIntgOcEvents['players']; ?></td>
                                        <td><?php
                                            $date = new DateTime();
                                            $date->setTimestamp($rowIntgOcEvents['timestamp']);
                                            echo $date->format('Y-m-d H:i:s');
                                            ?>
                                        </td>
                                        <td><?php echo $rowIntgOcEvents['signe']; ?></td>
                                        <td><?php echo $rowIntgOcEvents['cote']; ?></td>
                                        <td><?php echo $rowIntgOcEvents['score']; ?></td>
                                        <td>
                                            <?php
                                            if($rowIntgOcEvents['status'] == 1){
                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif";
                                            }if($rowIntgOcEvents['status'] == 2){
                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif";
                                            }if($rowIntgOcEvents['status'] == 0){
                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_0.gif";
                                            }if($rowIntgOcEvents['status'] == 3){
                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_4.gif";
                                            }
                                            ?>
                                            <img src="<?php echo $imgSrc; ?>" style="border-width:0px;">
                                        </td>
                                    </form>
                                </tr>

                                <?php
                            }}?>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr style="width: 100%; color: black; height: 1px; background-color:black;" />
            <div class="row">
                <div class="col-lg-12">
                    <div class="container">
                        <ul class="list-unstyled">
                            <li class="col-md-2 odd">Code coupon</li>
                            <li class="col-md-10 odd"><?php echo $rowCoupon['code_coupon'];?></li>
                            <li class="col-md-2 even">État du pari</li>
                            <li class="col-md-10 even"><?php echo $rowCoupon['etat_pari'];?></li>
                            <li class="col-md-2 odd">Usager</li>
                            <li class="col-md-10 odd"><?php echo $rowUsager['identificateur']." ".$rowUsager['prenom']." ".$rowUsager['nom'];?></li>
                            <li class="col-md-2 odd">Date</li>
                            <li class="col-md-10 odd">
                                <?php
                                $timestamp = strtotime($rowCoupon['date']);
                                $date = new DateTime();
                                $date->setTimestamp($timestamp);
                                echo $date->format('d/m/Y H:i:s');
                                ?>
                            </li>
                            <li class="col-md-2 odd">Type de pari</li>
                            <li class="col-md-10 odd"><?php echo $rowCoupon['type_pari'];?></li>
                            <li class="col-md-2 odd">Montant joué</li>
                            <li class="col-md-10 odd">
                                <?php if($rowCoupon['type_pari']=="intégrale"){?>
								<?php echo number_format($rowCoupon['amount']/$rowCoupon['multiplicateur'], 2, ',', '');?> x <?php echo $rowCoupon['multiplicateur'];?> = <?php echo number_format($rowCoupon['amount'], 2, ',', '');?>&nbsp;&euro;</span>
                                <?php }?>
                                <?php if($rowCoupon['type_pari']=="multiple"){?>
								<?php echo $rowCoupon['amount'];?>&nbsp;&euro;</span>
                                <?php }?>
                            </li>
                            <li class="col-md-2 odd">Bonus</li>
                            <li class="col-md-10 odd">
                                <?php if($rowCoupon['type_pari']=="intégrale"){?>
                                <?php echo $rowCoupon['bonus_min'];?> / <?php echo $rowCoupon['bonus_max'];?>&nbsp;€&nbsp;
                                <?php }?>
                                <?php if($rowCoupon['type_pari']=="multiple"){?>
                                <?php echo $rowCoupon['bonus'];?>&nbsp;&euro;</span>
                                <?php }?>
                            </li>
                            <li class="col-md-2 odd">Gain Pot. Min/Max Pot.</li>
                            <li class="col-md-10 odd">
                                <?php if($rowCoupon['type_pari']=="intégrale"){?>
                                <?php echo $rowCoupon['gain_pot_min'];?> / <?php echo $rowCoupon['gain_pot_max'];?>&nbsp;€
                                <?php }?>
                                <?php if($rowCoupon['type_pari']=="multiple"){?>
                                <?php echo $rowCoupon['gain_pot'];?>&nbsp;&euro;</span>
                                <?php }?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <hr  />
            <div class="row">
                <div class="col-lg-12">
                    <form method="post" action="update-coupon.php" id="editform">
                        <input type="hidden" value="<?php echo $rowCoupon['code_coupon'];?>" name="codeCoupon" />
                        <input type="hidden" value="<?php echo $couponDbId;?>" name="coupondbid" />
                        <input type="hidden" value="<?php echo $rowUsager['id'];?>" name="usagerdbid" />
                        <input type="hidden" value="" name="status" id="status" />
                        <input type="hidden" name="currentPage" value="<?php echo $pageActuelle;?>" />
                        <div class="col-xs-2">
                        <label for="ex1">Gain</label>
                        <input class="form-control" id="ex1" type="text" name="gain" />
                    </div>
                    <div class="col-md-2"><label for="ex1">&nbsp;</label>
                        <input style="submit" class="btn btn-success btn-large btn-block" value="Gagnant" id="win" />
                    </div>
                    <div class="col-md-2"><label for="ex1">&nbsp;</label>
                        <input style="submit" class="btn btn-danger btn-large btn-block" value="Perdant" id="lost" />
                    </div>
                    <div class="col-md-2"><label for="ex1">&nbsp;</label>
                        <input style="submit" class="btn btn-warning btn-large btn-block" value="En cours" id="running" />
                    </div>
                    <div class="col-md-6"></div>
                    </form>
                </div>
            </div>
            <div class="row" style="min-height: 200px;">
                <div class="col-lg-12">
                    &nbsp;
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Menu Toggle Script -->
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

    $("#win").click(function(e) {
        e.preventDefault();
        $("#status").val("win");
        $("#editform").submit();
    });

    $("#lost").click(function(e) {
        e.preventDefault();
        $("#status").val("lost");
        $("#editform").submit();
    });

    $("#running").click(function(e) {
        e.preventDefault();
        $("#status").val("running");
        $("#editform").submit();
    });
</script>

</body>