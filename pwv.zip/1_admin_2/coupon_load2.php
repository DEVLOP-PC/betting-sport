<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:login.php");
}
require_once __DIR__ . '/parser/vendor/autoload.php';

require 'parser/vendor/autoload.php';

use PHPHtmlParser\Dom;

include('parser/includes/ganon.php');
include('db_connect.php');

$url = 'http://ww3.365planetwinall.net/Sport/default.aspx';
$fields = array(
    'h$w$PC$cCoupon$txtCouponCodiceAnonimo' => $_POST['codecoupon'],
    '__EVENTTARGET' => 'h$w$PC$cCoupon$lnkCaricaCouponCodiceAnonimo',

);

$cookies = "ISBets_CurrentCulture=11";

$fields_string = "";

foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
rtrim($fields_string, '&');

$ch = curl_init();

$agent = "Mozilla/5.0 (X11; U; Linux i686; en-US) 
            AppleWebKit/532.4 (KHTML, like Gecko) 
            Chrome/4.0.233.0 Safari/532.4";
$referer = "http://www.google.com/";

curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_POST, count($fields));
curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIE, $cookies);
curl_setopt($ch, CURLOPT_REFERER, $referer);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
//curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
$result = curl_exec($ch);
curl_close($ch);




preg_match('`<div id="h_w_PC_cCoupon_atlasCoupon">(.*?)</div>`Uis', $result, $match);

$pos = strpos($match[0], "h_w_PC_cCoupon_btnStampaSco");

if($pos == false){
    $coupon_html = $match[0];

    preg_match('`<div id="h_w_PC_cCoupon_divTipoSco" class="divCpnTipi">(.*?)</div>`Uis', $coupon_html, $coupon_form);

    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$coupon_html);

    $divs = $doc->getElementsByTagName('div');
    $coupon_events = array();

    foreach ($divs as $div) {
        $classes = $div->getAttribute('class');
        if (strpos($classes, 'CItem te1') !== false) {

            $childs = $div->getElementsByTagName('div');

            foreach ($childs as $child) {
                $childClasses = $child->getAttribute('class');
                if (strpos($childClasses, 'CCodPub') !== false) {
                    $codepub = $child->nodeValue;
                }
            }

            foreach ($childs as $child) {
                $childClasses = $child->getAttribute('class');
                if (strpos($childClasses, 'CSubEv') !== false) {
                    $codePlayers = $child->nodeValue;
                }
            }

            $sql = "SELECT * FROM sub_events WHERE codepub = '".$codepub."'";
            $res = mysqli_query($dbhandle, $sql);
            $row = mysqli_fetch_assoc($res);

            if(mysqli_num_rows ($res) > 0) {
                if($row['status'] == 2){
                    $div->setAttribute ("data","wrong");
                }

            }else{
                $div->setAttribute ("data","wrong");
            }

            $coupon_events[] = $div->C14N();

        }
    }

    $amoutForm = $doc->getElementById('h_w_PC_cCoupon_divTipoSco')->C14N();

    if($doc->getElementById('h_w_PC_cCoupon_txtTotaleDI')){

        $_SESSION['type'] = "integrale";

        $_SESSION['amount'] = $doc->getElementById('h_w_PC_cCoupon_txtTotaleDI')->getAttribute('value');
        $_SESSION['gain_pot_min'] = $doc->getElementById('h_w_PC_cCoupon_lblVincitaPotMin')->nodeValue;
        $_SESSION['gain_pot_max'] = $doc->getElementById('h_w_PC_cCoupon_litVincitaPotDI')->nodeValue;
        $_SESSION['bonus_min'] = $doc->getElementById('h_w_PC_cCoupon_lblBonusMinDI')->nodeValue;
        $_SESSION['bonus_max'] = $doc->getElementById('h_w_PC_cCoupon_lblBonusMaxDI')->nodeValue;
        $_SESSION['multiplicateur'] = $doc->getElementById('h_w_PC_cCoupon_lblImportoDICombinazioni')->nodeValue;
        $_SESSION['cote_min'] = $doc->getElementById('h_w_PC_cCoupon_lblQuotaTotaleDIMin')->nodeValue;
        $_SESSION['cote_max'] = $doc->getElementById('h_w_PC_cCoupon_lblQuotaTotaleDIMax')->nodeValue;


    }else{

        $_SESSION['type'] = "multiple";

        $_SESSION['amount'] = $doc->getElementById('h_w_PC_cCoupon_txtImporto')->getAttribute('value');
        $_SESSION['gain_pot'] = $doc->getElementById('h_w_PC_cCoupon_litVincitaPot')->nodeValue;
        $_SESSION['bonus'] = $doc->getElementById('h_w_PC_cCoupon_litBonusNumScommesse')->nodeValue;
        $_SESSION['cote_tot'] = $doc->getElementById('h_w_PC_cCoupon_lblQuotaTotale')->nodeValue;

    }

    $_SESSION['coupon_content'] = $coupon_html;
    $_SESSION['amount_form'] = $amoutForm;
    $_SESSION['coupon_events'] = $coupon_events;
    header('Location: index.php');
}
else{
    header('Location: index.php?coupn-not-found');
}


?>