<?php
session_start();

require_once('db_connect.php');
require_once('includes/functions.php');

$eventDatas = array();
$eventData = array();

/*foreach($_SESSION['coupon_events'] as $event){

    $eventData["codepub"] = strip_tags(getNodeValueFromClass($event, "CCodPub"));
    $eventData["eventname"] = strip_tags(getNodeValueFromClass($event, "CEvento"));
    $eventData["players"] = strip_tags(getNodeValueFromClass($event, "CSubEv"));
    $signes = getSigne($event);
    $cotes = getCote($event);;

    if($eventData["eventname"] && $eventData["players"]){
        $codepub = $eventData["codepub"];
        $players = str_replace('  -  ',' - ', $eventData["players"]);

        $sqlParser = "select * from sub_events where codepub=".intval($codepub);
        $resParser = mysqli_query($dbhandle, $sqlParser)or die(mysqli_error($dbhandle));
        $rowParser = mysqli_fetch_assoc($resParser);

        $eventData["date"] = $rowParser['date'];
        $eventData["time"] = $rowParser['time'];
        $eventData["timestamp"] = $rowParser['timestamp'];
    }
	
	for($i=0;$i<sizeof($signes);$i++){
		$eventData["signe"] = str_replace("Segno:", "", strip_tags($signes[$i]));
		$eventData["cote"] = strip_tags($cotes[$i]);
		$eventDatas[] = $eventData;
	}
	
}*/

foreach($_SESSION['couponDataArr']['rows'] as $event){

    $eventData["codepub"] = strip_tags($event['codepub']);
    $eventData["eventname"] = strip_tags($event['event']);
    $eventData["players"] = strip_tags($event['players']);

    if($eventData["eventname"] && $eventData["players"]){
        $codepub = $eventData["codepub"];
        $players = str_replace('  -  ',' - ', $eventData["players"]);

        $sqlParser = "select * from sub_events where codepub=".intval($codepub);
        $resParser = mysqli_query($dbhandle, $sqlParser)or die(mysqli_error($dbhandle));
        $rowParser = mysqli_fetch_assoc($resParser);

        $eventData["date"] = $rowParser['date'];
        $eventData["time"] = $rowParser['time'];
        $eventData["timestamp"] = $rowParser['timestamp'];
    }

    foreach($event['cote'] as $coteRow){
        $eventData["signe"] = str_replace("Segno:", "", strip_tags($coteRow['signe']));
        $eventData["cote"] = strip_tags($coteRow['cote']);
        $eventDatas[] = $eventData;
    }

}

$eventsDbIds = array();

foreach($eventDatas as $data){
    $sql = "select id from events where players='".$data["players"]."' and event='".$data["eventname"]."'
     and date='".$data["date"]."' and  time='".$data["time"]."' and signe='".$data["signe"]."' and cote='".$data["cote"]."'";
    $res = mysqli_query($dbhandle, $sql);
    if(mysqli_num_rows ($res) > 0){
        $row = mysqli_fetch_assoc($res);
        $eventsDbIds[] = $row['id'];
    }else{
	    $sql = "INSERT INTO events (players, event, date, time, signe, cote, codepub, timestamp)
                VALUES ('".$data["players"]."', '".$data["eventname"]."', '".$data["date"]."', '".$data["time"]."', '".$data["signe"]."', '".$data["cote"]."', '".$data["codepub"]."', '".$data["timestamp"]."')";
        mysqli_query($dbhandle, $sql);
	    $eventsDbIds[] = mysqli_insert_id($dbhandle);
	}
}
if(empty($eventsDbIds)){
    header("Location:index.php");
}

$identificateur = $_SESSION['pw_logged_user'];

$gidUsager = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
$rowUsager = mysqli_fetch_assoc($gidUsager);

$codeCoupon = generateCouponId($dbhandle, $identificateur);
$usager = $identificateur;

date_default_timezone_set('Africa/Tunis');
$currentDateTime = date('Y-m-d H:i:s') ;

if($_SESSION['couponDataArr']['type'] == 'multiple'){
    $type= "multiple";
    $amount = stringToNumber($_SESSION['amount']);
    $gain_pot = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['gain_pot']));
    $bonus = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['bonus']));
    $cote_tot = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['cote_tot']));

    //query
    $sql = "INSERT INTO coupon (code_coupon,usager,date,type_pari,amount,bonus,gain_pot,cote_tot)
        VALUES ('$codeCoupon','$usager', '$currentDateTime','$type', '$amount','$bonus', '$gain_pot', '$cote_tot')";
}
if($_SESSION['couponDataArr']['type'] == 'integrale'){
    $type= "intégrale";
    $amount = stringToNumber($_SESSION['amount']);
    $gain_pot_min = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['gain_pot_min']));
    $gain_pot_max = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['gain_pot_max']));
    $bonus_min = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['bonus_min']));
    $bonus_max = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['bonus_max']));
    $multiplicateur = $_SESSION['multiplicateur'];
    $cote_min = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['cote_min']));
    $cote_max = stringToNumber(preg_replace("/[^0-9,.]/", "", $_SESSION['cote_max']));

    //query
    $sql = "INSERT INTO coupon (code_coupon,usager,date,type_pari,amount,bonus_min,bonus_max,gain_pot_min,gain_pot_max,multiplicateur,cote_min,cote_max)
        VALUES ('$codeCoupon', '$usager', '$currentDateTime', '$type', '$amount', '$bonus_min', '$bonus_max' ,'$gain_pot_min', '$gain_pot_max', '$multiplicateur', '$cote_min', '$cote_max')";

}

mysqli_query($dbhandle, $sql) or die(mysqli_error($dbhandle));
$couponDbId = mysqli_insert_id($dbhandle) or die(mysqli_error($dbhandle));;

foreach($eventsDbIds as $eventId){
    $sql = "INSERT INTO coupon_events (id_local,id_foreign)
        VALUES ('$couponDbId', '$eventId')";
    mysqli_query($dbhandle, $sql) or die(mysqli_error($dbhandle));
}

$newAmount = $rowUsager['solde'] - $amount;
mysqli_query($dbhandle, "UPDATE usager SET solde='$newAmount' WHERE identificateur = '$identificateur'");

//Transaction
$usagerDbId = $rowUsager['id'];
$sql = "INSERT INTO transaction (date, type, coupon, droit, solde, id_usager, id_coupon)
        VALUES ('$currentDateTime', 'pari', '$codeCoupon', '-$amount', '$newAmount', '$usagerDbId', '$couponDbId')";
mysqli_query($dbhandle, $sql) or die(mysqli_error($dbhandle));


//Print coupon
unset($_SESSION['coupon_content']);
unset($_SESSION['coupon_events']);

//Redirect to homepage
$_SESSION['coupon_to_print'] = $codeCoupon;
header("Location:index.php?coupon_ajoute=1");


//Functions

function getEventDateTime($eventName, $players){

    $url = 'http://ww3.365planetwinall.net/Sport/Groups.aspx?TipoVis=1';

	$agent = "Mozilla/5.0 (X11; U; Linux i686; en-US) 
            AppleWebKit/532.4 (KHTML, like Gecko) 
            Chrome/4.0.233.0 Safari/532.4";
  $referer = "http://www.google.com/";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_REFERER, $referer);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_COOKIE, "ISBets_CurrentCulture=11");
  curl_setopt($ch, CURLOPT_USERAGENT, $agent);
  
  $result = curl_exec($ch);
  curl_close($ch);

    $alldoc = new DOMDocument();
    @$alldoc->loadHTML('<?xml encoding="utf-8" ?>' .$result);

    $sportsList = $alldoc->getElementById('divMenuSportSX')->C14N();

    //$eventId = getEventId($sportsList, "England - Premier League");
    $eventId = getEventId($sportsList, $eventName);

    $url = 'http://ww3.365planetwinall.net/Sport/OddsAsync.aspx?EventID='.$eventId;
    $url2 = "http://ww3.365planetwinall.net/ControlsSkin/OddsEvent.aspx?ShowLinkFastBet=0&showDate=1&showGQ=1&rnd=05131459920667112&EventID=".$eventId."&GroupSep=undefined";



    $agent = "Mozilla/5.0 (X11; U; Linux i686; en-US) 
            AppleWebKit/532.4 (KHTML, like Gecko) 
            Chrome/4.0.233.0 Safari/532.4";
  $referer = "http://www.google.com/";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url2);
  curl_setopt($ch, CURLOPT_REFERER, $referer);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_COOKIE, "ISBets_CurrentCulture=11");
  curl_setopt($ch, CURLOPT_USERAGENT, $agent);
  
  $result = curl_exec($ch);
  curl_close($ch);
  

    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$result);

    $divs = $doc->getElementsByTagName('div');

    foreach ($divs as $div) {
        $classes = $div->getAttribute('data-event-id');
        if ($classes) {
            $eventsTablesDiv = $div->C14N();
        }
    }

    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$eventsTablesDiv);

    $divs = $doc->getElementsByTagName('div');

    foreach ($divs as $div) {
        $classes = $div->getAttribute('data-event-id');
        if ($classes) {
            $eventsTablesDiv = $div->C14N();
        }
    }

    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$eventsTablesDiv);

    $tables = $doc->getElementsByTagName('table');

	$found = 0;

    foreach ($tables as $table) {

        $docTable = new DOMDocument();
        @$docTable->loadHTML('<?xml encoding="utf-8" ?>' .$table->C14N());

        $tds = $docTable->getElementsByTagName('td');

		if($found == 0){
			//Date
			foreach ($tds as $td) {
				$classes = $td->getAttribute('class');
				if ($classes =='cqDateTbl') {
					$date = $td->C14N();
				}
			}
		}



        //Time
        $docTr = new DOMDocument();
        @$docTr->loadHTML('<?xml encoding="utf-8" ?>' .$table->C14N());


        $trs = $docTr->getElementsByTagName('tr');

        foreach ($trs as $tr) {
            $data_sottoevento_name = $tr->getAttribute('data-sottoevento-name');
            $data_sottoevento_name = str_replace(' ', '', $data_sottoevento_name);
            $players =  str_replace(' ', '', $players);

            if ($data_sottoevento_name == $players) {
                $test = explode(' ',strip_tags($tr->C14N()));
                $time = substr($test[0], 10, 5);
				$found = 1;
                $docTrTime = new DOMDocument();
                @$docTrTime->loadHTML('<?xml encoding="utf-8" ?>' .$table->C14N());
            }
        }
    }

    $dateTime = array();
    $dateTime["date"] = $date;
    $dateTime["time"] = $time;

    return $dateTime;

}

function getSigne($event){
	$doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$event);
	$divs = $doc->getElementsByTagName('div');

	$signes = array();
	foreach ($divs as $div) {
        $classes = $div->getAttribute('class');
        if (strpos($classes, 'COdds False') !== false) {
			$signes [] = getNodeValueFromClass($div->C14N(), "CSegno");
		}
	}
	return $signes;
}

function getCote($event){
	$doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$event);
	$divs = $doc->getElementsByTagName('div');

	$cotes = array();
	foreach ($divs as $div) {
        $classes = $div->getAttribute('class');
        if (strpos($classes, 'COdds False') !== false) {
			$cotes [] = getNodeValueFromClass($div->C14N(), "valQuota_");
		}
	}
	return $cotes;
}


function getEventId($sportsList, $eventName){
    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$sportsList);

    $links = $doc->getElementsByTagName('a');

    foreach ($links as $link) {
        $titles = $link->getAttribute('title');
        if($titles){
            if (strpos($eventName, $titles) > -1) {
                $linkHref = $link->getAttribute('href');
                $eventId = substr($linkHref, strpos($linkHref, "=") + 1);
            }
        }

    }

    return $eventId;
}

function generateCouponId($dbhandle, $identificateur) {
    $alphabet = "ABCDEFGHIJKLMNOPQRSTUWXYZABCDEFGHIJKLMNOPQRSTUWXYZABCDEFGHIJKLMNOPQRSTUWXYZABCDEFGHIJKLMNOPQRSTUWXYZ123456789";
    $pass = array(); //declare a array type variable
    $alphaLength = strlen($alphabet) - 1; //set alphaLength -1 to total alphabet
    //No take 5 charecter randomly one by one from alphabet
    for ($i = 0; $i < 9; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    // impload the Password array
    $pass = "P".date('i').implode($pass)."-".$identificateur; //turn the array into a string

    $sql = "select code_coupon from coupon where code_coupon='".$pass."'";
    $res = mysqli_query($dbhandle, $sql);
    if(mysqli_num_rows ($res) > 0){
        generateCouponId();
    }

    return $pass;
}

function getNodeValueFromClass($html, $class){
    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$html);
    $divs = $doc->getElementsByTagName('div');
    foreach ($divs as $div) {
        $classes = $div->getAttribute('class');
        if (strpos($classes, $class) !== false) {
            return $div->C14N();
        }
    }
}

function convertDate($date, $time){
    $dateArray = explode(" ", $date);
    switch ($dateArray[2]) {
        case 'janvier':$mois = "01";break;
        case "février":$mois = "02";break;
        case "mars":$mois = "03";break;
        case "avril":$mois = "04";break;
        case "mai":$mois = "05";break;
        case "juin":$mois = "06";break;
        case "juillet":$mois = "07";break;
        case "août":$mois = "08";break;
        case "septembre":$mois = "09";break;
        case "octobre":$mois = "10";break;
        case "novembre":$mois = "11";break;
        case "décembre":$mois = "12";
    }
    $dateArray[2] = $mois;
    return strtotime($dateArray[1]."-".$dateArray[2]."-".$dateArray[3]." ".$time);
}

