<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:login.php");
}

unset($_SESSION['coupon_content']);
unset($_SESSION['coupon_events']);
header('Location: index.php');
?>