<?php
session_start();


require_once('../db_connect.php');

$username = mysqli_real_escape_string($dbhandle, $_POST['username']);
$password = strip_tags($_POST['password']);
$password = sha1($password);

if(isset($username) && isset($password) && !empty($username) && !empty($password)) {
	$sql = mysqli_query($dbhandle, "SELECT * FROM be_user WHERE username = '$username' AND password = '$password'");

	if($sql){
		$num_rows = mysqli_num_rows($sql);
		if ($num_rows > 0) {
			$gid = mysqli_query($dbhandle, "SELECT * FROM be_user WHERE username = '$username' AND password = '$password'");
			$row = mysqli_fetch_assoc($gid);
			$uid = $row['id'];

			$_SESSION['pw_logged_user_admin'] = $uid;

			header('Location: index.php');
		}
		else{
			header('Location: login.php?LoginError=1');
		}
	}else{
		header('Location: login.php?LoginError=1');
	}

}

?>