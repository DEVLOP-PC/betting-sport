<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:login.php");
}
require_once __DIR__ . '/parser/vendor/autoload.php';

require 'parser/vendor/autoload.php';

use PHPHtmlParser\Dom;

include('parser/includes/ganon.php');
include('db_connect.php');


if(isset($_POST['coupon'])){
    $couponHtml = $_POST['coupon'];
    $couponHtmlPrefix = $_POST['prefix'];
    $_SESSION['coupon_html'] = $couponHtml;
    $_SESSION['coupon_html_prefix'] = $couponHtmlPrefix;
}else{

    $coupon_html = $_SESSION['coupon_html'];
    $coupon_prefix = $_SESSION['coupon_html_prefix'];

    unset($_SESSION['coupon_html']);

    preg_match('`<div id="'.$coupon_prefix.'_cCoupon_divTipoSco" class="divCpnTipi">(.*?)</div>`Uis', $coupon_html, $coupon_form);

    $dom = new Dom;
    $html = $dom->load($coupon_html);

    foreach ($html->getElementsByClass('CDelete') as $index => $element) {
        $element->setAttribute('href', "delete-cote.php?id=$index");
        $element->setAttribute('class', "CDelete active");
    }


    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$html);

    $divs = $doc->getElementsByTagName('div');
    $coupon_events = array();

    foreach ($divs as $div) {
        $classes = $div->getAttribute('class');
        if (strpos($classes, 'CItem te1') !== false) {

            $childs = $div->getElementsByTagName('div');

            foreach ($childs as $child) {
                $childClasses = $child->getAttribute('class');
                if (strpos($childClasses, 'CCodPub') !== false) {
                    $codepub = $child->nodeValue;
                }
            }

            foreach ($childs as $child) {
                $childClasses = $child->getAttribute('class');
                if (strpos($childClasses, 'CSubEv') !== false) {
                    $codePlayers = $child->nodeValue;
                }
            }

            $sql = "SELECT * FROM sub_events WHERE codepub = '".$codepub."' AND SUBSTRING( players, 1, 4 ) = '".substr($codePlayers, 0, 4)."'";
            $res = mysqli_query($dbhandle, $sql);
            $row = mysqli_fetch_assoc($res);

            if(mysqli_num_rows ($res) > 0) {
                if($row['status'] == 2){
                    $div->setAttribute ("data","wrong");
                }

            }else{
                $div->setAttribute ("data","wrong");
            }

            $coupon_events[] = $div->C14N();

        }
    }


    $amoutFormDom = $doc->getElementById($coupon_prefix.'_cCoupon_divTipoSco');

    if(!$amoutFormDom){
        header('Location: index.php');
    }

    $amoutForm = $amoutFormDom->C14N();

    if($doc->getElementById($coupon_prefix.'_cCoupon_txtTotaleDI')){

        $_SESSION['type'] = "integrale";

        $_SESSION['amount'] = $doc->getElementById($coupon_prefix.'_cCoupon_txtTotaleDI')->getAttribute('value');
        $_SESSION['gain_pot_min'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblVincitaPotMin')->nodeValue;
        $_SESSION['gain_pot_max'] = $doc->getElementById($coupon_prefix.'_cCoupon_litVincitaPotDI')->nodeValue;
        $_SESSION['bonus_min'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblBonusMinDI')->nodeValue;
        $_SESSION['bonus_max'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblBonusMaxDI')->nodeValue;
        $_SESSION['multiplicateur'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblImportoDICombinazioni')->nodeValue;
        $_SESSION['cote_min'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblQuotaTotaleDIMin')->nodeValue;
        $_SESSION['cote_max'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblQuotaTotaleDIMax')->nodeValue;


    }else{

        $_SESSION['type'] = "multiple";

        $_SESSION['amount'] = $doc->getElementById($coupon_prefix.'_cCoupon_txtImporto')->getAttribute('value');
        $_SESSION['gain_pot'] = $doc->getElementById($coupon_prefix.'_cCoupon_litVincitaPot')->nodeValue;
        $_SESSION['bonus'] = $doc->getElementById($coupon_prefix.'_cCoupon_litBonusNumScommesse')->nodeValue;
        $_SESSION['cote_tot'] = $doc->getElementById($coupon_prefix.'_cCoupon_lblQuotaTotale')->nodeValue;

    }

//    $_SESSION['coupon_content'] = $coupon_html;
    $_SESSION['amount_form'] = $amoutForm;
    $_SESSION['coupon_events'] = $coupon_events;
    header('Location: index.php');

}

