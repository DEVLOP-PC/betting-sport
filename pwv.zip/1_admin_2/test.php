<?php


$string ="";
