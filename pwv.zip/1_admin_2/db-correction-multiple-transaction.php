#!/usr/local/bin/php
<?php
require_once('db_connect.php');

//Multiple
$parisRes = mysqli_query($dbhandle, "SELECT * FROM coupon WHERE etat_pari = 'win' AND montant_gagne= 0");

while($rowCoupon = mysqli_fetch_assoc($parisRes)){

    $couponDbId = $rowCoupon['id'];
    $usager = $rowCoupon['usager'];


    $resUsager = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$usager'");
    $rowUsager = mysqli_fetch_assoc($resUsager);
    $winnerId = $rowUsager['id'];

    $codeCoupon = $rowCoupon['code_coupon'];
    $gain = $rowCoupon['gain_pot'];

    date_default_timezone_set('Africa/Tunis');
    $currentDateTime = date('Y-m-d H:i:s') ;

    $newAmount = $rowUsager['solde'];

    mysqli_query($dbhandle, "UPDATE coupon SET montant_gagne = '$gain' WHERE id = '$couponDbId'");

    //Transaction
    $sql = "INSERT INTO transaction (date, type, coupon, avoir, solde, id_usager, id_coupon)
            VALUES ('$currentDateTime', 'gain pari', '$codeCoupon', '$gain', '$newAmount', '$winnerId', '$couponDbId')";
    mysqli_query($dbhandle, $sql) or die(mysqli_error($dbhandle));

}
?>