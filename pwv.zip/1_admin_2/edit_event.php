<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$score = $_POST['score'];
$status = $_POST['status'];
$eventId = $_POST['eventId'];
$players = $_POST['players'];
$signe = $_POST['signe'];
$codepub = $_POST['codepub'];
$timestamp = $_POST['timestamp'];

if($status == 3){
    $score = "void";
}

$uid = intval($_SESSION['pw_logged_user_admin']);

$signe = str_replace(array("&"), "&amp;", $signe);

$currentPage = $_POST['currentPage'];

$resUser = mysqli_query($dbhandle, "SELECT * from be_user WHERE id = '".$uid."'" );
$rowUser = mysqli_fetch_assoc($resUser);

$username = $rowUser['prenom'];

mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE id = ".intval($eventId) );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE id = ". intval($eventId) );
mysqli_query($dbhandle, "UPDATE events SET user = '$username' WHERE id = ". intval($eventId) );

mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET user = '$username' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );


/*mysqli_query($dbhandle, "UPDATE events AS s, (SELECT id  FROM events WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."') AS p
SET score = '".$score."'
WHERE s.id = p.id;" );

mysqli_query($dbhandle, "UPDATE events AS s, (SELECT id  FROM events WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."') AS p
SET status = '".$status."'
WHERE s.id = p.id;" );

mysqli_query($dbhandle, "UPDATE events AS s, (SELECT id  FROM events WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."') AS p
SET user = '".$username."'
WHERE s.id = p.id;" );*/

mysqli_query($dbhandle, "UPDATE be_user SET nb_corr_jour = nb_corr_jour+1 WHERE id = '".$uid."'" );
mysqli_query($dbhandle, "UPDATE be_user SET nb_corr_tot = nb_corr_tot+1 WHERE id = '".$uid."'" );




//BE user Stat
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

date_default_timezone_set('Africa/Tunis');
$currentDateTime = date('Y-m-d H:i:s') ;
$current_timestamp = time();

$sessionId = session_id();

mysqli_query($dbhandle, "INSERT INTO be_user_stat (user_id, ip, session_id, date, timestamp, event_id) values ( '".$uid."', '".$ip."', '".$sessionId."', '".$currentDateTime."', '".$current_timestamp."', '".intval($eventId)."' )" );


//sleep(2);
//usleep(1500000);

header("Location:index.php?page=".$currentPage);

?>