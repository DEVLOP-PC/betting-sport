#!/usr/bin/php
<?php
require_once('/var/www/planet/public_html/db_connect.php');
mysqli_query($dbhandle, 'UPDATE be_user SET nb_corr_jour = 0') or die(mysqli_error($dbhandle));
$date = date('d/m/Y H:i:s');
echo $date;
