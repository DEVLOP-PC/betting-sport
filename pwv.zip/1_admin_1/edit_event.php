<?php
require_once('../db_connect.php');

$score = $_POST['score'];
$status = $_POST['status'];
$eventId = $_POST['eventId'];
$players = $_POST['players'];
$signe = $_POST['signe'];
$codepub = $_POST['codepub'];
$timestamp = $_POST['timestamp'];

if($status == 3){
    $score = "void";
}

$signe = str_replace(array("&"), "&amp;", $signe);

$currentPage = $_POST['currentPage'];

mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE id = ".intval($eventId) );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE id = ". intval($eventId) );

//echo "UPDATE events SET status = '$status' WHERE id = ". intval($eventId);

/*mysqli_query($dbhandle, "UPDATE events SET score = '$score'  WHERE players = '".$players."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE players = '".$players."' AND signe = '".$signe."'" );*/

//mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE codepub = '".$codepub."' AND timestamp = '".$timestamp."' AND signe = '".$signe."'" );


header("Location:index.php?page=".$currentPage);

?>