<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$currentPage = $_POST['currentPage'];

$couponId = $_POST['coupondbid'];
$status = $_POST['status'];

if($status == 'lost'){
    mysqli_query($dbhandle, "UPDATE coupon SET etat_pari = 'lost' WHERE id = '$couponId'");
}
if($status == 'win'){

    date_default_timezone_set('Africa/Tunis');
    $currentDateTime = date('Y-m-d H:i:s') ;

    $codeCoupon = $_POST['codeCoupon'];
    $usagerDbId = $_POST['usagerdbid'];
    $gain = (float)str_replace(',', '.', $_POST['gain']);
    mysqli_query($dbhandle, "UPDATE coupon SET etat_pari = 'win' WHERE id = '$couponId'");
    mysqli_query($dbhandle, "UPDATE coupon SET montant_gagne = '$gain' WHERE id = '$couponId'");
    mysqli_query($dbhandle, "UPDATE usager SET solde = solde + '$gain' WHERE id = '$usagerDbId'");

    $gidUsager = mysqli_query($dbhandle, "SELECT * FROM usager WHERE id = '$usagerDbId'");
    $rowUsager = mysqli_fetch_assoc($gidUsager);
    $newAmount = $rowUsager['solde'];

    //Transaction
    $usagerDbId = $rowUsager['id'];
    $sql = "INSERT INTO transaction (date, type, coupon, avoir, solde, id_usager, id_coupon)
        VALUES ('$currentDateTime', 'gain pari', '$codeCoupon', '$gain', '$newAmount', '$usagerDbId', '$couponId')";
    mysqli_query($dbhandle, $sql) or die(mysqli_error($dbhandle));
}

if($status == 'running'){
    mysqli_query($dbhandle, "UPDATE coupon SET etat_pari = 'running' WHERE id = '$couponId'");
}

header("Location:list-coupons.php?page=".$currentPage);
?>