<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin - Paris</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="wrapper">

    <!-- Sidebar -->
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand">
                <a href="index.php">
                    Events
                </a>
            </li>
            <li>
                <a href="index.php">Mise à jour events</a>
            </li>
            <li>
                <a href="correction-events.php">Correction evenement</a>
            </li>
            <li>
                <a href="list-coupons.php">Mise à jour coupons</a>
            </li>
            <li>
                <a href="correction-coupons.php">Correction coupons</a>
            </li>
            <li>&nbsp;</li>
            <li>
                <a href="logout.php">Déconnexion</a>
            </li>
        </ul>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Liste des evenements</h1>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Event</th>
                            <th>Players</th>
                            <th>Score</th>
                            <th>Signe</th>
                            <th>Status</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        //Pagination
                        $messagesParPage=5000;

                        $retour_total=mysqli_query($dbhandle, "SELECT COUNT(*) AS total FROM events order by timestamp desc,players");
                        $donnees_total=mysqli_fetch_assoc($retour_total);
                        $total=$donnees_total['total'];

                        //Nous allons maintenant compter le nombre de pages.
                        $nombreDePages=ceil($total/$messagesParPage);

                        if(isset($_GET['page'])){
                            $pageActuelle=intval($_GET['page']);
                            if($pageActuelle>$nombreDePages){
                                $pageActuelle=$nombreDePages;
                            }
                        }
                        else{
                            $pageActuelle=1; // La page actuelle est la n°1
                        }

                        $premiereEntree=($pageActuelle-1)*$messagesParPage;

                        $resIntgOcEvents = mysqli_query($dbhandle, "SELECT * FROM events order by timestamp desc,players LIMIT $premiereEntree, $messagesParPage");



                        if(mysqli_num_rows ($resIntgOcEvents) > 0){
                            while($rowIntgOcEvents = mysqli_fetch_assoc($resIntgOcEvents)){
                                ?>
                                <tr>
                                    <form action="edit_event.php" method="post">
                                        <td><?php echo $rowIntgOcEvents['date'];?></td>
                                        <td><?php echo $rowIntgOcEvents['time'];?></td>
                                        <td><?php echo $rowIntgOcEvents['event'];?></td>
                                        <td><?php echo $rowIntgOcEvents['players'];?></td>
                                        <td><input type="text" size="3" value="<?php echo $rowIntgOcEvents['score'];?>" name="score" /></td>
                                        <td><?php echo $rowIntgOcEvents['signe'];?></td>
                                        <td>
                                            <select class="form-control" id="sel1" name="status">
                                                <option value="0" <?php if($rowIntgOcEvents['status'] == '0') echo "selected";?>>Non defini</option>
                                                <option value="1" <?php if($rowIntgOcEvents['status'] == '1') echo "selected";?>>Correct</option>
                                                <option value="2" <?php if($rowIntgOcEvents['status'] == '2') echo "selected";?>>Faux</option>
                                                <option value="3" <?php if($rowIntgOcEvents['status'] == '3') echo "selected";?>>Void</option>
                                            </select>
                                        </td>
                                        <td><button class="btn btn-primary"><span class="glyphicon glyphicon-refresh"></span> Update</button></td>
                                        <input type="hidden" name="eventId" value="<?php echo $rowIntgOcEvents['id'];?>" />
                                        <input type="hidden" name="players" value="<?php echo $rowIntgOcEvents['players'];?>" />
                                        <input type="hidden" name="signe" value="<?php echo $rowIntgOcEvents['signe'];?>" />
                                        <input type="hidden" name="codepub" value="<?php echo $rowIntgOcEvents['codepub'];?>" />
                                        <input type="hidden" name="timestamp" value="<?php echo $rowIntgOcEvents['timestamp'];?>" />
                                        <input type="hidden" name="currentPage" value="<?php echo $pageActuelle;?>" />
                                    </form>
                                </tr>

                                <?php
                            }}?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="pagination">

                        <?php
                        for($i=1; $i<=$nombreDePages; $i++) {
                            //On va faire notre condition
                            if($i==$pageActuelle){
                                echo '<li class="disabled"><a href="#">'.$i.'</a></li>';
                            }
                            else{
                                echo '<li><a href="correction-events.php?page='.$i.'">'.$i.'</a></li> ';
                            }
                        }
                        ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Menu Toggle Script -->
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>

</body>