<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

if(!isset($_GET['correction'])){
	$where = "WHERE status=0";
}else{
	$where = "";
}


?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>Admin Events</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <!-- Font-Awesome -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">


</head>
<body>
<table class="table table-striped">
    <thead>
        <tr>
            <th>Date</th>
            <th>Time</th>
            <th>Event</th>
            <th>Players</th>
            <th>Score</th>
            <th>Signe</th>
            <th>Status</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>
<?php
            $sqlIntgOcEvents = "SELECT * FROM events
                                  $where
								  ORDER BY timestamp DESC,players DESC";
            $resIntgOcEvents = mysqli_query($dbhandle, $sqlIntgOcEvents) or die(mysqli_error($dbhandle));
            if(mysqli_num_rows ($resIntgOcEvents) > 0){
                while($rowIntgOcEvents = mysqli_fetch_assoc($resIntgOcEvents)){
            ?>
			<tr>
				<form action="edit_event.php" method="post">
					<td><?php echo $rowIntgOcEvents['date'];?></td>
					<td><?php echo $rowIntgOcEvents['time'];?></td>
					<td><?php echo $rowIntgOcEvents['event'];?></td>
					<td><?php echo $rowIntgOcEvents['players'];?></td>
					<td><input type="text" size="3" value="<?php echo $rowIntgOcEvents['score'];?>" name="score" /></td>
					<td><?php echo $rowIntgOcEvents['signe'];?></td>
					<td>
                        <select class="form-control" id="sel1" name="status">
							<option value="0" <?php if($rowIntgOcEvents['status'] == '0') echo "selected";?>>Non defini</option>
							<option value="1" <?php if($rowIntgOcEvents['status'] == '1') echo "selected";?>>Correct</option>
							<option value="2" <?php if($rowIntgOcEvents['status'] == '2') echo "selected";?>>Faux</option>
						</select>
					</td>
					<td><button class="btn btn-primary"><span class="glyphicon glyphicon-refresh"></span> Update</button></td>
					<input type="hidden" name="eventId" value="<?php echo $rowIntgOcEvents['id'];?>" />
				</form>	
			</tr>
			
			<?php
			}}?>
    </tbody>
</table>
</body>
</html>
