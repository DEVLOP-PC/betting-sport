<?php

require_once __DIR__ . '/vendor/autoload.php';

require 'vendor/autoload.php';

use PHPHtmlParser\Dom;

include('includes/db_connect.php');
include('includes/ganon.php');
include('includes/functions.php');

date_default_timezone_set('Africa/Tunis');
$date = date('Y-m-d');

$sqlLivescore = "SELECT * FROM livescore";
$resLivescore = mysqli_query($dbhandle, $sqlLivescore);

while($scoreRow = mysqli_fetch_assoc($resLivescore)){
    /*$sqlUpdate = "UPDATE events SET score = ".$scoreRow['score']." WHERE score = '' AND date = '"
        .$scoreRow['datefr']."' AND REPLACE(lower(players),' ','') = '".str_replace(" ","", strtolower($scoreRow['players']))."'";*/
    $sqlUpdate = "UPDATE events SET score = '".$scoreRow['score']."' WHERE score = '' AND date = '"
        .$scoreRow['datefr']."' AND ( REPLACE(lower(players),' ','') like '%".str_replace(" ","", strtolower($scoreRow['home']))."%' OR REPLACE(lower(players),' ','') like '%".str_replace(" ","", strtolower($scoreRow['away']))."%')";
    echo $sqlUpdate."<br>";
    mysqli_query($dbhandle, $sqlUpdate);
}
