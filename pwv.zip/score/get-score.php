<?php

require_once __DIR__ . '/vendor/autoload.php';

require 'vendor/autoload.php';

use PHPHtmlParser\Dom;

include('includes/db_connect.php');
include('includes/ganon.php');
include('includes/functions.php');

date_default_timezone_set('Africa/Tunis');
$date = date('Y-m-d');

$jour = array("dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi");
$mois = array("","janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre");

$datefr = $jour[date("w")]." ".date("d")." ".$mois[date("n")]." ".date("Y");


$curl = curl_init('http://www.livescore.com/'.$date.'/');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10');
$result = curl_exec($curl);
curl_close($curl);

if (!$result) {
    die("something's wrong!");
}

$html = str_get_dom($result);
$dom = new Dom;
$dom->load($html);

foreach ($dom->getElementsByClass('row-gray') as $div) {
    $domTmp = new Dom;
    $domTmp->load($div->outerHtml);
    $status = preg_replace('/[^a-zA-Z0-9\'\.:]*/i', '', $domTmp->getElementsByClass('min')->innerHtml);
    if($status == "FT"){
        $score = str_replace(" ","", strip_tags($domTmp->getElementsByClass('sco')->innerHtml));
        $players = array();
        foreach ($domTmp->getElementsByClass('ply') as $player) {
            $players[] = preg_replace('/[^a-zA-Z0-9\'\.:]*/i', '', $player->innerHtml);
        }

        $playersString = $players[0]." - ".$players[1];

        $sqlCheck = "SELECT * FROM livescore WHERE home = '".$players[0]."' and away = '".$players[1]."' and date = '".$date."'";
        $res = mysqli_query($dbhandle, $sqlCheck);

        if(mysqli_num_rows ($res) == 0) {
            $sqlInsert = "INSERT INTO livescore (home, away, players, score, date, datefr)
            VALUES ('".$players[0]."', '".$players[1]."', '".$playersString."', '".$score."', '".$date."', '".$datefr."')";
            mysqli_query($dbhandle, $sqlInsert)or die(mysqli_error($dbhandle));
        }

       echo $players[0]." ".$score." ".$players[1]."<br>";
    }

}