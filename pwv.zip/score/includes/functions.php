<?php
/**
 * Created by PhpStorm.
 * User: amine
 * Date: 23/01/16
 * Time: 22:06
 */

function convertDate($date, $time){
    $dateArray = explode(" ", $date);
    switch ($dateArray[2]) {
        case 'janvier':$mois = "01";break;
        case "février":$mois = "02";break;
        case "mars":$mois = "03";break;
        case "avril":$mois = "04";break;
        case "mai":$mois = "05";break;
        case "juin":$mois = "06";break;
        case "juillet":$mois = "07";break;
        case "août":$mois = "08";break;
        case "septembre":$mois = "09";break;
        case "octobre":$mois = "10";break;
        case "novembre":$mois = "11";break;
        case "décembre":$mois = "12";
    }
    $dateArray[2] = $mois;
    return strtotime($dateArray[1]."-".$dateArray[2]."-".$dateArray[3]." ".$time);
}