<?php

$dbhandle = mysqli_connect('localhost', 'id4947759_planet', 'Just4havefun', 'id4947759_planet');


mysqli_query($dbhandle,"SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");

date_default_timezone_set('Africa/Tunis');
?>
