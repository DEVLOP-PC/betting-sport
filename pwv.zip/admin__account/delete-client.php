<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin_acount'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$usagerId = $_GET['usagerId'];

$sqlUsager = "DELETE FROM usager where id='".$usagerId."'";
mysqli_query($dbhandle, $sqlUsager) or die(mysqli_error($dbhandle));


header("Location:edit-account.php");
?>