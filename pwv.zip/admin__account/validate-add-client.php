<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin_acount'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$idt = $_POST['idt'];
$login = $_POST['login'];
$password = sha1($_POST['password']);
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$solde = $_POST['solde'];



$sql = "INSERT INTO usager (identificateur, username, password, nom, prenom, solde)
                VALUES ('".$idt."', '".$login."', '".$password."', '".$nom."', '".$prenom."', '".$solde."')";
mysqli_query($dbhandle, $sql);

header("Location:index.php");
?>