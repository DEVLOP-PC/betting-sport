<?php
require_once('../db_connect.php');

$montant = $_POST['montant'];
$id = $_POST['id'];

date_default_timezone_set('Africa/Tunis');
$currentDateTime = date('Y-m-d H:i:s') ;

mysqli_query($dbhandle, "UPDATE usager SET solde = solde + '$montant' WHERE id = '$id'");

$gidUsager = mysqli_query($dbhandle, "SELECT * FROM usager WHERE id = '$id'");
$rowUsager = mysqli_fetch_assoc($gidUsager);
$newAmount = $rowUsager['solde'];

//Transaction
$usagerDbId = $rowUsager['id'];
$sql = "INSERT INTO transaction (date, type, avoir, solde, id_usager)
        VALUES ('$currentDateTime', 'neteller', '$montant', '$newAmount', '$id')";
mysqli_query($dbhandle, $sql) or die(mysqli_error($dbhandle));

header("Location:edit-solde.php");

?>