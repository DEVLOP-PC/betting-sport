<?php
require_once('../db_connect.php');

$score = $_POST['score'];
$status = $_POST['status'];
$eventId = $_POST['eventId'];

mysqli_query($dbhandle, "UPDATE events SET score = '$score' WHERE id = '$eventId'");
mysqli_query($dbhandle, "UPDATE events SET status = '$status' WHERE id = '$eventId'");

header("Location:index.php");

?>