<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin_acount'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$id = $_POST['id'];

$idt = $_POST['idt'];
$login = $_POST['login'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];


if(isset($_POST['new_password'])){
    $password = sha1($_POST['new_password']);
}else{
    $password = $_POST['current_password'];
}

$sql = "UPDATE usager SET identificateur='".$idt."', username='".$login."', password='".$password."', nom='".$nom."', prenom='".$prenom."'
    WHERE id = '".$id."'";
mysqli_query($dbhandle, $sql);

header("Location:edit-account.php");
?>