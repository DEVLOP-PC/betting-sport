<?php
session_start();
if(!isset($_SESSION['pw_logged_user_admin_acount'])){
    header("Location:login.php");
}
require_once('../db_connect.php');

$sqlCouponId = "SELECT max(identificateur)+1 as idt FROM usager";
$resCouponId = mysqli_query($dbhandle, $sqlCouponId) or die(mysqli_error($dbhandle));
$rowCouponId = mysqli_fetch_assoc($resCouponId);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin - Accounts</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="wrapper">

    <!-- Sidebar -->
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand">
                <a href="index.php">
                    Accounts
                </a>
            </li>
            <li>
                <a href="edit-solde.php">Transactions</a>
            </li>
            <li>
                <a href="edit-account.php">Mise à jour données Client</a>
            </li>
            <li>
                <a href="add-client.php">Ajouter Nouveau Client</a>
            </li>
        </ul>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <h1>Ajout Nouveau Client</h1>
                    <form role="form" method="post" action="validate-add-client.php">
                        <div class="form-group">
                            <label for="idt">Identifiant client:</label>
                            <input name="idt" type="text" value="<?php echo $rowCouponId['idt'];?>" class="form-control" id="idt" required="true" readonly>
                        </div>
                        <div class="form-group">
                            <label for="login">Nom d'utilisateur:</label>
                            <input name="login" type="text" class="form-control" id="login" required="true">
                        </div>
                        <div class="form-group">
                            <label for="pwd">Mot de passe:</label>
                            <input name="password" type="password" class="form-control" id="pwd" required="true">
                        </div>
                        <div class="form-group">
                            <label for="nom">Nom :</label>
                            <input name="nom" type="text" class="form-control" id="nom" required="true">
                        </div>
                        <div class="form-group">
                            <label for="prenom">Prénom:</label>
                            <input name="prenom" type="text" class="form-control" id="prenom" required="true">
                        </div>
                        <div class="form-group">
                            <label for="solde">Solde:</label>
                            <input name="solde" type="text" value="0" class="form-control" id="solde" required="true">
                        </div>
                        <button type="submit" class="btn btn-default">Submit</button>
                    </form>
                </div>
                <div class="col-lg-6"></div>
            </div>
        </div>
    </div>
    <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Menu Toggle Script -->
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>

</body>