<?php
session_start();


$username = strip_tags($_POST['username']);
$password = strip_tags($_POST['password']);

if(isset($username) && isset($password) && !empty($username) && !empty($password)) {
	if($username=="TheCracker" && $password=="Just4havefun") {
		$_SESSION['pw_logged_user_admin_acount'] = true;
		header('Location: index.php');
	}else{
		header('Location: login.php');
	}
}


?>