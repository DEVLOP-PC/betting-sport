﻿/// <reference path="jquery-1.7.1.js" />

(function __Session__(exports, undefined)
{
    var
        $session = exports.session =
        {
            onExpireWarning: function onExpireWarning()
            {
                console.log("Session is about to expire.");
            },

            onExpired: function onExpire()
            {
                console.log("Session has expired.");
            }
        },
        xhr =
        {
            _factories: 
		    [
			    function () { return new XMLHttpRequest(); },
			    function () { return new ActiveXObject("Msxml2.XMLHTTP"); },
			    function () { return new ActiveXObject("Msxml3.XMLHTTP"); },
			    function () { return new ActiveXObject("Microsoft.XMLHTTP"); }
		    ],

            create: function _createXmlHttpRequest()
            {
                /// <returns type="XMLHttpRequest" />
                var ret = null, i = 0;
                for (i = 0; i < this._factories.length; i++)
                {
                    try
                    {
                        ret = this._factories[i]();
                        return ret;
                    }
                    catch (e)
                    {
                        console.error(e.toString());
                    }
                }
                return null;
            }
        },
        _config =
        {
            expireWarningAt: 300000,
            logoutUrl: "Logout.aspx",
            timeout: 1800000, // 30 minutes
            slidingExpiration: false,
            pingUrl: "SessionPing.ashx",
            pingInterval: 10000, //60000, // ping server at 1min interval to keep IIS session alive
            pingMaxFailCount: 5 // after 5 failed pings we will force client to logout url
        },
        expireWarningShown = false,
        // 
        startTime = new Date().getTime(),
        //
        pingTimer = null,
        pingFailCount = 0,
        pingLastTimeStamp = null,
        $hasOwn = Object.prototype.hasOwnProperty;

    $session.configure = function (config)
    {
        config = config || {};
        for (var key in config)
        {
            if ($hasOwn.call(config, key))
                _config[key] = config[key];
        };
    };

    $session.logout = function logout()
    {
        window.location = _config.logoutUrl;
    };

    function pingSession()
    {
        // GET http handler which will perform IIS session ping...
        var req = xhr.create();

        req.onreadystatechange = function ()
        {
            if (this.readyState != 4)
                return;

            if ((this.status != 200) && (this.status != 304))
            {
                pingFailCount++;
                if (pingFailCount > _config.pingMaxFailCount)
                {
                    // internal error: session ping service is unreachable, force redirect to logout page
                    $session.logout();
                    return;
                };
            }
            else // xhr completed ok
            {
                //console.log(req.responseText);
                var responseParts = req.responseText.split(" ");
                var responseStatus = responseParts[0];
                var responseIsAuthenticated = responseParts[1] === "true" ? true : false;
                var responseSessionTimeout = parseInt(responseParts[2], 10);
                var responseTimeLeft = parseInt(responseParts[3], 10);

                //console.log("Status: " + responseStatus + "; IsAuth: " + responseIsAuthenticated + "; SessionTimeout: " + responseSessionTimeout + "; TimeLeft: " + responseTimeLeft);
                // reset internal counters and remove onreadystatechange event handler
                pingFailCount = 0;
                pingLastTimestamp = new Date();
                this.onreadystatechange = null;

                if (responseIsAuthenticated)
                {
                    if (responseTimeLeft <= _config.expireWarningAt && !expireWarningShown)
                    {
                        expireWarningShown = true;
                        $session.onExpireWarning();
                    };

                    if (responseTimeLeft <= 15000)
                    {
                        $session.onExpired();
                        $session.logout();
                    };
                };
            };
        };

        req.open("GET", _config.pingUrl + "?ts=" + new Date().getTime(), true, null, null); 
        req.setRequestHeader("User-Agent", "XMLHTTP/1.0");
        req.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        req.setRequestHeader("X-Sks", "365");      
        req.setRequestHeader("Accept", "text/javascript, text/html, application/xml, text/xml, text/plain, */*");

        // if XHR completed before send (usually an internal browser error) just return
        if (req.readyState == 4)
            return;

        // send request
        req.send();
    };

    $session.startTracking = function ()
    {
        pingTimer = window.setInterval(function ()
        {
            pingSession();
        }, _config.pingInterval);
    };

    $session.stopTracking = function ()
    {
        window.clearInterval(pingTimer);
        pingTimer = null;
    };

})(window.sks365 || (window.sks365 = {}));