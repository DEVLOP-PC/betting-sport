

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head><title>

</title><link rel="SHORTCUT ICON" href="../../App_Themes/PlanetWin365/Images/Icons/favicon.ico" type="text/css"></link><link type="text/css" rel="stylesheet" href="//static.planetwin365.com/App_Themes/PlanetWin365/layout.css" /><link type="text/css" rel="stylesheet" href="//static.planetwin365.com/App_Themes/PlanetWin365/calendar.css" /><link type="text/css" rel="stylesheet" href="//static.planetwin365.com/App_Themes/PlanetWin365/coupon.css" /><link type="text/css" rel="stylesheet" href="//static.planetwin365.com/App_Themes/PlanetWin365/quote.css" /></head>
<body class="bodyMainPop fr-FR">
    <form name="aspnetForm" method="post" action="LastWinningsDetailsPopUp.aspx?Winner=" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTk2MDAxOTQ2Ng9kFgJmD2QWAgIBD2QWAgIDD2QWAgIPDzwrAA0AZBgBBRhwb3BVcCRQQyRkZ19FbGVuY29FdmVudGkPZ2TzPciolXce21TgKak0FMLGgWZ25Q==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=f3pQjycQyzTdyno9eL6vAMSzJv27X455zTEuNx4V8i0AFvRN3j20rAiQPBrmPj0v27ZRMWdrb4eZGLSOGQGUycaLOAk1&amp;t=635589471570790873" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=8Bbe_AK8SMSVU6sEaTHNMgBnzcE53zqJ58NPK16RmnL7_WsSgzDX8NhIPzAlUao-8BoRBE2W5nPI9nTKn4qEcO6TMzKul1Hq2F0dYoGzDqJni6V9wqV8KKs_YvzNhXsrW_xXnPWRD7phh3r3gopoHGdV7mw1&amp;t=ffffffffbcb9b94a" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=9tR3EV_JjSKp_WLqKao8foPHyjbwS63OnHIUlsR1dNtFPe_wM1NeGG0n4q9v4dNmG0JgXPNjM1ZO7xuPEkL2ERO0g0bc9xz_t6HBMOP564dXPYylRdfFXJM8uRKPJbq8D870yVLJNcElVWZxOMHgnOqlMyJeAPlaH5J7g-KsW5eFkQ_E0&amp;t=ffffffffbcb9b94a" type="text/javascript"></script>
<script src="../Scripts/jquery-x.x.x.min.js?v=636437504660000000" type="text/javascript"></script>
<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="ACC077A9" />
</div>
         <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('popUp$SM', document.getElementById('aspnetForm'));
Sys.WebForms.PageRequestManager.getInstance()._updateControls([], [], [], 90);
//]]>
</script>

    <div>
        
    
    
    
        <div class="LWimg" style="width: 850px;">               
            <div class="stakedLW">              
                <span class="title">Joué</span>
                <span class="value"></span>
                <span class="currency"></span>
            </div>
            <div class="winLW">
                <span class="title">Gain</span>
                <span class="value"></span>
                <span class="currency"></span>
            </div>
        </div>
        <div class="LWContent" style="width: 850px;">
     

    <script language="javascript" type="text/javascript" > //handling big winning amount font size
        $(document).ready(function () {
            var $value = $('.value', '.winLW');
            var $currency = $('.currency', '.winLW');
            var $totalLength = $value.text().length + $currency.text().length;

            if (($totalLength > 11) && ($totalLength < 13)) {
                $value.css({ 'top': '35px', 'font-size': '23px' });
                $currency.css({ 'top': '35px', 'font-size': '23px' });
            }
            else if (($totalLength >= 13) && ($totalLength < 16)) {
                $value.css({ 'top': '34px', 'font-size': '21px' });
                $currency.css({ 'top': '34px', 'font-size': '21px' });
            }
            else if ($totalLength >= 16) {
                $value.css({ 'top': '36px', 'font-size': '19px' });
                $currency.css({ 'top': '36px', 'font-size': '19px' });
            }
            else {
                return;
            }
        });
    </script>

     <div class="spacer9"></div>
     <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0" class="LWSection">
             <tr>
                <td class="SectionTitle" colspan="2">
                    Coupon
                </td>
            </tr>
            <tr>
              <td class="cellaSx">
                    Date
                </td>
                <td class="cellaDx" style="text-align:right">
                    
                </td>
            </tr>
            <tr>
                <td class="cellaSx">
                    Type de pari
                </td>
                <td class="cellaDx" style="text-align:right">
                    
                </td>
            </tr>
        </table>
               <div class="spacer9"></div> 
        <!-- Tabella che visualizzo quando c'è un sistema -->
        <div id="popUp_PC_tbl_DettagliSistema" class="LWSection">
            <table cellpadding="0" cellspacing="0" width="100%" align="center" class="dgStyle">
                <tr>
                    <td class="SectionTitle" colspan="7">
                        Détail système
                    </td>
                </tr>
                <tr class="dgSubHdrStyle">
                    <td align="center">Type combinaison</td>
                    <td align="center">Numéro de Combinaisons</td>
                    <td align="right">Montant</td>
                    <td align="right">Gain Pot. </td>
                    <td align="right">Bonus</td>
                    <td align="right">Gain</td>
                </tr>
                
            </table>
        </div>
        
         <!-- Tabella che visualizzo Singole/Multiple -->
        <table id="popUp_PC_tbl_DettagliScommessa" cellpadding="0" cellspacing="0" width="100%" align="center" class="LWSection">
	<tr>
		<td class="SectionTitle" colspan="2">
                    Détail
                </td>
	</tr>
	<tr>
		<td class="cellaSx">
                    <span class="detScoIG">Montant joué</span>
                </td>
		<td class="cellaDx" style="text-align:right">
                     <span class="detScoIG"></span>
                </td>
	</tr>
	<tr>
		<td class="cellaSx">
                    Bonus
                </td>
		<td class="cellaDx" style="text-align:right">
                    
                </td>
	</tr>
	<tr>
		<td class="cellaSx">
                    <span class="detScoVP">Gain Pot. </span>
                </td>
		<td class="cellaDx" style="text-align:right">
                    <span class="detScoVP"></span>
                </td>
	</tr>
</table>

        <div class="spacer9"></div> 
                          
         <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
            <tr>
                <td class="SectionTitle" colspan="2">
                    Liste événements
                </td>
            </tr>
            </table>
   
        <div>

</div>
    
        </div>
    
    </div>
    

<script type="text/javascript">
//<![CDATA[
Sys.Application.initialize();
//]]>
</script>
</form>
</body>
</html>
