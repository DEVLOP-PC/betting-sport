#!/usr/bin/php5
<?php
/**
 * Created by PhpStorm.
 * User: amine
 * Date: 01/02/16
 * Time: 20:17
 */

include('includes/db_connect.php');

//date_default_timezone_set('Africa/Tunis');
date_default_timezone_set('Europe/Malta');
$current_timestamp = time();


$sql = "SELECT * FROM sub_events WHERE status = 1 and timestamp < ".$current_timestamp;
$res = mysqli_query($dbhandle, $sql);
if(mysqli_num_rows ($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {

        $id = $row['id'];

        $codepub = $row['codepub'];
        $eventPlayers = checkEvent($codepub);

//        echo "live raw: ".$eventPlayers."<br>";
//        echo "codepub: ".$codepub."<br>";

        $codePlayers = $row['players'];

        $eventPlayers = clean($eventPlayers);
        $codePlayers = utf8_encode(clean($codePlayers));

        $eventPlayers = str_replace(' ', '', $eventPlayers);
        $eventPlayers = preg_replace('/(\s\s+|\t|\n)/', '', $eventPlayers);

        $codePlayers =  str_replace(' ', '', $codePlayers);
        $codePlayers = preg_replace('/(\s\s+|\t|\n)/', '', $codePlayers);

        $cmp = strcmp($eventPlayers, $codePlayers);

//        echo "live ".$eventPlayers;
//        echo "<br>";
//        echo "local ".$codePlayers;
//        echo "  ".$cmp;
//        echo "<p>";


        if ($cmp != 0) {
            mysqli_query($dbhandle, "UPDATE sub_events set status = 2 WHERE id = ".intval($id));
        }
    }
}

mysqli_query($dbhandle, "update sub_events set players = Replace(players, '   ', '') where players like '%   '");

function checkEvent($codepub){
    $data = array("CodPub" => $codepub, "CodiceConfigurazione" => "Default");
    $data_string = json_encode($data);
    $qry_str = "?CodPub=%22".$data["CodPub"]."%22&CodiceConfigurazione=%22Default%22";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://ww3.365planetwinall.net/Controls/FastBetWS.asmx/GetTQ' . $qry_str);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
    );

    $result = curl_exec($ch);
    $array = json_decode($result, true);
    return $array['d']['SE'];
}

function clean($str){
    // clean out the \n\r
    $str = str_replace(array("\r\n", "\r", "\n"), '', $str);

    // strip the doctype
    $str = mb_eregi_replace("<!doctype(.*?)>", '', $str);

    // strip out comments
    $str = mb_eregi_replace("<!--(.*?)-->", '', $str);

    // strip out cdata
    $str = mb_eregi_replace("<!\[CDATA\[(.*?)\]\]>", '', $str);

    // strip out <script> tags
    $str = mb_eregi_replace("<\s*script[^>]*[^/]>(.*?)<\s*/\s*script\s*>", '', $str);
    $str = mb_eregi_replace("<\s*script\s*>(.*?)<\s*/\s*script\s*>", '', $str);

    // strip out <style> tags
    $str = mb_eregi_replace("<\s*style[^>]*[^/]>(.*?)<\s*/\s*style\s*>", '', $str);
    $str = mb_eregi_replace("<\s*style\s*>(.*?)<\s*/\s*style\s*>", '', $str);

    // strip out pre-formatted tags
    $str = mb_eregi_replace("<\s*(?:code)[^>]*>(.*?)<\s*/\s*(?:code)\s*>", '', $str);

    // strip out server side scripts
    $str = mb_eregi_replace("(<\?)(.*?)(\?>)", '', $str);

    // strip smarty scripts
    $str = mb_eregi_replace("(\{\w)(.*?)(\})", '', $str);

    // remove extra spaces
    $str = str_replace(array("  ", "   ", "&nbsp;&nbsp;", "&#xD;"), '', $str);

    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);

    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);

    return $str;
}