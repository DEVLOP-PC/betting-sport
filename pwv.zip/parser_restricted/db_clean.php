<?php
/**
 * Created by PhpStorm.
 * User: amine
 * Date: 28/01/16
 * Time: 13:14
 */

require_once('../db_connect.php');
// Set font
echo "<font size=\"-1\" face=\"arial\">";
// Statement to select the databases
$db_select = 'SHOW DATABASES';
// Query mySQL for the results
$db_result = mysql_query($db_select);
// Loop through all the databases
while ($db_row = mysql_fetch_array($db_result)) {
    // Select currently looped database and continue only if sucessful (have permission to)
    If (mysql_select_db($db_row[0])) {
        // Echo database name
        echo "<br><b>";
        echo $db_row[0];
        echo "</b><br>";
        // Statement to select the tables in the currently looped database
        $tbl_status = 'SHOW TABLE STATUS FROM ' . $db_row[0];
        // Query mySQL for the results
        $tbl_result = mysql_query($tbl_status);
        // Check to see if any tables exist within database
        If(mysql_num_rows($tbl_result)) {
            // Loop through all the tables
            while ($tbl_row = mysql_fetch_array($tbl_result)) {
                // Statement to optimize table
                $opt_table = 'OPTIMIZE TABLE ' . $tbl_row[0];
                // Query mySQL to optimize currently looped table
                $opt_result = mysql_query($opt_table);
                // Echo table name
                echo "&nbsp;&nbsp;<i>";
                echo $tbl_row[0];
                echo "</i><br>";
            } // End table while loop
        } else {
            // Alert that there are no tables within database
            echo "&nbsp;&nbsp;<i>No Tables</i><br>";
        } // End table existance if statement
    } // End database if statement
} // End database while loop
// Alert them that operation was successful
echo "<br><br><b>Above tables successfully optimized!</b>";
// End font
echo "</font>";
?>