<?php
/**
 * Created by PhpStorm.
 * User: amine
 * Date: 21/01/16
 * Time: 18:56
 */
include('includes/db_connect.php');
include('includes/ganon.php');

$sql = "select * from event limit 11,12";
$res = mysqli_query($dbhandle, $sql);

$i = 0;
//while($row = mysqli_fetch_assoc($res)){
    $i++;
$row = mysqli_fetch_assoc($res);
        $eventId = $row['code'];

        $url = "https://ww3.365planetwinall.net/ControlsSkin/OddsEvent.aspx?ShowLinkFastBet=0&showDate=1&showGQ=1&rnd=05131459920667112&EventID=".$eventId."&GroupSep=undefined";
        $agent = "Mozilla/5.0 (X11; U; Linux i686; en-US)
            AppleWebKit/532.4 (KHTML, like Gecko)
            Chrome/4.0.233.0 Safari/532.4";
        $referer = "http://www.google.com/";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_COOKIE, "ISBets_CurrentCulture=11");
        curl_setopt($ch, CURLOPT_USERAGENT, $agent);
        $result = curl_exec($ch);
        curl_close($ch);

        $html = str_get_dom($result);

$divQt = $html('div.divQt', 0);
//echo $divQt->html();

foreach($divQt('table') as $element) {
        echo $element->html(), "<br>\n";

        foreach($element('.cqDateTbl') as $el) {
                echo $el, "<br>\n";
        }
//        echo "<strong>".$element('td.cqDateTbl')->getPlainText()."</strong>";
}

//$i = 0;
//$tables = array();
//
//foreach($divQt('table') as $table) {
//    $tables[] = $table;
//}
//
//echo $tables[2]->html();
//echo "<br><br><br><br><br>";
//
//foreach($tables[2]('td.cqDateTbl') as $table){
//    echo $table->html();
//}





//}

//$eventsArray = array();
//foreach($html('li.VociMenuSport') as $element) {
//    if(is_numeric($cod = str_replace('e', '', $element->id))){
//        $eventsArray[] = $cod;
//    }
//}
//
//date_default_timezone_set('Africa/Tunis');
//$current_timestamp = time();
//
//foreach($eventsArray as $code){
//    echo $code."<br>";
//
//    $sql = "select * from event where code='".$code."'";
//    $res = mysqli_query($dbhandle, $sql);
//    if(mysqli_num_rows ($res) == 0){
//        mysqli_query($dbhandle, "INSERT INTO event (code, crdate, udate) VALUES ('".$code."', '".$current_timestamp."', '".$current_timestamp."')");
//    }
//}


//echo $html;
//print_r($html('div#divMenuSportGSX')) ;