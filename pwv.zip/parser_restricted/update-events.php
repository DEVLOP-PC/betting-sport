#!/usr/bin/php5
<?php
/**
 * Created by PhpStorm.
 * User: amine
 * Date: 21/01/16
 * Time: 18:56
 */
set_time_limit(0);
include('includes/db_connect.php');
include('includes/ganon.php');

//$url = 'http://ww3.365planetwinall.net/Sport/OddsAsync.aspx?EventID=257612,257613,257614,257615,257617,257618,263541,7937,7944,8082,263308,7882,7844,7859,7860,157422';
$url = 'https://ww3.365planetwinall.net/Sport/Groups.aspx?TipoVis=1';
$agent = "Mozilla/5.0 (X11; U; Linux i686; en-US)
            AppleWebKit/532.4 (KHTML, like Gecko)
            Chrome/4.0.233.0 Safari/532.4";
$referer = "http://www.google.com/";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_REFERER, $referer);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIE, "ISBets_CurrentCulture=11");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
$result = curl_exec($ch);
curl_close($ch);

$html = str_get_dom($result);

$eventsArray = array();
foreach($html('li.VociMenuSport') as $element) {
    if(is_numeric($cod = str_replace('e', '', $element->id))){
        $eventsArray[] = $cod;
    }
}

date_default_timezone_set('Africa/Tunis');
$current_timestamp = time();

$i = 0;

foreach($eventsArray as $code){
//    echo $code."<br>";

    $sql = "SELECT * FROM all_events WHERE code=".intval($code);
    $res = mysqli_query($dbhandle, $sql);
    if($res && mysqli_num_rows ($res) == 0 && $i < 50){

        $url = "https://ww3.365planetwinall.net/ControlsSkin/OddsEvent.aspx?ShowLinkFastBet=0&showDate=1&showGQ=1&rnd=05131459920667112&EventID=".$code."&GroupSep=undefined";
        $agent = "Mozilla/5.0 (X11; U; Linux i686; en-US)
            AppleWebKit/532.4 (KHTML, like Gecko)
            Chrome/4.0.233.0 Safari/532.4";
        $referer = "http://www.google.com/";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_COOKIE, "ISBets_CurrentCulture=11");
        curl_setopt($ch, CURLOPT_USERAGENT, $agent);
        $result = curl_exec($ch);
        curl_close($ch);

        $html = str_get_dom($result);

        if($html('span#lblTitolo', 0)){
            $evetName = $html('span#lblTitolo', 0)->getPlainText();
            $evetName = mysqli_real_escape_string($dbhandle, $evetName);

            mysqli_query($dbhandle, "INSERT INTO all_events (code, name, crdate, udate) VALUES ('".intval($code)."', '".$evetName."', '".$current_timestamp."', '".$current_timestamp."')");
            $i++;
        }

    }
}

