#!/usr/bin/php5

<?php
require_once __DIR__ . '/vendor/autoload.php';

require 'vendor/autoload.php';

use PHPHtmlParser\Dom;

include('includes/db_connect.php');
include('includes/ganon.php');
include('includes/functions.php');

date_default_timezone_set('Africa/Tunis');
$current_timestamp = time();


$sql = "SELECT * FROM all_events WHERE (subevents_udate + 900) < ".$current_timestamp." OR subevents_udate = 0 ORDER BY subevents_udate ASC LIMIT 50";
//$sql = "SELECT * FROM all_events WHERE (subevents_udate + 900) < ".$current_timestamp." OR subevents_udate = 0 ORDER BY RAND() ASC LIMIT 50";


//echo $sql;
$resAllEvents = mysqli_query($dbhandle, $sql);


if(mysqli_num_rows ($resAllEvents) > 0) {
    while ($rowAllEvents = mysqli_fetch_assoc($resAllEvents)) {
        $eventId = $rowAllEvents['code'];
        $eventDbId = $rowAllEvents['id'];

        //$eventId = 7950;

        $url = "https://ww3.365planetwinall.net/ControlsSkin/OddsEvent.aspx?ShowLinkFastBet=0&showDate=1&showGQ=1&rnd=05131459920667112&EventID=" . $eventId . "&GroupSep=undefined";
        $agent = "Mozilla/5.0 (X11; U; Linux i686; en-US)
            AppleWebKit/532.4 (KHTML, like Gecko)
            Chrome/4.0.233.0 Safari/532.4";
        $referer = "http://www.google.com/";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_REFERER, $referer);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_COOKIE, "ISBets_CurrentCulture=11");
        curl_setopt($ch, CURLOPT_USERAGENT, $agent);
        $result = curl_exec($ch);
        curl_close($ch);

        $html = str_get_dom($result);

        $divQt = $html('div.divQt', 0)->html();

        $divQttmp = getNodeValueFromClass($result, "divQt");
//        echo $divQttmp, "<p>&nbsp;</p>";

        $dom = new Dom;
        $dom->load($divQttmp);
//echo $divQt->ounterHtml, "<p>&nbsp;</p>";
        foreach ($dom->getElementsByTag('table') as $table) {
            $tableHtml = $table->outerHtml;
//            echo $table->outerHtml, "   eventid=", $eventId, "<br><br><br>";

            if(strlen($table->outerHtml) > 5){

                $domTmp = new Dom;
                $domTmp->load($table->outerHtml);
                $dateHtml = $domTmp->getElementsByClass('cqDateTbl');
                $date = $dateHtml[0]->innerHtml;
//                echo $date, "<p></p><p></p>";

                foreach ($domTmp->getElementsByClass('dgAItem') as $item) {
                    $domItem = new Dom;
                    $domItem->load($item->outerHtml);
                    $codepubHtml = $domItem->getElementsByClass('codInc');
                    $codepub = $codepubHtml[0]->text();
                    $timeHtml = $domItem->getElementsByClass('dtInc');
                    $time = $timeHtml[0]->text();
                    $playersHtml = $domItem->getElementsByClass('nmInc');
                    $players = clean(strip_tags($playersHtml[0]->innerHtml));
                    updateSubEvent($codepub, $players, $date, $time, $eventDbId, $dbhandle);
//                echo $codepub, " ", $date, " ", $time, " ", $players, "<br>";
                }

                foreach ($domTmp->getElementsByClass('dgItem') as $item) {
                    $domItem = new Dom;
                    $domItem->load($item->outerHtml);
                    $codepubHtml = $domItem->getElementsByClass('codInc');
                    $codepub = $codepubHtml[0]->text();
                    $timeHtml = $domItem->getElementsByClass('dtInc');
                    $time = $timeHtml[0]->text();
                    $playersHtml = $domItem->getElementsByClass('nmInc');
                    $players = clean(strip_tags($playersHtml[0]->innerHtml));
                    updateSubEvent($codepub, $players, $date, $time, $eventDbId, $dbhandle);
//                echo $codepub, " ", $date, " ", $time, " ", $players, "<br>";
                }
            }
        }

//Update event udate
        $sql = "UPDATE all_events SET subevents_udate ='" . $current_timestamp . "' WHERE id = '" . $eventDbId . "'";
        $res = mysqli_query($dbhandle, $sql);

    }
}

function updateSubEvent($codepub, $players, $date, $time, $eventId, $dbhandle){
    $timestamp = convertDate($date, $time);

    $codepub = mysqli_real_escape_string($dbhandle, $codepub);
    $players = mysqli_real_escape_string($dbhandle, $players);
    $date = mysqli_real_escape_string($dbhandle, $date);
    $time = mysqli_real_escape_string($dbhandle, $time);
    $eventId = mysqli_real_escape_string($dbhandle, $eventId);

    $sqlD = "DELETE from sub_events where codepub='".$codepub."'";
    mysqli_query($dbhandle, $sqlD)or die(mysqli_error($dbhandle));

    $sql = "INSERT INTO sub_events (codepub, players, date, time, timestamp, event_id, status)
            VALUES ('".$codepub."', '".$players."', '".$date."', '".$time."', '".$timestamp."', '".$eventId."', 1)";
    mysqli_query($dbhandle, $sql)or die(mysqli_error($dbhandle));

}

function clean($str){
    // clean out the \n\r
    $str = str_replace(array("\r\n", "\r", "\n"), '', $str);

    // strip the doctype
    $str = mb_eregi_replace("<!doctype(.*?)>", '', $str);

    // strip out comments
    $str = mb_eregi_replace("<!--(.*?)-->", '', $str);

    // strip out cdata
    $str = mb_eregi_replace("<!\[CDATA\[(.*?)\]\]>", '', $str);

    // strip out <script> tags
    $str = mb_eregi_replace("<\s*script[^>]*[^/]>(.*?)<\s*/\s*script\s*>", '', $str);
    $str = mb_eregi_replace("<\s*script\s*>(.*?)<\s*/\s*script\s*>", '', $str);

    // strip out <style> tags
    $str = mb_eregi_replace("<\s*style[^>]*[^/]>(.*?)<\s*/\s*style\s*>", '', $str);
    $str = mb_eregi_replace("<\s*style\s*>(.*?)<\s*/\s*style\s*>", '', $str);

    // strip out pre-formatted tags
    $str = mb_eregi_replace("<\s*(?:code)[^>]*>(.*?)<\s*/\s*(?:code)\s*>", '', $str);

    // strip out server side scripts
    $str = mb_eregi_replace("(<\?)(.*?)(\?>)", '', $str);

    // strip smarty scripts
    $str = mb_eregi_replace("(\{\w)(.*?)(\})", '', $str);

    // remove extra spaces
    $str = str_replace(array("  ", "   ", "&nbsp;&nbsp;", "&#xD;"), '', $str);

    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);
    if (substr($str,0,1) == " ") $str = substr($str,1);

    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);
    if (substr($str,0,-1) == " ") $str = substr($str,-1);

    return $str;
}


function getNodeValueFromClass($html, $class){
    $doc = new DOMDocument();
    @$doc->loadHTML('<?xml encoding="utf-8" ?>' .$html);
    $divs = $doc->getElementsByTagName('div');
    foreach ($divs as $div) {
        $classes = $div->getAttribute('class');
        if (strpos($classes, $class) !== false) {
            return $div->C14N();
        }
    }
}