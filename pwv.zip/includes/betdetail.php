<?php

if(!isset($_POST['IDCoupon'])){
    return ;
}

require_once('../db_connect.php');


$codeCoupon = $_POST['IDCoupon'];


$gidCoupon = mysqli_query($dbhandle, "SELECT * FROM coupon WHERE code_coupon = '$codeCoupon'");
$rowCoupon = mysqli_fetch_assoc($gidCoupon);

$num_rows = mysqli_num_rows($gidCoupon);
if($num_rows == 0){
    return;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="h_w_h"><title>
        planetwin365
    </title><link rel="SHORTCUT ICON" href="http://planetwin365.com/App_Themes/PlanetWin365/Images/Icons/favicon.ico" type="text/css"></link><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/layout.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/calendar.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/coupon.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/download_card.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/quote.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/WebRadio.css" />



    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<!--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

    <script src="http://planetwin365.com/Scripts/Flash.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/Coupon.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/Common.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/ClickBet.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/App_Themes/Planetwin365/Scripts/odds.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/jquery.cookie.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/jquery.scrollable.min.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/jquery.cycle.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/Scroller/jquery.scrollTo-min.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/Scroller/jquery.serialScroll-min.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/jquery.innerfade.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/jcarousellite_1.0.1.min.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/swfobject.js" type="text/javascript"></script>
    <script src="http://planetwin365.com/Scripts/Session.js" type="text/javascript"></script>




    <script language="javascript" type="text/javascript">
        // variabili specifihe per bookmaker
        var divCouponTopPosition = 0; //Posizione top del coupon, se <=0 disabilita scroll
        var heightFooter = 206 //Altezza footer per far in modo che il coupon non ci vada sopra
        var hideAgentSummary = 1; //1 nasconde inizialmente il riassunto nella defaultlogged
        var themeUrl = 'http://static.planetwin365.com/App_Themes/PlanetWin365/';
        var TVClientID = null;
        var TVClientLimiteCampionati = null;
        var TVClientLimiteCampionatiErr = null;
        var sepDec = ',';
        var ExpandSubEvent = 1;
        var isAnonymous = 'True';
        var bestsellerQT = false;
        var qtaDeleted = false;

        function OpenLiveChat() {
        }

        function OpenWebRadio(url, widthDiv, heightDiv) {
        }

        function scrollToCoupon() {
            setTimeout(function(){
                $('html, body').animate({
                    scrollTop: $("#divCoupon").offset().top }, 250);
                setTimeout(function(){
                    $(".CItems").effect("pulsate", { times:1 }, 2000);
                }, 250);
            }, 250);
        }

        function pulsateCoupon() {
        }


        $(document).ready(function() {

            $("a").on('click', function(e) {
                if( $(this).hasClass( "active" ) ) { }
                else {
                    e.preventDefault;
                    return false;
                }
            });

        });
    </script>

    <script type="text/javascript">
        var sBtnUpdateSaldo = 'h_w_cLogin_btnSaldo';
    </script>

    <script>
        $( document ).ready(function() {
            var isInputSupported = 'placeholder' in document.createElement('input');
            var isTextareaSupported = 'placeholder' in document.createElement('textarea');
            if (!isInputSupported || !isTextareaSupported) {
                $('[placeholder]').focus(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                        input.val('');
                        input.removeClass('placeholder');
                    }
                }).blur(function () {
                    var input = $(this);
                    if (input.val() == '') {
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                        input.data('placeholder', true);
                    } else {
                        input.data('placeholder', false);
                    }
                }).blur().parents('form').submit(function () {
                    $(this).find('[placeholder]').each(function () {
                        var input = $(this);
                        if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                            input.val('');
                        }
                    })
                });
            }

        });
        function pageLoad() {
            if ($('.txtLogin').length>0) {
                $('input:not(.txtLogin), select').bind("focus", function () {
                    preventSavingCredentials();
                });
            }
        }
        function preventSavingCredentials() {
            document.getElementsByClassName('RegTxtPwd')[0].children[0].value = document.getElementById('inputPassword').value;
            document.getElementsByClassName('RegTxtPwd')[0].children[0].type = "text";
            document.getElementById('fakePasswordTxt').value = "";
            document.getElementById('inputPassword').value = "";
        }
    </script>
</head>
<body class="bodyMain Anonymous fr-FR">


<div class="CntSX"><div class="CntDX"><div id="ac_w_PC_PC_panelSquare">

            <span class="noBetFound"></span>
            <div id="ac_w_PC_PC_panel_DataGrid">

                <div class="NormalPageContent">
                    <table align="center" cellpadding="0" cellspacing="0" width="100%">
                        <tbody><tr>
                            <td colspan="4">
                                <table align="center" cellpadding="0" cellspacing="1" width="100%">
                                    <tbody><tr>
                                        <td class="SectionTitle" colspan="4">Coupon</td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx" width="40%">Code coupon</td>
                                        <td class="cellaDx"><?php echo $codeCoupon;?></td>
                                        <td class="cellaSx">&nbsp;</td>
                                        <td class="cellaDx">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx">Date</td>
                                        <td class="cellaDx">
                                            <?php
                                            $timestamp = strtotime($rowCoupon['date']);
                                            $date = new DateTime();
                                            $date->setTimestamp($timestamp);
                                            echo $date->format('d/m/Y H:i:s');
                                            ?>
                                        </td>
                                        <td class="cellaSx">&nbsp;</td>
                                        <td class="cellaDx">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx">Type de pari</td>
                                        <td class="cellaDx"><?php echo $rowCoupon['type_pari'];?></td>
                                        <td class="cellaSx">&nbsp;</td>
                                        <td class="cellaDx">&nbsp;</td>
                                    </tr>
                                    </tbody></table>

                                <!-- Dettagli Antiriciclaggio -->


                                <!-- Tabella che visualizza Singole/Multiple -->
                                <table id="ac_w_PC_PC_tbl_DettagliScommessa" align="center" cellpadding="0" cellspacing="1" width="100%">
                                    <tbody><tr>
                                        <td class="SectionTitle" colspan="2">Détail</td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx" width="40%">Etat</td>
                                        <td class="cellaDx">
                                            <?php if($rowCoupon['etat_pari'] == 'running'){?><span class="detScoEsitoIncorso">En cours</span><?php }?>
                                            <?php if($rowCoupon['etat_pari'] == 'win'){?><span class="detScoEsitoVin">Gagnant</span><?php }?>
                                            <?php if($rowCoupon['etat_pari'] == 'lost'){?><span class="detScoEsitoPer">Perdant</span><?php }?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx" width="40%"><span class="detScoIG">Montant joué</span></td>
                                        <td class="cellaDx">
                                                                <span class="detScoIG">
																<?php if($rowCoupon['type_pari']=="intégrale"){?>
                                                                    <?php echo number_format($rowCoupon['amount']/$rowCoupon['multiplicateur'], 2, ',', '');?> x <?php echo $rowCoupon['multiplicateur'];?> = <?php echo number_format($rowCoupon['amount'], 2, ',', '');?>&nbsp;&euro;</span>
                                            <?php }?>
                                            <?php if($rowCoupon['type_pari']=="multiple"){?>
																<?php echo $rowCoupon['amount'];?>&nbsp;&euro;</span>
                                                                <?php }?>
                                            <div></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx">Bonus</td>
                                        <td class="cellaDx">
                                            <?php if($rowCoupon['type_pari']=="intégrale"){?>
                                                <?php echo $rowCoupon['bonus_min'];?> / <?php echo $rowCoupon['bonus_max'];?>&nbsp;€&nbsp;
                                            <?php }?>
                                            <?php if($rowCoupon['type_pari']=="multiple"){?>
															<?php echo $rowCoupon['bonus'];?>&nbsp;&euro;</span>
															<?php }?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="cellaSx" width="40%"><span class="detScoVP">Gain Pot. Min/Max Pot.</span></td>
                                        <td class="cellaDx"><span class="detScoVP">
															<?php if($rowCoupon['type_pari']=="intégrale"){?>
                                                                <?php echo $rowCoupon['gain_pot_min'];?> / <?php echo $rowCoupon['gain_pot_max'];?>&nbsp;€
                                                            <?php }?>
                                                <?php if($rowCoupon['type_pari']=="multiple"){?>
                                                <?php echo $rowCoupon['gain_pot'];?>&nbsp;&euro;</span>
                                            <?php }?>
                                            </span></td>
                                    </tr>
                                    </tbody></table>


                                <!-- Dettagli Pagamento -->




                            </td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <!-- Tabella che visualizzo quando c'è un sistema -->

                            </td>
                        </tr>

                        <tr>
                            <td colspan="4">

                            </td>
                        </tr>
                        </tbody></table>
                </div>

                <div class="RiquadroNews"><div class="TopSX"><div class="TopDX"></div></div><div class="Cnt"><div>

                            <table align="center" border="0" cellpadding="0" cellspacing="1" width="100%">
                                <tbody><tr>
                                    <td class="SectionTitle">Liste événements</td>
                                </tr>
                                </tbody></table>
                            <div>
                                <table class="dgStyle" id="ac_w_PC_PC_dg_ElencoEventi" style="border-width:0px;border-style:None;width:100%;border-collapse:collapse;" align="Center" border="0" cellspacing="0">
                                    <tbody>
                                    <tr class="dgSubHdrStyle">
                                        <th scope="col">Evénement</th><th scope="col">Date début</th><th scope="col">Type</th><th scope="col">HND</th><th scope="col">Cote</th><th scope="col">Fixe</th><th scope="col">Résultat</th><th scope="col">Résultat</th>
                                    </tr>


                                    <?php
                                    if($rowCoupon['type_pari']=="intégrale"){
                                        $couponDbId = $rowCoupon['id'];

                                        $sqlIntgEvents = "SELECT e.* FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId'
                                  GROUP BY e.codepub HAVING count(*) >1";

                                        $resIntgEvents = mysqli_query($dbhandle, $sqlIntgEvents) or die(mysqli_error($dbhandle));

                                        while($rowIntgEvents = mysqli_fetch_assoc($resIntgEvents)){
                                            $codePubInt = $rowIntgEvents['codepub'];
                                            $sqlIntgOcEvents = "SELECT e.* FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId'
                                    AND codepub='$codePubInt'";

                                            $resIntgOcEvents = mysqli_query($dbhandle, $sqlIntgOcEvents) or die(mysqli_error($dbhandle));
                                            if(mysqli_num_rows ($resIntgOcEvents) > 0){
                                                while($rowIntgOcEvents = mysqli_fetch_assoc($resIntgOcEvents)){

                                                    $codepub = $rowIntgOcEvents['codepub'];
                                                    $players = $rowIntgOcEvents['players'];
                                                    $sqlParserE = "SELECT * FROM all_events
                                                                    INNER JOIN sub_events ON all_events.id = sub_events.event_id
                                                                    WHERE codepub=".intval($codepub);

//                                                                echo $sqlParserE, "<br>";
                                                    $resParserE = mysqli_query($dbhandle, $sqlParserE)or die(mysqli_error($dbhandle));
                                                    $rowParserE = mysqli_fetch_assoc($resParserE);

                                                    ?>
                                                    <tr class="dgItemStyle">
                                                        <!--                                                            <td>--><?php //echo $rowParserE['name']; ?><!-- - --><?php //echo $rowIntgOcEvents['players']; ?><!--</td>-->
                                                        <td><?php echo $rowIntgOcEvents['event']; ?> - <?php echo $rowIntgOcEvents['players']; ?></td>
                                                        <td align="center">
                                                            <?php
                                                            $date = new DateTime();
                                                            $date->setTimestamp($rowIntgOcEvents['timestamp']);
                                                            echo $date->format('Y-m-d H:i:s');
                                                            ?>
                                                        </td>
                                                        <td align="center"><?php echo $rowIntgOcEvents['signe']; ?></td>
                                                        <td align="center">&nbsp;&nbsp;</td>
                                                        <td align="center"><?php echo $rowIntgOcEvents['cote']; ?></td>
                                                        <td align="center"></td>
                                                        <td style="white-space:nowrap;" align="center">
                                                            <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato1" title="Final Result"><?php echo $rowIntgOcEvents['score']; ?></span>
                                                            <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato2"></span>
                                                            <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato3"></span></td>
                                                        <td align="center">
                                                            <?php
                                                            if($rowIntgOcEvents['status'] == 1){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif";
                                                            }if($rowIntgOcEvents['status'] == 2){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif";
                                                            }if($rowIntgOcEvents['status'] == 0){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_0.gif";
                                                            }if($rowIntgOcEvents['status'] == 3){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_4.gif";
                                                            }
                                                            ?>
                                                            <img src="<?php echo $imgSrc; ?>" style="border-width:0px;">

                                                        </td>
                                                    </tr>

                                                <?php }}}?>

                                        <?php
                                        $couponDbId = $rowCoupon['id'];
//                                                        $sqlIntgOcEvents = "SELECT e.*, ce1.sorting FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId' order by ce1.sorting, codepub";
                                        $sqlIntgEvents = "SELECT e.* FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId'
                                  GROUP BY codepub HAVING count(*) =1 order by codepub";

                                        $resIntgEvents = mysqli_query($dbhandle, $sqlIntgEvents) or die(mysqli_error($dbhandle));

                                        while($rowIntgEvents = mysqli_fetch_assoc($resIntgEvents)){
                                            $codePubInt = $rowIntgEvents['codepub'];
                                            $sqlIntgOcEvents = "SELECT e.* FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId'
                                    AND codepub='$codePubInt'";

                                            $resIntgOcEvents = mysqli_query($dbhandle, $sqlIntgOcEvents) or die(mysqli_error($dbhandle));
                                            if(mysqli_num_rows ($resIntgOcEvents) > 0){
                                                while($rowIntgOcEvents = mysqli_fetch_assoc($resIntgOcEvents)){

                                                    $codepub = $rowIntgOcEvents['codepub'];
                                                    $players = $rowIntgOcEvents['players'];
                                                    $sqlParserE = "SELECT * FROM all_events
                                                                    INNER JOIN sub_events ON all_events.id = sub_events.event_id
                                                                    WHERE codepub=".intval($codepub);

//                                                                echo $sqlParserE, "<br>";
                                                    $resParserE = mysqli_query($dbhandle, $sqlParserE)or die(mysqli_error($dbhandle));
                                                    $rowParserE = mysqli_fetch_assoc($resParserE);

////                                                                echo $rowParserE['name'];
//
//                                                                $parserEventId = $rowParserE['id'];
////                                                                echo $parserEventId, "<br>";
//
//                                                                $sqlParser = "select * from all_events where id=".intval($parserEventId);
//                                                                $resParser = mysqli_query($dbhandle, $sqlParser)or die(mysqli_error($dbhandle));
//                                                                $rowParser = mysqli_fetch_assoc($resParser);
                                                    ?>
                                                    <tr class="dgItemStyle">
                                                        <!--                                                            <td>--><?php //echo $rowParserE['name']; ?><!-- - --><?php //echo $rowIntgOcEvents['players']; ?><!--</td>-->
                                                        <td><?php echo $rowIntgOcEvents['event']; ?> - <?php echo $rowIntgOcEvents['players']; ?></td>
                                                        <td align="center">
                                                            <?php
                                                            $date = new DateTime();
                                                            $date->setTimestamp($rowIntgOcEvents['timestamp']);
                                                            echo $date->format('Y-m-d H:i:s');
                                                            ?>
                                                        </td>
                                                        <td align="center"><?php echo $rowIntgOcEvents['signe']; ?></td>
                                                        <td align="center">&nbsp;&nbsp;</td>
                                                        <td align="center"><?php echo $rowIntgOcEvents['cote']; ?></td>
                                                        <td align="center"></td>
                                                        <td style="white-space:nowrap;" align="center">
                                                            <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato1" title="Final Result"><?php echo $rowIntgOcEvents['score']; ?></span>
                                                            <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato2"></span>
                                                            <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato3"></span></td>
                                                        <td align="center">
                                                            <?php
                                                            if($rowIntgOcEvents['status'] == 1){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif";
                                                            }if($rowIntgOcEvents['status'] == 2){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif";
                                                            }if($rowIntgOcEvents['status'] == 0){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_0.gif";
                                                            }if($rowIntgOcEvents['status'] == 3){
                                                                $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_4.gif";
                                                            }
                                                            ?>
                                                            <img src="<?php echo $imgSrc; ?>" style="border-width:0px;">

                                                        </td>
                                                    </tr>

                                                <?php }}}}?>

                                    <?php
                                    if($rowCoupon['type_pari']=="multiple"){
                                        $couponDbId = $rowCoupon['id'];
                                        $sqlIntgOcEvents = "SELECT e.*, ce1.sorting FROM events e INNER JOIN coupon_events ce1 on e.id = ce1.id_foreign where ce1.id_local='$couponDbId' order by ce1.sorting";


                                        $resIntgOcEvents = mysqli_query($dbhandle, $sqlIntgOcEvents) or die(mysqli_error($dbhandle));
                                        if(mysqli_num_rows ($resIntgOcEvents) > 0){
                                            while($rowIntgOcEvents = mysqli_fetch_assoc($resIntgOcEvents)){

                                                $codepub = $rowIntgOcEvents['codepub'];
                                                $players = $rowIntgOcEvents['players'];
                                                $sqlParserE = "SELECT * FROM all_events
                                                                    INNER JOIN sub_events ON all_events.id = sub_events.event_id
                                                                    WHERE codepub=".intval($codepub);

//                                                                echo $sqlParserE, "<br>";
                                                $resParserE = mysqli_query($dbhandle, $sqlParserE)or die(mysqli_error($dbhandle));
                                                $rowParserE = mysqli_fetch_assoc($resParserE);

                                                ?>
                                                <tr class="dgItemStyle">
                                                    <!--                                                            <td>--><?php //echo $rowParserE['name']; ?><!-- - --><?php //echo $rowIntgOcEvents['players']; ?><!--</td>-->
                                                    <td><?php echo $rowIntgOcEvents['event']; ?> - <?php echo $rowIntgOcEvents['players']; ?></td>
                                                    <td align="center">
                                                        <?php
                                                        $date = new DateTime();
                                                        $date->setTimestamp($rowIntgOcEvents['timestamp']);
                                                        echo $date->format('Y-m-d H:i:s');
                                                        ?>
                                                    </td>
                                                    <td align="center"><?php echo $rowIntgOcEvents['signe']; ?></td>
                                                    <td align="center">&nbsp;&nbsp;</td>
                                                    <td align="center"><?php echo $rowIntgOcEvents['cote']; ?></td>
                                                    <td align="center"></td>
                                                    <td style="white-space:nowrap;" align="center">
                                                        <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato1" title="Final Result"><?php echo $rowIntgOcEvents['score']; ?></span>
                                                        <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato2"></span>
                                                        <span id="ac_w_PC_PC_dg_ElencoEventi_ctl02_labelRisultato3"></span></td>
                                                    <td align="center">
                                                        <?php
                                                        if($rowIntgOcEvents['status'] == 1){
                                                            $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif";
                                                        }if($rowIntgOcEvents['status'] == 2){
                                                            $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif";
                                                        }if($rowIntgOcEvents['status'] == 0){
                                                            $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_0.gif";
                                                        }if($rowIntgOcEvents['status'] == 3){
                                                            $imgSrc = "http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_4.gif";
                                                        }
                                                        ?>
                                                        <img src="<?php echo $imgSrc; ?>" style="border-width:0px;">

                                                    </td>
                                                </tr>

                                            <?php }}}?>

                                    </tbody></table>
                            </div>

                            

                            <table class="SearchContainerStyle">
                                <tbody><tr class="SearchSectionStyle">
                                    <td class="SearchControlsStyle">
                                        <table class="SearchControlsContainerStyle tablespacing">
                                            <tbody><tr>
                                                <td class="SearchControlDesc" style="text-align:left; padding:0px auto;">Résultat:</td>
                                                <td><img id="ac_w_PC_PC_imgLegEsito1" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif" style="border-width:0px;"></td>
                                                <td>Gagnant</td>
                                                <td><img id="ac_w_PC_PC_imgLegEsito2" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif" style="border-width:0px;"></td>
                                                <td>Perdant</td>
                                                <td><img id="ac_w_PC_PC_imgLegEsito3" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_10.gif" style="border-width:0px;"></td>
                                                <td>Mi-gagnant</td>
                                                <td><img id="ac_w_PC_PC_Image2" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_11.gif" style="border-width:0px;"></td>
                                                <td>Mi-perdant</td>
                                                <td><img id="ac_w_PC_PC_imgLegEsito4" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseDettaglioEsito_4.gif" style="border-width:0px;"></td>
                                                <td>Gagnant avec la cote 1 (valide pour le bonus)</td>
                                                <!--<td style='display:none;'><img id="ac_w_PC_PC_imgLegStatoCouponDaValidare" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/CouponDaValidare.png" style="border-width:0px;" /></td>
                                                <td style='display:none;'>Da Validare</td>-->
                                                <td><img id="ac_w_PC_PC_imgLegEsito5" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_4.gif" style="border-width:0px;"></td>
                                                <td>Nul (non valide pour le bonus)</td>
                                            </tr>
                                            </tbody></table>
                                    </td>
                                </tr>
                                </tbody></table>


                        </div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>

            </div>



        </div></div></div>
<div class="divCheckCpnDisclaimer">
    Bet correctly registered on planetwin365 Database
</div>
</body>
</html>
