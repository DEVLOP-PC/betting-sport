<?php

function stringToNumber($string){
    return str_replace(',', '.', $string);
}

function numberToString($number){
    return str_replace('.', ',', $number);
}

?>