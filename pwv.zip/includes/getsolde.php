<?php
session_start();

require_once($_SERVER['DOCUMENT_ROOT'].'/db_connect.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/includes/functions.php');

$identificateur = $_SESSION['pw_logged_user'];

$gid = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
$row = mysqli_fetch_assoc($gid);


?>
<div class="TitoloValuta" >
                    <span id = "hl_w_cLogin_lblValutaCaption" > Valuta</span >:
                    <span id = "hl_w_cLogin_lblValuta" > EUR</span >
                </div >
                <div class="TitoloSaldo" >
                    <span id = "hl_w_cLogin_lblDisponibilitaCaption" > Disponibilité</span >:
                    <span id = "hl_w_cLogin_lblDisponibilita" ><?php echo numberToString(number_format($row['solde'], 2, '.', ''));?>&nbsp;€</span>
<input name="hl$w$cLogin$btnSaldo" id="hl_w_cLogin_btnSaldo"
       src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/icons/Refresh_ico.png"
       alt="Mettre à jour solde" style="border-width:0px;" align="absmiddle" type="image">
</div>
<div class="divSaldoUtente">
    <span id="hl_w_cLogin_lblSaldoCaption">Solde</span>:
    <span id="hl_w_cLogin_lblSaldo"><?php echo numberToString(number_format($row['solde'], 2, '.', '')); ?>
        &nbsp;€</span>


</div>