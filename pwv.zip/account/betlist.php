<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:../login.php");
}

require_once('../db_connect.php');

$identificateur = $_SESSION['pw_logged_user'];

$gid = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
$row = mysqli_fetch_assoc($gid);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="h_w_h"><title>
        planetwin365
    </title><link rel="SHORTCUT ICON" href="http://planetwin365.com/App_Themes/PlanetWin365/Images/Icons/favicon.ico" type="text/css"></link><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/layout.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/calendar.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/coupon.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/download_card.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/quote.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/WebRadio.css" />



    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

    <script src="http://ww3.365planetwinall.net/Scripts/Flash.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Coupon.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Common.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/ClickBet.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/odds.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cookie.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.scrollable.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cycle.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.scrollTo-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.serialScroll-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.innerfade.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jcarousellite_1.0.1.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/swfobject.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Session.js" type="text/javascript"></script>




    <script language="javascript" type="text/javascript">
        // variabili specifihe per bookmaker
        var divCouponTopPosition = 0; //Posizione top del coupon, se <=0 disabilita scroll
        var heightFooter = 206 //Altezza footer per far in modo che il coupon non ci vada sopra
        var hideAgentSummary = 1; //1 nasconde inizialmente il riassunto nella defaultlogged
        var themeUrl = 'http://static.planetwin365.com/App_Themes/PlanetWin365/';
        var TVClientID = null;
        var TVClientLimiteCampionati = null;
        var TVClientLimiteCampionatiErr = null;
        var sepDec = ',';
        var ExpandSubEvent = 1;
        var isAnonymous = 'True';
        var bestsellerQT = false;
        var qtaDeleted = false;

        function OpenLiveChat() {
        }

        function OpenWebRadio(url, widthDiv, heightDiv) {
        }

        function scrollToCoupon() {
            setTimeout(function(){
                $('html, body').animate({
                    scrollTop: $("#divCoupon").offset().top }, 250);
                setTimeout(function(){
                    $(".CItems").effect("pulsate", { times:1 }, 2000);
                }, 250);
            }, 250);
        }

        function pulsateCoupon() {
        }


        $(document).ready(function() {

            $("a").on('click', function(e) {
                if( $(this).hasClass( "active" ) ) { }
                else {
                    e.preventDefault;
                    return false;
                }
            });

        });
    </script>

    <script type="text/javascript">
        var sBtnUpdateSaldo = 'h_w_cLogin_btnSaldo';
    </script>

    <script>
        $( document ).ready(function() {
            var isInputSupported = 'placeholder' in document.createElement('input');
            var isTextareaSupported = 'placeholder' in document.createElement('textarea');
            if (!isInputSupported || !isTextareaSupported) {
                $('[placeholder]').focus(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                        input.val('');
                        input.removeClass('placeholder');
                    }
                }).blur(function () {
                    var input = $(this);
                    if (input.val() == '') {
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                        input.data('placeholder', true);
                    } else {
                        input.data('placeholder', false);
                    }
                }).blur().parents('form').submit(function () {
                    $(this).find('[placeholder]').each(function () {
                        var input = $(this);
                        if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                            input.val('');
                        }
                    })
                });
            }

        });
        function pageLoad() {
            if ($('.txtLogin').length>0) {
                $('input:not(.txtLogin), select').bind("focus", function () {
                    preventSavingCredentials();
                });
            }
        }
        function preventSavingCredentials() {
            document.getElementsByClassName('RegTxtPwd')[0].children[0].value = document.getElementById('inputPassword').value;
            document.getElementsByClassName('RegTxtPwd')[0].children[0].type = "text";
            document.getElementById('fakePasswordTxt').value = "";
            document.getElementById('inputPassword').value = "";
        }
    </script>
</head>
<body class="bodyMain Anonymous fr-FR">


<div>

    <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="15C4A0A3" />
</div>
<div style="position:absolute; top:0; left:0; width:5px; height:5px;" title='SRVM-WEB09'></div>


<script type="text/javascript">
    $('.bodyMain').css('background-image', 'url(../1/1.jpg)');


</script>






<div id="sessionEndWarning"> </div>
<div class="divMainHome">
    <!--HEADER-->
    <?php include("../header.php");?>
    <!--MAIN-->








    <div id="divMain">
        <div id="divContent">

            <table id="tblMainContent" cellpadding="0" cellspacing="0">
                <tbody><tr><td><div class="spacer5"></div></td></tr>
                <tr><td class="tdCNMaxAccount"><div id="MainContent">

                            <script language="javascript" type="text/javascript">
                                $(document).ready(function() {
                                    initializePopup("popupAnnullamentoClose", "popupAnnullamento", "backgroundPopup");
                                });

                                function showPopup(IDCoupon) {

                                    centerPopup("popupAnnullamento", "backgroundPopup");

                                    var PathIndi;
                                    PathIndi = 'BetRefuse.aspx'



                                    $("iframe[id=ifPopup]").attr("src",PathIndi + "?IDCoupon=" + IDCoupon) ;

                                    loadPopup("popupAnnullamento", "backgroundPopup");

                                }

                            </script>



                            <div class="Riquadro"><div class="TopSX"><div class="TopDX"><h3>Liste paris</h3></div></div><div class="CntSX"><div class="CntDX"><div id="ac_w_PC_PC_panelSquare">

                                            <div class="RiquadroSrc"><div class="TopSX"><div class="TopDX"></div></div><div class="Cnt"><div>

                                                        <div id="ac_w_PC_PC_valSummary" class="ValidationSummary" style="color:Red;display:none;">

                                                        </div>

                                                        <div id="ac_w_PC_PC_panForm" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ac_w_PC_PC_btnAvanti')">
                                                            <script>
                                                                $(function() {
                                                                    $( "#date_de, #date_a" ).datepicker({
                                                                        altField: "#datepicker",
                                                                        closeText: 'Fermer',
                                                                        prevText: 'Précédent',
                                                                        nextText: 'Suivant',
                                                                        currentText: 'Aujourd\'hui',
                                                                        monthNames: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
                                                                        monthNamesShort: ['Janv.', 'Févr.', 'Mars', 'Avril', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'],
                                                                        dayNames: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
                                                                        dayNamesShort: ['Dim.', 'Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.'],
                                                                        dayNamesMin: ['D', 'L', 'M', 'M', 'J', 'V', 'S'],
                                                                        weekHeader: 'Sem.',
                                                                        dateFormat: 'yy-mm-dd',
                                                                        maxDate: '+0D'
                                                                    });
                                                                });
                                                            </script>
                                                            <div class="SearchTitleStyle">
                                                                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                    <tbody><tr>
                                                                        <td>
                                                                            Filters
                                                                        </td>
                                                                        <td class="SearchMinimizeStyle">
                                                                            <a href="javascript:ShowHideSearch('tblSearch', 'ac_w_PC_PC_imgHide', 'ac_w_PC_PC_imgShow');"><img id="ac_w_PC_PC_imgHide" src="../App_Themes/PlanetWin365/Images/Icons/Minimizza_ico.png" alt="Hide Panel" style="border-width:0px;"><img id="ac_w_PC_PC_imgShow" src="../App_Themes/PlanetWin365/Images/Icons/Ingrandire_ico.png" alt="Show Panel" style="border-width:0px;display:none;"></a>
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </div>
                                                            <table id="tblSearch" class="SearchContainerStyle">
                                                                <tbody><tr class="SearchSectionStyle">
                                                                    <td class="SearchDescStyle">

                                                                    </td>
                                                                    <td class="SearchControlsStyle">



                                                                        <form action="betlist.php" method="GET" id="search">
                                                                            <table width="100%">
                                                                                <tbody><tr>
                                                                                    <td class="SearchControlDesc" width="20%">
                                                                                        Du
                                                                                    </td>
                                                                                    <td width="30%">

                                                                                        <input name="de" value="<?php echo date("Y-m-d", strtotime("- 10 days"));?>" id="date_de" class="textbox" style="width:75px;" type="text">

                                                                                    </td>
                                                                                    <td class="SearchControlDesc" width="20%">
                                                                                        Au
                                                                                    </td>
                                                                                    <td width="30%">


                                                                                        <table cellpadding="0" cellspacing="0">
                                                                                            <tbody><tr>
                                                                                                <td>
                                                                                                    <input name="a" value="<?php echo date("Y-m-d", strtotime("today"));?>" id="date_a" class="textbox" style="width:75px;" type="text">
                                                                                                </td>
                                                                                                <td align="center" width="25px">
                                                                                                </td>
                                                                                                <td>

                                                                                                </td>

                                                                                            </tr>
                                                                                            </tbody></table>


                                                                                    </td>
                                                                                </tr>
                                                                                </tbody></table>
                                                                    </td>
                                                                </tr>

                                                                <tr class="SearchSectionStyle">
                                                                    <td class="SearchDescStyle">
                                                                        Coupon
                                                                    </td>
                                                                    <td class="SearchControlsStyle">
                                                                        <table class="SearchControlsContainerStyle">
                                                                            <tbody><tr>
                                                                                <td class="SearchControlDesc" width="20%">
                                                                                    Code coupon
                                                                                </td>
                                                                                <td width="30%">
                                                                                    <input name="code_coupon" id="ac_w_PC_PC_txtCodiceCoupon" class="textbox" style="width:175px;" type="text" value="<?php if(isset($_GET['code_coupon'])) echo $_GET['code_coupon'];?>">
                                                                                </td>
                                                                                <td class="SearchControlDesc" width="20%">
                                                                                    Résultat
                                                                                </td>
                                                                                <td width="30%">
                                                                                    <select name="resultat" id="ac_w_PC_PC_ddlEsito" class="dropdown" style="width:80px;">
                                                                                        <option value="" selected></option>
                                                                                        <option value="0" <?php if(isset($_GET['resultat']) && $_GET['resultat'] == 0) echo "selected"?> >En cours</option>
                                                                                        <option value="1" <?php if(isset($_GET['resultat']) && $_GET['resultat'] == 1) echo "selected"?>>Gagnant</option>
                                                                                        <option value="2" <?php if(isset($_GET['resultat']) && $_GET['resultat'] == 2) echo "selected"?>>Perdant</option>
                                                                                    </select>
                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>
                                                                </tbody></table>
                                                            </form>
                                                            <table class="SearchButtonsStyle">
                                                                <tbody><tr>
                                                                    <td></td>
                                                                    <td class="tdSrcSX">
                                                                        <input name="ac$w$PC$PC$btnCancella" value="Effacer" onclick="" id="ac_w_PC_PC_btnCancella" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')" type="submit">
                                                                    </td>
                                                                    <td class="tdSrcDX">
                                                                        <input name="ac$w$PC$PC$btnAvanti" value="Continuer" onclick="" id="ac_w_PC_PC_btnAvanti" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')" type="submit">
                                                                    </td>
                                                                </tr>
                                                                </tbody></table>
                                                            <script type="text/javascript">
                                                                $(document).ready(function() {

                                                                    $("#ac_w_PC_PC_btnAvanti").on('click', function(e) {

                                                                        $("#h_w_ctl18_UpdateProgress").show();
                                                                        $("#search").submit();

                                                                    });



                                                                    $("#ac_w_PC_PC_btnCancella").on('click', function(e) {

                                                                        $("#h_w_ctl18_UpdateProgress").show();
                                                                        window.location="betlist.php";
//                                                                        $("#search").submit();

                                                                    });

                                                                });
                                                            </script>
                                                        </div>
                                                        <div class="spacer9"></div>
                                                        <div class="SearchTitleStyle">
                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                <tbody><tr>
                                                                    <td>Totals</td>
                                                                    <td class="SearchMinimizeStyle">
                                                                        <a href="javascript:ShowHideSearch('tblSearch2', 'ac_w_PC_PC_imgShow2', 'ac_w_PC_PC_imgHide2');"><img id="ac_w_PC_PC_imgHide2" src="../App_Themes/PlanetWin365/Images/Icons/Minimizza_ico.png" alt="Hide Panel" style="border-width:0px;"><img id="ac_w_PC_PC_imgShow2" src="../App_Themes/PlanetWin365/Images/Icons/Ingrandire_ico.png" alt="Show Panel" style="border-width:0px;display:none;"></a>
                                                                    </td>
                                                                </tr>
                                                                </tbody></table>
                                                        </div>
                                                        <?php
                                                        $pageFilters = array();

                                                        $dateFilter = "";
                                                        if(isset($_GET['de']) && isset($_GET['a'])){
                                                            $de = $_GET['de']." 00:00:00";
//                                                            $date = DateTime::createFromFormat('Y-m-d',$de);
//                                                            echo $date->format("Y-m-d H:i:s");
                                                            $a = $_GET['a']." 59:59:59";
                                                            $dateFilter = " AND date >= '$de' AND date <= '$a'";
                                                            $pageFilters[] = "de=".$_GET['de'];
                                                            $pageFilters[] = "a=".$_GET['a'];
                                                        }

                                                        $resultatFilter = "";
                                                        if(isset($_GET['resultat']) && strlen($_GET['resultat']) > 0){
                                                            switch($_GET['resultat']){
                                                                case 0 : $rest = "running";break;
                                                                case 1 : $rest = "win";break;
                                                                case 2 : $rest = "lost";break;
                                                            }
                                                            $resultatFilter = " AND etat_pari='".$rest."'";
                                                            $pageFilters[] = "resultat=".$_GET['resultat'];
                                                        }

                                                        $codeCouponFilter = "";
                                                        if(isset($_GET['code_coupon']) && strlen($_GET['code_coupon']) > 0){
                                                            $codeCouponFilter = " AND code_coupon='".$_GET['code_coupon']."'";
                                                            $dateFilter = "";
                                                            $resultatFilter = "";
                                                        }



                                                        $usagerId = $row['identificateur'];

                                                        //Pagination
                                                        $messagesParPage=15; //Nous allons afficher 5 messages par page.

                                                        //Une connexion SQL doit être ouverte avant cette ligne...
                                                        $retour_total=mysqli_query($dbhandle, "SELECT COUNT(*) AS total FROM coupon WHERE usager = '$usagerId' $dateFilter $codeCouponFilter $resultatFilter"); //Nous récupérons le contenu de la requête dans $retour_total
                                                        $donnees_total=mysqli_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
                                                        $total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

                                                        //Nous allons maintenant compter le nombre de pages.
                                                        $nombreDePages=ceil($total/$messagesParPage);

                                                        if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
                                                        {
                                                            $pageActuelle=intval($_GET['page']);

                                                            if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
                                                            {
                                                                $pageActuelle=$nombreDePages;
                                                            }
                                                        }
                                                        else // Sinon
                                                        {
                                                            $pageActuelle=1; // La page actuelle est la n°1
                                                        }

                                                        $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire

                                                        $sqlQuery = "SELECT * FROM coupon WHERE usager = '$usagerId' $dateFilter $codeCouponFilter $resultatFilter ORDER BY date DESC LIMIT $premiereEntree, $messagesParPage";
                                                        $parisRes = mysqli_query($dbhandle, $sqlQuery);
                                                        $pariIndex = 0;
                                                        ?>
                                                        <table id="tblSearch2" class="SearchContainerStyle">
                                                            <tbody><tr class="SearchSectionStyle">
                                                                <td class="SearchDescStyle">
                                                                    <div style="position:relative;">
                                                                        No. Paris
                                                                        <div class="Dati"><span id="ac_w_PC_PC_lblNumSco"><?php echo $total;?></span></div>
                                                                    </div>
                                                                </td>
                                                                <td class="SearchControlsStyle"></td>
                                                            </tr>


                                                            </tbody></table>

                                                        <table class="SearchContainerStyle">
                                                            <tbody><tr class="SearchSectionStyle">
                                                                <td class="SearchDescStyle">
                                                                    Légende
                                                                </td>
                                                                <td class="SearchControlsStyle">
                                                                    <table class="SearchControlsContainerStyle">
                                                                        <tbody><tr>
                                                                            <td class="SearchControlDesc" style="text-align:left">Résultat:</td>
                                                                            <td><img id="ac_w_PC_PC_imgLegEsito1" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif" style="border-width:0px;"></td>
                                                                            <td>Gagnant</td>
                                                                            <td><img id="ac_w_PC_PC_imgLegEsito2" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif" style="border-width:0px;"></td>
                                                                            <td>Perdant</td>
                                                                            <td><img id="ac_w_PC_PC_imgLegEsito3" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_3.gif" style="border-width:0px;"></td>
                                                                            <td>En cours</td>
                                                                            <td><img id="ac_w_PC_PC_imgLegEsito4" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_4.gif" style="border-width:0px;"></td>
                                                                            <td>Annulé</td>
                                                                            <td style="display:none;"><img id="ac_w_PC_PC_imgLegStatoCouponDaValidare" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/CouponDaValidare.png" style="border-width:0px;"></td>
                                                                            <td style="display:none;">Da Validare</td>
                                                                            <td><img id="ac_w_PC_PC_imgLegEsito5" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_5.gif" style="border-width:0px;"></td>
                                                                            <td>En acceptation</td>
                                                                        </tr>
                                                                        </tbody></table>
                                                                </td>
                                                            </tr>
                                                            </tbody></table>

                                                    </div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>
                                            <div class="divDg">
                                                <input name="ac$w$PC$PC$ImportoTotPagina" id="ac_w_PC_PC_ImportoTotPagina" value="9.53" type="hidden"><input name="ac$w$PC$PC$VincitaTotPagina" id="ac_w_PC_PC_VincitaTotPagina" value="0.00" type="hidden">
                                                <div>
                                                    <table class="dgStyle" cellspacing="0" border="0" id="ac_w_PC_PC_grid" style="border-width:0px;border-style:None;width:100%;border-collapse:collapse;">
                                                        <tbody>
                                                        <tr class="dgHdrStyle">
                                                            <th scope="col">Coupon</th>
                                                            <th scope="col">Usager</th>
                                                            <th scope="col">Type de pari</th>
                                                            <th scope="col">Date</th>
                                                            <th scope="col">Date résultat</th>
                                                            <th class="dgHdrImporti" scope="col">Montant</th>
                                                            <th scope="col">Résultat</th>
                                                            <th class="dgHdrImporti" scope="col">Gain</th>
                                                        </tr>

                                                        <?php

                                                        while($parisRow = mysqli_fetch_assoc($parisRes)){
                                                            if ( $pariIndex & 1 ) {
                                                                $class = "dgItemStyle";
                                                            } else {
                                                                $class = "dgAItemStyle";
                                                            }

                                                            $pariIndex++;

                                                        ?>

                                                        <tr class="<?php echo $class;?>">
                                                            <td align="center"><a title="Voir Coupon" class="active" href="betdetail.php?IDCoupon=<?php echo $parisRow['code_coupon'];?>"><?php echo $parisRow['code_coupon'];?></a></td>
                                                            <td align="center"><?php echo $row['prenom']." ".$row['nom'];?></td>
                                                            <td align="center"><?php echo $parisRow['type_pari'];?></td>
                                                            <td align="center">
                                                                <span id="ac_w_PC_PC_grid_ctl02_lblData">
                                                                    <?php
                                                                        $timestamp = strtotime($parisRow['date']);
                                                                        $date = new DateTime();
                                                                        $date->setTimestamp($timestamp);
                                                                        echo $date->format('d/m/Y H:i:s');
                                                                    ?>
                                                                </span>
                                                            </td>
                                                            <td align="center">
                                                                <span id="ac_w_PC_PC_grid_ctl02_lblDataEsito"></span>
                                                            </td>
                                                            <td align="right"><?php
                                                                if($parisRow['amount'] > 0){
                                                                    echo str_replace('.',',',number_format(str_replace(',','.',$parisRow['amount']), 2, '.', ''));
                                                                }
                                                                ?>
                                                            </td>
                                                            <td align="center">
                                                                <?php if($parisRow['etat_pari'] == 'running'){?>
                                                                    <img id="ac_w_PC_PC_imgLegEsito3" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_3.gif" style="border-width:0px;">
                                                                <?php }?>
                                                                <?php if($parisRow['etat_pari'] == 'win'){?>
                                                                    <img id="ac_w_PC_PC_imgLegEsito1" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_1.gif" style="border-width:0px;">
                                                                <?php }?>
                                                                <?php if($parisRow['etat_pari'] == 'lost'){?>
                                                                    <img id="ac_w_PC_PC_imgLegEsito2" src="http://static.planetwin365.com/App_Themes/PlanetWin365/Images/Icons/ScommesseEsito_2.gif" style="border-width:0px;">
                                                                <?php }?>
                                                            </td>
                                                            <td align="right">
                                                                <?php
                                                                echo str_replace('.',',',number_format(str_replace(',','.',$parisRow['montant_gagne']), 2, '.', ''));
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <?php }?>


                                                        <tr class="dgTotalsStyle">
                                                            <td colspan="4" style="width:100%;">- Total Page -</td>
                                                            <td class="dgTotalsImpPos" colspan="2" style="white-space:nowrap;">
                                                                <?php
                                                                $amountTotRes = mysqli_query($dbhandle, "SELECT SUM(amount) AS amounttot FROM (SELECT amount FROM coupon WHERE usager = '$usagerId' $dateFilter ORDER BY date DESC LIMIT $premiereEntree, $messagesParPage) as subquery");
                                                                $amountTotRow = mysqli_fetch_assoc($amountTotRes);
                                                                if($amountTotRow['amounttot']){
                                                                    echo str_replace('.',',',number_format(str_replace(',','.',$amountTotRow['amounttot']), 2, '.', ''));
                                                                }

                                                                ?>
                                                            </td>
                                                            <td colspan="1"></td>
                                                            <td class="dgTotalsImpNeg" colspan="1" style="white-space:nowrap;">
                                                                <?php
                                                                $amountTotRes = mysqli_query($dbhandle, "SELECT SUM(montant_gagne) AS amounttot FROM (SELECT montant_gagne FROM coupon WHERE usager = '$usagerId' $dateFilter ORDER BY date DESC LIMIT $premiereEntree, $messagesParPage) as subquery");
                                                                $amountTotRow = mysqli_fetch_assoc($amountTotRes);
                                                                if($amountTotRow['amounttot'])
                                                                echo str_replace('.',',',number_format(str_replace(',','.',$amountTotRow['amounttot']), 2, '.', ''));
                                                                ?>
                                                            </td>
                                                            <td colspan="2"></td>
                                                        </tr>
                                                        <tr class="dgTotalsStyle">
                                                            <td colspan="4" style="width:100%;">- Total -</td>
                                                            <td class="dgTotalsImpPos" colspan="2" style="white-space:nowrap;">
                                                                <?php
                                                                $amountTotRes = mysqli_query($dbhandle, "SELECT SUM(amount) AS amounttot FROM (SELECT amount FROM coupon WHERE usager = '$usagerId' $dateFilter ORDER BY date DESC) as subquery");
                                                                $amountTotRow = mysqli_fetch_assoc($amountTotRes);
                                                                if($amountTotRow['amounttot'])
                                                                echo str_replace('.',',',number_format(str_replace(',','.',$amountTotRow['amounttot']), 2, '.', ''));
                                                                ?>
                                                            </td>
                                                            <td colspan="1"></td>
                                                            <td class="dgTotalsImpNeg" colspan="1" style="white-space:nowrap;">
                                                                <?php
                                                                $amountTotRes = mysqli_query($dbhandle, "SELECT SUM(montant_gagne) AS amounttot FROM (SELECT montant_gagne FROM coupon WHERE usager = '$usagerId' $dateFilter ORDER BY date DESC) as subquery");
                                                                $amountTotRow = mysqli_fetch_assoc($amountTotRes);
                                                                if($amountTotRow['amounttot'])
                                                                echo str_replace('.',',',number_format(str_replace(',','.',$amountTotRow['amounttot']), 2, '.', ''));
                                                                ?>
                                                            </td>
                                                            <td colspan="2"></td>
                                                        </tr>
                                                        <tr class="dgPagerStyle">
                                                            <td colspan="8">
                                                                <table border="0">
                                                                    <tbody>
                                                                    <tr>
                                                                        <?php

                                                                        if(!empty($pageFilters)){

                                                                        }

                                                                        $maxPage = ( floor($pageActuelle / 10) * 10 ) + 10;
                                                                        $minPage = $maxPage - 10;

                                                                        $prev = $minPage - 1;
                                                                        $next = $maxPage + 1;

                                                                        $pageFiltersString = "";
                                                                        if(!empty($pageFilters)){
                                                                            $pageFiltersString = "&".implode("&", $pageFilters);
                                                                        }

                                                                        if($minPage > 0 && $pageActuelle >= $minPage){
                                                                            echo '<td><a class="active" href="betlist.php?page='.$prev.$pageFiltersString.'">...</a></td> ';
                                                                        }

                                                                        for($i=1; $i<=$nombreDePages; $i++) {
                                                                            //On va faire notre condition
                                                                            if($i >= $minPage && $i <= $maxPage){
                                                                                if($i==$pageActuelle){
                                                                                    echo "<td><span>$i</span></td>";
                                                                                }
                                                                                if($i!=$pageActuelle){
                                                                                    echo '<td><a class="active" href="betlist.php?page='.$i.$pageFiltersString.'">'.$i.'</a></td> ';
                                                                                }
                                                                            }
                                                                        }

                                                                        if($nombreDePages > $maxPage){
                                                                            echo '<td><a class="active" href="betlist.php?page='.$next.$pageFiltersString.'">...</a></td> ';
                                                                        }

                                                                        ?>

                                                                    </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>




                                        </div></div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>


                            <div id="popupAnnullamento">
                                <div class="sezBtn"><a id="popupAnnullamentoClose"><img src="http://static.planetwin365.com/App_Themes/PlanetWin365/images/btn_close.gif" id="ac_w_PC_PC_Img1"></a></div>
                                <div>
                                    <iframe id="ifPopup" scrolling="no" src="" marginheight="0" marginwidth="0" frameborder="0" height="270px" width="600px">
                                    </iframe>
                                </div>
                            </div>
                            <div id="backgroundPopup"></div>
                        </div></td></tr>
                </tbody></table>

            <div class="spacer30"></div>
        </div>
    </div>









</div>
<!--FOOTER-->
<div id="divFooter">
    <div class="spacer13"></div>
    <div class="Main">
        <div class="Promo"><div style="margin: 0px; padding: 0px; width: 165px; height: 72px; position: relative;"><img border="0" height="95" src="http://ww3.365planetwinall.net/ImgCMS/dilivio_new.png" style="left: -228px; top: -23px; position: absolute;" width="393" /></div>
        </div>
        <div class="Txt">
            <div class="Terms">
                <ul><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=166')" >Termes et Conditions</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=284')" >Conditions d'Utilisation</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3')" >Règlement</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=163')" >Jeu Responsable</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=164')" >Privacy</a></li><li><a title="" href="http://info.365planetwinall.com/index.php?lang=3" target="_blank" >Qui nous sommes</a></li><li><a title="" href="http://my.planetwin365.com/sport-rules-and-bet-types/bet-types/" target="_blank" ></a></li></ul>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    //<![CDATA[
    var Page_ValidationSummaries =  new Array(document.getElementById("h_w_PC_ctl02_vgHotWin"));
    var Page_Validators =  new Array(document.getElementById("h_w_cLogin_ctrlLogin_reqUsername"), document.getElementById("h_w_cLogin_ctrlLogin_RequiredFieldValidator1"), document.getElementById("h_w_PC_ctl02_checkQuotaDaRaggiungere"), document.getElementById("h_w_PC_ctl02_reqVincita"), document.getElementById("h_w_PC_ctl02_cmpVincita"), document.getElementById("h_w_PC_ctl02_reqGiocata"), document.getElementById("h_w_PC_ctl02_cmpGiocata"));
    //]]>
</script>

<script type="text/javascript">
    //<![CDATA[
    var h_w_cLogin_ctrlLogin_reqUsername = document.all ? document.all["h_w_cLogin_ctrlLogin_reqUsername"] : document.getElementById("h_w_cLogin_ctrlLogin_reqUsername");
    h_w_cLogin_ctrlLogin_reqUsername.controltovalidate = "h_w_cLogin_ctrlLogin_Username";
    h_w_cLogin_ctrlLogin_reqUsername.errormessage = "Champ usager non valorisé";
    h_w_cLogin_ctrlLogin_reqUsername.display = "Dynamic";
    h_w_cLogin_ctrlLogin_reqUsername.validationGroup = "Login";
    h_w_cLogin_ctrlLogin_reqUsername.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_cLogin_ctrlLogin_reqUsername.initialvalue = "";
    var h_w_cLogin_ctrlLogin_RequiredFieldValidator1 = document.all ? document.all["h_w_cLogin_ctrlLogin_RequiredFieldValidator1"] : document.getElementById("h_w_cLogin_ctrlLogin_RequiredFieldValidator1");
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.controltovalidate = "h_w_cLogin_ctrlLogin_Password";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.errormessage = "Champ mot de passe non valorisé";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.display = "Dynamic";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.validationGroup = "Login";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.initialvalue = "";
    var h_w_PC_ctl02_vgHotWin = document.all ? document.all["h_w_PC_ctl02_vgHotWin"] : document.getElementById("h_w_PC_ctl02_vgHotWin");
    h_w_PC_ctl02_vgHotWin.showmessagebox = "True";
    h_w_PC_ctl02_vgHotWin.showsummary = "False";
    h_w_PC_ctl02_vgHotWin.validationGroup = "vHotWin";
    var h_w_PC_ctl02_checkQuotaDaRaggiungere = document.all ? document.all["h_w_PC_ctl02_checkQuotaDaRaggiungere"] : document.getElementById("h_w_PC_ctl02_checkQuotaDaRaggiungere");
    h_w_PC_ctl02_checkQuotaDaRaggiungere.controltovalidate = "h_w_PC_ctl02_txtVincita";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.errormessage = "Le multiplieur peut être seulement entre 10 et 20,000.";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.display = "Dynamic";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.validationGroup = "vHotWin";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.evaluationfunction = "CustomValidatorEvaluateIsValid";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.clientvalidationfunction = "checkQuotaDaRaggiungere";
    var h_w_PC_ctl02_reqVincita = document.all ? document.all["h_w_PC_ctl02_reqVincita"] : document.getElementById("h_w_PC_ctl02_reqVincita");
    h_w_PC_ctl02_reqVincita.controltovalidate = "h_w_PC_ctl02_txtVincita";
    h_w_PC_ctl02_reqVincita.errormessage = "Erreur dans l\'insertion du gain!";
    h_w_PC_ctl02_reqVincita.display = "Dynamic";
    h_w_PC_ctl02_reqVincita.validationGroup = "vHotWin";
    h_w_PC_ctl02_reqVincita.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_PC_ctl02_reqVincita.initialvalue = "";
    var h_w_PC_ctl02_cmpVincita = document.all ? document.all["h_w_PC_ctl02_cmpVincita"] : document.getElementById("h_w_PC_ctl02_cmpVincita");
    h_w_PC_ctl02_cmpVincita.controltovalidate = "h_w_PC_ctl02_txtVincita";
    h_w_PC_ctl02_cmpVincita.errormessage = "Erreur dans l\'insertion du gain!";
    h_w_PC_ctl02_cmpVincita.display = "Dynamic";
    h_w_PC_ctl02_cmpVincita.validationGroup = "vHotWin";
    h_w_PC_ctl02_cmpVincita.type = "Double";
    h_w_PC_ctl02_cmpVincita.decimalchar = ",";
    h_w_PC_ctl02_cmpVincita.evaluationfunction = "CompareValidatorEvaluateIsValid";
    h_w_PC_ctl02_cmpVincita.operator = "DataTypeCheck";
    var h_w_PC_ctl02_reqGiocata = document.all ? document.all["h_w_PC_ctl02_reqGiocata"] : document.getElementById("h_w_PC_ctl02_reqGiocata");
    h_w_PC_ctl02_reqGiocata.controltovalidate = "h_w_PC_ctl02_txtGiocata";
    h_w_PC_ctl02_reqGiocata.errormessage = "Erreur dans l\'insertion du pari! ";
    h_w_PC_ctl02_reqGiocata.display = "Dynamic";
    h_w_PC_ctl02_reqGiocata.validationGroup = "vHotWin";
    h_w_PC_ctl02_reqGiocata.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_PC_ctl02_reqGiocata.initialvalue = "";
    var h_w_PC_ctl02_cmpGiocata = document.all ? document.all["h_w_PC_ctl02_cmpGiocata"] : document.getElementById("h_w_PC_ctl02_cmpGiocata");
    h_w_PC_ctl02_cmpGiocata.controltovalidate = "h_w_PC_ctl02_txtGiocata";
    h_w_PC_ctl02_cmpGiocata.errormessage = "Erreur dans l\'insertion du pari! ";
    h_w_PC_ctl02_cmpGiocata.display = "Dynamic";
    h_w_PC_ctl02_cmpGiocata.validationGroup = "vHotWin";
    h_w_PC_ctl02_cmpGiocata.type = "Double";
    h_w_PC_ctl02_cmpGiocata.decimalchar = ",";
    h_w_PC_ctl02_cmpGiocata.evaluationfunction = "CompareValidatorEvaluateIsValid";
    h_w_PC_ctl02_cmpGiocata.operator = "DataTypeCheck";
    //]]>
</script>


<script type="text/javascript">
    //<![CDATA[
    checkLocation();$.event.trigger('CouponRefreshed');$(document).ready(function(){ $.event.trigger('CouponChanged');});
    var Page_ValidationActive = false;
    if (typeof(ValidatorOnLoad) == "function") {
        ValidatorOnLoad();
    }

    function ValidatorOnSubmit() {
        if (Page_ValidationActive) {
            return ValidatorCommonOnSubmit();
        }
        else {
            return true;
        }
    }

    document.getElementById('h_w_PC_ctl02_vgHotWin').dispose = function() {
        Array.remove(Page_ValidationSummaries, document.getElementById('h_w_PC_ctl02_vgHotWin'));
    }
    Sys.Application.initialize();

    document.getElementById('h_w_cLogin_ctrlLogin_reqUsername').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_cLogin_ctrlLogin_reqUsername'));
    }

    document.getElementById('h_w_cLogin_ctrlLogin_RequiredFieldValidator1').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_cLogin_ctrlLogin_RequiredFieldValidator1'));
    }
    Sys.Application.add_init(function() {
        $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":100,"dynamicLayout":true}, null, null, $get("h_w_ctl18_UpdateProgress"));
    });

    document.getElementById('h_w_PC_ctl02_checkQuotaDaRaggiungere').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_checkQuotaDaRaggiungere'));
    }

    document.getElementById('h_w_PC_ctl02_reqVincita').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_reqVincita'));
    }

    document.getElementById('h_w_PC_ctl02_cmpVincita').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_cmpVincita'));
    }

    document.getElementById('h_w_PC_ctl02_reqGiocata').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_reqGiocata'));
    }

    document.getElementById('h_w_PC_ctl02_cmpGiocata').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_cmpGiocata'));
    }
    Sys.Application.add_init(function() {
        $create(Sys.UI._Timer, {"enabled":false,"interval":60000,"uniqueID":"h$w$PC$ctl10$tmrUpdateLive"}, null, null, $get("h_w_PC_ctl10_tmrUpdateLive"));
    });
    //]]>
</script>

<script type="text/javascript" src="http://planetwins365.tk/livechat/php/app.php?widget-init.js"></script>

<style>
img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {
    display: none;
}
</style>


</body>
</html>
