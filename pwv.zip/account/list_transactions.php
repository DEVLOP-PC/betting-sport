<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:../login.php");
}

require_once('../db_connect.php');

$identificateur = $_SESSION['pw_logged_user'];

$gid = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
$row = mysqli_fetch_assoc($gid);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="h_w_h"><title>
        planetwin365
    </title><link rel="SHORTCUT ICON" href="http://planetwin365.com/App_Themes/PlanetWin365/Images/Icons/favicon.ico" type="text/css"></link><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/layout.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/calendar.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/coupon.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/download_card.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/quote.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/WebRadio.css" />



    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

    <script src="http://ww3.365planetwinall.net/Scripts/Flash.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Coupon.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Common.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/ClickBet.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/odds.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cookie.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.scrollable.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cycle.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.scrollTo-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.serialScroll-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.innerfade.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jcarousellite_1.0.1.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/swfobject.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Session.js" type="text/javascript"></script>




    <script language="javascript" type="text/javascript">
        // variabili specifihe per bookmaker
        var divCouponTopPosition = 0; //Posizione top del coupon, se <=0 disabilita scroll
        var heightFooter = 206 //Altezza footer per far in modo che il coupon non ci vada sopra
        var hideAgentSummary = 1; //1 nasconde inizialmente il riassunto nella defaultlogged
        var themeUrl = 'http://static.planetwin365.com/App_Themes/PlanetWin365/';
        var TVClientID = null;
        var TVClientLimiteCampionati = null;
        var TVClientLimiteCampionatiErr = null;
        var sepDec = ',';
        var ExpandSubEvent = 1;
        var isAnonymous = 'True';
        var bestsellerQT = false;
        var qtaDeleted = false;

        function OpenLiveChat() {
        }

        function OpenWebRadio(url, widthDiv, heightDiv) {
        }

        function scrollToCoupon() {
            setTimeout(function(){
                $('html, body').animate({
                    scrollTop: $("#divCoupon").offset().top }, 250);
                setTimeout(function(){
                    $(".CItems").effect("pulsate", { times:1 }, 2000);
                }, 250);
            }, 250);
        }

        function pulsateCoupon() {
        }


        $(document).ready(function() {

            $("a").on('click', function(e) {
                if( $(this).hasClass( "active" ) ) { }
                else {
                    e.preventDefault;
                    return false;
                }
            });

        });
    </script>

    <script type="text/javascript">
        var sBtnUpdateSaldo = 'h_w_cLogin_btnSaldo';
    </script>

    <script>
        $( document ).ready(function() {
            var isInputSupported = 'placeholder' in document.createElement('input');
            var isTextareaSupported = 'placeholder' in document.createElement('textarea');
            if (!isInputSupported || !isTextareaSupported) {
                $('[placeholder]').focus(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                        input.val('');
                        input.removeClass('placeholder');
                    }
                }).blur(function () {
                    var input = $(this);
                    if (input.val() == '') {
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                        input.data('placeholder', true);
                    } else {
                        input.data('placeholder', false);
                    }
                }).blur().parents('form').submit(function () {
                    $(this).find('[placeholder]').each(function () {
                        var input = $(this);
                        if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                            input.val('');
                        }
                    })
                });
            }

        });
        function pageLoad() {
            if ($('.txtLogin').length>0) {
                $('input:not(.txtLogin), select').bind("focus", function () {
                    preventSavingCredentials();
                });
            }
        }
        function preventSavingCredentials() {
            document.getElementsByClassName('RegTxtPwd')[0].children[0].value = document.getElementById('inputPassword').value;
            document.getElementsByClassName('RegTxtPwd')[0].children[0].type = "text";
            document.getElementById('fakePasswordTxt').value = "";
            document.getElementById('inputPassword').value = "";
        }
    </script>
</head>
<body class="bodyMain Anonymous fr-FR">


<div>

    <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="15C4A0A3" />
</div>
<div style="position:absolute; top:0; left:0; width:5px; height:5px;" title='SRVM-WEB09'></div>


<script type="text/javascript">
    $('.bodyMain').css('background-image', 'url(../1/1.jpg)');


</script>






<div id="sessionEndWarning"> </div>
<div class="divMainHome">
    <!--HEADER-->
    <?php include("../header.php");?>
    <!--MAIN-->








    <div id="divMain">
        <div id="divContent">

            <table id="tblMainContent" cellpadding="0" cellspacing="0">
                <tbody><tr><td><div class="spacer5"></div></td></tr>
                <tr><td class="tdCNMaxAccount"><div id="MainContent">

                            <script language="javascript" type="text/javascript">
                                $(document).ready(function() {
                                    initializePopup("popupAnnullamentoClose", "popupAnnullamento", "backgroundPopup");
                                });

                                function showPopup(IDCoupon) {

                                    centerPopup("popupAnnullamento", "backgroundPopup");

                                    var PathIndi;
                                    PathIndi = 'BetRefuse.aspx'



                                    $("iframe[id=ifPopup]").attr("src",PathIndi + "?IDCoupon=" + IDCoupon) ;

                                    loadPopup("popupAnnullamento", "backgroundPopup");

                                }

                            </script>



                            <div class="Riquadro"><div class="TopSX"><div class="TopDX"><h3>Liste Transactions</h3></div></div>
                                <div class="CntSX"><div class="CntDX"><div id="ac_w_PC_PC_panelSquare">

                                            <div class="RiquadroSrc"><div class="TopSX"><div class="TopDX"></div></div><div class="Cnt"><div>

                                                        <div id="ac_w_PC_PC_valSummary" class="ValidationSummary" style="color:Red;display:none;">

                                                        </div>
                                                        <div id="ac_w_PC_PC_panForm" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ac_w_PC_PC_btnAvanti')">

                                                            <script>
                                                                $(function() {
                                                                    $( "#date_de, #date_a" ).datepicker({
                                                                        altField: "#datepicker",
                                                                        closeText: 'Fermer',
                                                                        prevText: 'Précédent',
                                                                        nextText: 'Suivant',
                                                                        currentText: 'Aujourd\'hui',
                                                                        monthNames: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
                                                                        monthNamesShort: ['Janv.', 'Févr.', 'Mars', 'Avril', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'],
                                                                        dayNames: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
                                                                        dayNamesShort: ['Dim.', 'Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.'],
                                                                        dayNamesMin: ['D', 'L', 'M', 'M', 'J', 'V', 'S'],
                                                                        weekHeader: 'Sem.',
                                                                        dateFormat: 'yy-mm-dd',
                                                                        minDate: '-3M',
                                                                        maxDate: '+0D'
                                                                    });
                                                                });
                                                            </script>
                                                            <form action="" method="GET" id="search">
                                                            <div class="SearchTitleStyle">
                                                                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                    <tbody><tr>
                                                                        <td>
                                                                            Recherche
                                                                        </td>
                                                                        <td class="SearchMinimizeStyle">
                                                                            <a href="javascript:ShowHideSearch('tblSearch', 'ac_w_PC_PC_imgHide', 'ac_w_PC_PC_imgShow');">
                                                                                <img id="ac_w_PC_PC_imgHide" src="./planetwin365_files/Minimizza_ico.png" alt="Cacher tableau" style="border-width:0px;">
                                                                                <img id="ac_w_PC_PC_imgShow" src="./planetwin365_files/Ingrandire_ico.png" alt="Montrer tableau" style="border-width:0px;display: none;">
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                    </tbody></table>
                                                            </div>
                                                            <table id="tblSearch" class="SearchContainerStyle">

                                                                <tbody><tr class="SearchSectionStyle">
                                                                    <td class="SearchDescStyle">
                                                                        Montants
                                                                    </td>
                                                                    <td class="SearchControlsStyle">
                                                                        <table width="100%">
                                                                            <tbody><tr>
                                                                                <td width="19%" align="left">
                                                                                    Type
                                                                                </td>
                                                                                <td width="81%" align="left" colspan="3">
                                                                                    <table id="ac_w_PC_PC_rblTipoImporto" border="0">
                                                                                        <tbody><tr>
                                                                                            <td><input id="ac_w_PC_PC_rblTipoImporto_0" type="radio" name="ac$w$PC$PC$rblTipoImporto" value="-1" checked="checked"><label for="ac_w_PC_PC_rblTipoImporto_0">Tous</label></td><td><input id="ac_w_PC_PC_rblTipoImporto_1" type="radio" name="ac$w$PC$PC$rblTipoImporto" value="1"><label for="ac_w_PC_PC_rblTipoImporto_1">Crédits</label></td><td><input id="ac_w_PC_PC_rblTipoImporto_2" type="radio" name="ac$w$PC$PC$rblTipoImporto" value="2"><label for="ac_w_PC_PC_rblTipoImporto_2">Débits</label></td>
                                                                                        </tr>
                                                                                        </tbody></table>
                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>
                                                                <tr class="SearchSectionStyle">
                                                                    <td class="SearchDescStyle">
                                                                        Transaction
                                                                    </td>
                                                                    <td class="SearchControlsStyle">
                                                                        <table width="100%">
                                                                            <tbody><tr>
                                                                                <td width="20%" align="left">
                                                                                    Type
                                                                                </td>
                                                                                <td width="30%" align="left">
                                                                                    <select name="ac$w$PC$PC$ddlCausale" id="ac_w_PC_PC_ddlCausale" class="dropdown" style="width:172px;">
                                                                                        <option selected="selected" value=""></option>
                                                                                        <option value="1">Indéfini</option>
                                                                                        <option value="2">VersementRetrait</option>
                                                                                        <option value="3">Retraits</option>
                                                                                        <option value="4">Paris</option>
                                                                                        <option value="6">SkillGames</option>
                                                                                        <option value="7">Transfert Caisse</option>

                                                                                    </select>
                                                                                </td>
                                                                                <td width="20%">
                                                                                </td>
                                                                                <td width="30%">
                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>
                                                                <tr class="SearchSectionStyle">
                                                                    <td class="SearchDescStyle">
                                                                        Tipo Causale
                                                                    </td>
                                                                    <td class="SearchControlsStyle">
                                                                        <table width="100%">
                                                                            <tbody><tr>
                                                                                <td width="20%" align="left">
                                                                                    Tipo
                                                                                </td>
                                                                                <td width="30%" align="left">
                                                                                    <table id="ac_w_PC_PC_chklTipoCausale" border="0">
                                                                                        <tbody><tr>
                                                                                            <td><input id="ac_w_PC_PC_chklTipoCausale_0" type="checkbox" name="ac$w$PC$PC$chklTipoCausale$0" checked="checked"><label for="ac_w_PC_PC_chklTipoCausale_0">Normal</label></td>
                                                                                        </tr><tr>
                                                                                            <td><input id="ac_w_PC_PC_chklTipoCausale_1" type="checkbox" name="ac$w$PC$PC$chklTipoCausale$1" checked="checked"><label for="ac_w_PC_PC_chklTipoCausale_1">Virtual Bets</label></td>
                                                                                        </tr>
                                                                                        </tbody></table>
                                                                                </td>
                                                                                <td width="20%">

                                                                                </td>
                                                                                <td width="30%">

                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>

                                                                <tr class="SearchSectionStyle">
                                                                    <td class="SearchDescStyle">
                                                                        Date de la Transaction
                                                                    </td>
                                                                    <td class="SearchControlsStyle">
                                                                        <table width="100%">
                                                                            <tbody><tr>
                                                                                <td width="20%" align="left">
                                                                                    Du
                                                                                </td>
                                                                                <td width="30%" align="left">


                                                                                    <table cellpadding="0" cellspacing="0">
                                                                                        <tbody><tr>
                                                                                            <td>
                                                                                                <input name="de" value="<?php echo date("Y-m-d", strtotime("- 3 months"));?>" id="date_de" class="textbox" style="width:75px;" type="text">
                                                                                            </td>
                                                                                            <td width="25px" align="center">
                                                                                                <img src="../planetwin365_files/Calendar.gif" alt="Voir calendrier" style="border-width:0px;cursor:pointer;">
                                                                                            </td>
                                                                                            <td>
                                                                                                <span id="ac_w_PC_PC_cldDal_cmpDate" style="color:Red;display:none;">Le format de la date n'est pas valable</span>
                                                                                                <span id="ac_w_PC_PC_cldDal_reqDate" class="validation-error" style="color:Red;display:none;">Insérer une date de début </span>

                                                                                                <div id="ac_w_PC_PC_cldDal_pnlCalendar" class="popupControl" style="display: none; position: absolute;">



                                                                                                    <div id="ac_w_PC_PC_cldDal_UpdatePanel1">


                                                                                                        <table class="CalendarExternalTableStyle">
                                                                                                            <tbody><tr>
                                                                                                                <td align="left" style="padding:5px;width:30px">
                                                                                                                    <a id="ac_w_PC_PC_cldDal_btnDecrYear" class="CalendarLinkButStyleW" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ac$w$PC$PC$cldDal$btnDecrYear", "", true, "", "", false, true))'>-</a>&nbsp;
                                                                                                                </td>
                                                                                                                <td align="center">
                                                                                                                    <span id="ac_w_PC_PC_cldDal_lbYear">2016</span>
                                                                                                                </td>
                                                                                                                <td align="right" style="padding:5px;width:30px">
                                                                                                                    &nbsp;<a id="ac_w_PC_PC_cldDal_btnAddYear" class="CalendarLinkButStyleW" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ac$w$PC$PC$cldDal$btnAddYear", "", true, "", "", false, true))'>+</a>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr><td colspan="3">
                                                                                                                    <table id="ac_w_PC_PC_cldDal_cldSelectDate" class="CalendarStyle" cellspacing="0" cellpadding="2" title="Calendar" border="0" style="border-width:1px;border-style:solid;width:160px;border-collapse:collapse;">
                                                                                                                        <tbody><tr><td colspan="7" style="background-color:Silver;"><table class="CalendarTitleStyle" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                                                                                                                    <tbody><tr><td class="CalendarNextPrevStyle" style="width:15%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','V5813')" style="color:Black" title="Go to the previous month">&lt;</a></td><td align="center" style="width:70%;">janvier</td><td class="CalendarNextPrevStyle" align="right" style="width:15%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','V5875')" style="color:Black" title="Go to the next month">&gt;</a></td></tr>
                                                                                                                                    </tbody></table></td></tr><tr><th class="CalendarDayHeaderStyle" align="center" abbr="lundi" scope="col">lu</th><th class="CalendarDayHeaderStyle" align="center" abbr="mardi" scope="col">ma</th><th class="CalendarDayHeaderStyle" align="center" abbr="mercredi" scope="col">me</th><th class="CalendarDayHeaderStyle" align="center" abbr="jeudi" scope="col">je</th><th class="CalendarDayHeaderStyle" align="center" abbr="vendredi" scope="col">ve</th><th class="CalendarDayHeaderStyle" align="center" abbr="samedi" scope="col">sa</th><th class="CalendarDayHeaderStyle" align="center" abbr="dimanche" scope="col">di</th></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5840')" style="color:Gray" title="28 décembre">28</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5841')" style="color:Gray" title="29 décembre">29</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5842')" style="color:Gray" title="30 décembre">30</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5843')" style="color:Gray" title="31 décembre">31</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5844')" style="color:Black" title="1 janvier">1</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5845')" style="color:Black" title="2 janvier">2</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5846')" style="color:Black" title="3 janvier">3</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5847')" style="color:Black" title="4 janvier">4</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5848')" style="color:Black" title="5 janvier">5</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5849')" style="color:Black" title="6 janvier">6</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5850')" style="color:Black" title="7 janvier">7</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5851')" style="color:Black" title="8 janvier">8</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5852')" style="color:Black" title="9 janvier">9</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5853')" style="color:Black" title="10 janvier">10</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5854')" style="color:Black" title="11 janvier">11</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5855')" style="color:Black" title="12 janvier">12</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5856')" style="color:Black" title="13 janvier">13</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5857')" style="color:Black" title="14 janvier">14</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5858')" style="color:Black" title="15 janvier">15</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5859')" style="color:Black" title="16 janvier">16</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5860')" style="color:Black" title="17 janvier">17</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5861')" style="color:Black" title="18 janvier">18</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5862')" style="color:Black" title="19 janvier">19</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5863')" style="color:Black" title="20 janvier">20</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5864')" style="color:Black" title="21 janvier">21</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5865')" style="color:Black" title="22 janvier">22</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5866')" style="color:Black" title="23 janvier">23</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Black;background-color:#D2F1F8;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5867')" style="color:Black" title="24 janvier">24</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5868')" style="color:Black" title="25 janvier">25</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5869')" style="color:Black" title="26 janvier">26</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5870')" style="color:Black" title="27 janvier">27</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5871')" style="color:Black" title="28 janvier">28</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5872')" style="color:Black" title="29 janvier">29</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5873')" style="color:Black" title="30 janvier">30</a></td><td class="CalendarTodayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5874')" style="color:Black" title="31 janvier">31</a></td></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5875')" style="color:Gray" title="1 février">1</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5876')" style="color:Gray" title="2 février">2</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5877')" style="color:Gray" title="3 février">3</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5878')" style="color:Gray" title="4 février">4</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5879')" style="color:Gray" title="5 février">5</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5880')" style="color:Gray" title="6 février">6</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldDal$cldSelectDate','5881')" style="color:Gray" title="7 février">7</a></td></tr>
                                                                                                                        </tbody></table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            </tbody></table>

                                                                                                    </div>

                                                                                                </div>
                                                                                            </td>

                                                                                        </tr>
                                                                                        </tbody></table>



                                                                                </td>
                                                                                <td width="20%" align="right">
                                                                                    Au
                                                                                </td>
                                                                                <td width="30%" align="left">


                                                                                    <table cellpadding="0" cellspacing="0">
                                                                                        <tbody><tr>
                                                                                            <td>
                                                                                                <input name="a" value="<?php echo date("Y-m-d", strtotime("today"));?>" id="date_a" class="textbox" style="width:75px;" type="text">
                                                                                            </td>
                                                                                            <td width="25px" align="center">
                                                                                                <img src="../planetwin365_files/Calendar.gif" alt="Voir calendrier" style="border-width:0px;cursor:pointer;">
                                                                                            </td>
                                                                                            <td>
                                                                                                <span id="ac_w_PC_PC_cldAl_cmpDate" style="color:Red;display:none;">Le format de la date n'est pas valable</span>
                                                                                                <span id="ac_w_PC_PC_cldAl_reqDate" class="validation-error" style="color:Red;display:none;">Insérer une date de fin </span>

                                                                                                <div id="ac_w_PC_PC_cldAl_pnlCalendar" class="popupControl" style="display: none; position: absolute;">



                                                                                                    <div id="ac_w_PC_PC_cldAl_UpdatePanel1">


                                                                                                        <table class="CalendarExternalTableStyle">
                                                                                                            <tbody><tr>
                                                                                                                <td align="left" style="padding:5px;width:30px">
                                                                                                                    <a id="ac_w_PC_PC_cldAl_btnDecrYear" class="CalendarLinkButStyleW" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ac$w$PC$PC$cldAl$btnDecrYear", "", true, "", "", false, true))'>-</a>&nbsp;
                                                                                                                </td>
                                                                                                                <td align="center">
                                                                                                                    <span id="ac_w_PC_PC_cldAl_lbYear">2016</span>
                                                                                                                </td>
                                                                                                                <td align="right" style="padding:5px;width:30px">
                                                                                                                    &nbsp;<a id="ac_w_PC_PC_cldAl_btnAddYear" class="CalendarLinkButStyleW" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ac$w$PC$PC$cldAl$btnAddYear", "", true, "", "", false, true))'>+</a>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr><td colspan="3">
                                                                                                                    <table id="ac_w_PC_PC_cldAl_cldSelectDate" class="CalendarStyle" cellspacing="0" cellpadding="2" title="Calendar" border="0" style="border-width:1px;border-style:solid;width:160px;border-collapse:collapse;">
                                                                                                                        <tbody><tr><td colspan="7" style="background-color:Silver;"><table class="CalendarTitleStyle" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                                                                                                                    <tbody><tr><td class="CalendarNextPrevStyle" style="width:15%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','V5813')" style="color:Black" title="Go to the previous month">&lt;</a></td><td align="center" style="width:70%;">janvier</td><td class="CalendarNextPrevStyle" align="right" style="width:15%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','V5875')" style="color:Black" title="Go to the next month">&gt;</a></td></tr>
                                                                                                                                    </tbody></table></td></tr><tr><th class="CalendarDayHeaderStyle" align="center" abbr="lundi" scope="col">lu</th><th class="CalendarDayHeaderStyle" align="center" abbr="mardi" scope="col">ma</th><th class="CalendarDayHeaderStyle" align="center" abbr="mercredi" scope="col">me</th><th class="CalendarDayHeaderStyle" align="center" abbr="jeudi" scope="col">je</th><th class="CalendarDayHeaderStyle" align="center" abbr="vendredi" scope="col">ve</th><th class="CalendarDayHeaderStyle" align="center" abbr="samedi" scope="col">sa</th><th class="CalendarDayHeaderStyle" align="center" abbr="dimanche" scope="col">di</th></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5840')" style="color:Gray" title="28 décembre">28</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5841')" style="color:Gray" title="29 décembre">29</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5842')" style="color:Gray" title="30 décembre">30</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5843')" style="color:Gray" title="31 décembre">31</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5844')" style="color:Black" title="1 janvier">1</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5845')" style="color:Black" title="2 janvier">2</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5846')" style="color:Black" title="3 janvier">3</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5847')" style="color:Black" title="4 janvier">4</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5848')" style="color:Black" title="5 janvier">5</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5849')" style="color:Black" title="6 janvier">6</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5850')" style="color:Black" title="7 janvier">7</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5851')" style="color:Black" title="8 janvier">8</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5852')" style="color:Black" title="9 janvier">9</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5853')" style="color:Black" title="10 janvier">10</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5854')" style="color:Black" title="11 janvier">11</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5855')" style="color:Black" title="12 janvier">12</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5856')" style="color:Black" title="13 janvier">13</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5857')" style="color:Black" title="14 janvier">14</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5858')" style="color:Black" title="15 janvier">15</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5859')" style="color:Black" title="16 janvier">16</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5860')" style="color:Black" title="17 janvier">17</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5861')" style="color:Black" title="18 janvier">18</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5862')" style="color:Black" title="19 janvier">19</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5863')" style="color:Black" title="20 janvier">20</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5864')" style="color:Black" title="21 janvier">21</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5865')" style="color:Black" title="22 janvier">22</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5866')" style="color:Black" title="23 janvier">23</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5867')" style="color:Black" title="24 janvier">24</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5868')" style="color:Black" title="25 janvier">25</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5869')" style="color:Black" title="26 janvier">26</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5870')" style="color:Black" title="27 janvier">27</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5871')" style="color:Black" title="28 janvier">28</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5872')" style="color:Black" title="29 janvier">29</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5873')" style="color:Black" title="30 janvier">30</a></td><td class="CalendarTodayStyle" align="center" style="color:Black;background-color:#D2F1F8;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5874')" style="color:Black" title="31 janvier">31</a></td></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5875')" style="color:Gray" title="1 février">1</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5876')" style="color:Gray" title="2 février">2</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5877')" style="color:Gray" title="3 février">3</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5878')" style="color:Gray" title="4 février">4</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5879')" style="color:Gray" title="5 février">5</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5880')" style="color:Gray" title="6 février">6</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('ac$w$PC$PC$cldAl$cldSelectDate','5881')" style="color:Gray" title="7 février">7</a></td></tr>
                                                                                                                        </tbody></table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            </tbody></table>

                                                                                                    </div>

                                                                                                </div>
                                                                                            </td>

                                                                                        </tr>
                                                                                        </tbody></table>



                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="SearchDescStyle">
                                                                        Dimension Page
                                                                    </td>
                                                                    <td class="SearchControlsStyle">
                                                                        <table class="SearchControlsContainerStyle">
                                                                            <tbody><tr>
                                                                                <td width="20%" class="SearchControlDesc">
                                                                                    &nbsp;
                                                                                </td>
                                                                                <td width="80%" colspan="3">
                                                                                    <select name="ac$w$PC$PC$ddlPageSize" id="ac_w_PC_PC_ddlPageSize" class="dropdown" style="width:75px;">
                                                                                        <option selected="selected" value="15">15</option>
                                                                                        <option value="50">50</option>
                                                                                        <option value="100">100</option>

                                                                                    </select>
                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>
                                                                </tbody></table>
                                                            <table class="SearchButtonsStyle">
                                                                <tbody><tr>
                                                                    <td>

                                                                    </td>
                                                                    <td class="tdSrcSX">
                                                                        <input type="submit" name="ac$w$PC$PC$btnCancella" value="Annuler" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ac$w$PC$PC$btnCancella&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ac_w_PC_PC_btnCancella" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')">
                                                                    </td>
                                                                    <td class="tdSrcDX">
                                                                        <input type="submit" name="ac$w$PC$PC$btnAvanti" value="Continuer" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ac$w$PC$PC$btnAvanti&quot;, &quot;&quot;, true, &quot;ricerca&quot;, &quot;&quot;, false, false))" id="ac_w_PC_PC_btnAvanti" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')">
                                                                    </td>
                                                                </tr>
                                                                </tbody></table>

                                                        </div>

                                                    </div>
                                                </form>
                                                    <script type="text/javascript">
                                                        $(document).ready(function() {

                                                            $("#ac_w_PC_PC_btnAvanti").on('click', function(e) {

                                                                $("#h_w_ctl18_UpdateProgress").show();
                                                                $("#search").submit();

                                                            });
                                                            $("#ac_w_PC_PC_btnCancella").on('click', function(e) {

                                                                $("#h_w_ctl18_UpdateProgress").show();
                                                                window.location="betlist.php";

                                                            });

                                                        });
                                                    </script>
                                                </div><div class="BtmSX"><div class="BtmDX"></div></div></div>
                                            <table id="tblSearch2" class="SearchContainerStyle">
                                                <tbody><tr class="SearchSectionStyle">
                                                    <td class="SearchDescStyle">
                                                        <div style="position:relative;">
                                                            Avoir
                                                            <div class="Dati">
                                                                <span id="ac_w_PC_PC_lblDare"></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="SearchControlsStyle"></td>
                                                </tr>
                                                <tr class="SearchSectionStyle">
                                                    <td class="SearchDescStyle">
                                                        <div style="position:relative;">
                                                            Doit
                                                            <div class="Dati">
                                                                <span id="ac_w_PC_PC_lblAvere"></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="SearchControlsStyle"></td>
                                                </tr>
                                                <tr class="SearchSectionStyle">
                                                    <td class="SearchDescStyle">
                                                        <div style="position:relative">
                                                            BilanTotal
                                                            <div class="Dati">
                                                                <span id="ac_w_PC_PC_lblTotale"></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="SearchControlsStyle"></td>
                                                </tr>
                                                </tbody></table>
                                            <br>
                                            <div class="divDg">
                                                <div>
                                                    <table class="dgStyle" cellspacing="0" border="0" id="ac_w_PC_PC_grid" style="border-width:0px;border-style:None;width:100%;border-collapse:collapse;">
                                                        <tbody>
                                                        <tr class="dgHdrStyle">
                                                            <th scope="col">&nbsp;</th>
                                                            <th align="center" scope="col">ID</th>
                                                            <th align="center" scope="col">Date</th>
                                                            <th align="center" scope="col">Transaction</th>
                                                            <th align="center" scope="col">Coupon</th>
                                                            <th class="dgHdrImporti" scope="col">Avoir</th>
                                                            <th class="dgHdrImporti" scope="col">Doit</th>
                                                            <th align="center" scope="col">Sujet</th>
                                                            <th class="dgHdrImporti" scope="col">Solde</th>
                                                        </tr>

                                                        <?php

                                                        $dateFilter = "";
                                                        if(isset($_GET['de']) && isset($_GET['a'])){
                                                            $de = $_GET['de']." 00:00:00";
//                                                            $date = DateTime::createFromFormat('Y-m-d',$de);
//                                                            echo $date->format("Y-m-d H:i:s");
                                                            $a = $_GET['a']." 00:00:00";
                                                            $dateFilter = " AND date > '$de' AND date < '$a'";
                                                        }

                                                        $identificateur = $_SESSION['pw_logged_user'];

                                                        $gid = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
                                                        $row = mysqli_fetch_assoc($gid);

                                                        $usagerId = $row['id'];

                                                        //Pagination
                                                        $messagesParPage=15; //Nous allons afficher 5 messages par page.

                                                        //Une connexion SQL doit être ouverte avant cette ligne...
                                                        $retour_total=mysqli_query($dbhandle, "SELECT COUNT(*) AS total FROM transaction WHERE id_usager = '$usagerId' $dateFilter"); //Nous récupérons le contenu de la requête dans $retour_total
                                                        $donnees_total=mysqli_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
                                                        $total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

                                                        //Nous allons maintenant compter le nombre de pages.
                                                        $nombreDePages=ceil($total/$messagesParPage);

                                                        if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
                                                        {
                                                            $pageActuelle=intval($_GET['page']);

                                                            if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
                                                            {
                                                                $pageActuelle=$nombreDePages;
                                                            }
                                                        }
                                                        else // Sinon
                                                        {
                                                            $pageActuelle=1; // La page actuelle est la n°1
                                                        }

                                                        $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire


                                                        $parisRes = mysqli_query($dbhandle, "SELECT * FROM transaction WHERE id_usager = '$usagerId' $dateFilter ORDER BY date DESC LIMIT $premiereEntree, $messagesParPage");
                                                        while($parisRow = mysqli_fetch_assoc($parisRes)){
                                                        ?>
                                                        <tr class="dgItemStyle">
                                                            <td align="center"><a title="Voir détail" href="http://ww3.365planetwinall.net/Account/TransactionDetail.aspx?IDTransazione=2022496011&amp;IDPDR=1131313"><img title="Voir détail" src="../planetwin365_files/Dettagli.gif" style="border-width:0px;"></a></td>
                                                            <td align="center"><?php echo $parisRow['id'];?></td>
                                                            <td align="center">
                                                                <span id="ac_w_PC_PC_grid_ctl02_lblData">
                                                                    <?php
                                                                        $timestamp = strtotime($parisRow['date']);
                                                                        $date = new DateTime();
                                                                        $date->setTimestamp($timestamp);
                                                                        echo $date->format('d/m/Y H:i:s');
                                                                    ?>
                                                                </span>
                                                            </td>
                                                            <td align="center"><?php echo ucfirst($parisRow['type']);?></td>
                                                            <td align="center"><a title="Voir Coupon" class="active" href="betdetail.php?IDCoupon=<?php echo $parisRow['coupon'];?>"><?php echo $parisRow['coupon'];?></a></td>
                                                            <td align="right">
                                                                <?php
                                                                    if($parisRow['avoir']){
                                                                        echo str_replace('.',',',number_format(str_replace(',','.',abs($parisRow['avoir'])), 2, '.', ''));
                                                                    }
                                                                ?>
                                                            </td>
                                                            <td align="right">
                                                                <?php
                                                                if($parisRow['droit']){
                                                                    echo str_replace('.',',',number_format(str_replace(',','.',abs($parisRow['droit'])), 2, '.', ''));
                                                                }
                                                                ?>
                                                            </td>
                                                            <td align="center">&nbsp;</td>
                                                            <td class="dgHdrImporti" align="right"><?php echo str_replace('.',',',number_format(str_replace(',','.',$parisRow['solde']), 2, '.', ''));?></td>
                                                        </tr>
                                                        <?php }?>

                                                        <tr class="dgPagerStyle">
                                                            <td colspan="8">
                                                                <table border="0">
                                                                    <tbody>
                                                                    <tr>
                                                                    <?php
                                                                    $maxPage = ( floor($pageActuelle / 10) * 10 ) + 10;
                                                                    $minPage = $maxPage - 10;

                                                                    $prev = $minPage - 1;
                                                                    $next = $maxPage + 1;

                                                                    if($minPage > 0 && $pageActuelle >= $minPage){
                                                                        echo '<td><a class="active" href="list_transactions.php?page='.$prev.'">...</a></td> ';
                                                                    }

                                                                    for($i=1; $i<=$nombreDePages; $i++) {
                                                                        //On va faire notre condition
                                                                        if($i >= $minPage && $i <= $maxPage){
                                                                            if($i==$pageActuelle){
                                                                                echo "<td><span>$i</span></td>";
                                                                            }
                                                                            if($i!=$pageActuelle){
                                                                                echo '<td><a class="active" href="list_transactions.php?page='.$i.'">'.$i.'</a></td> ';
                                                                            }
                                                                        }
                                                                    }

                                                                    if($nombreDePages > $maxPage){
                                                                        echo '<td><a class="active" href="list_transactions.php?page='.$next.'">...</a></td> ';
                                                                    }

                                                                    ?>

                                                                    </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                                <br>
                                                <br>
                                                <div>
                                                </div>
                                            </div>


                                        </div></div></div>
                                <div class="BtmSX"><div class="BtmDX"></div></div></div>


                            <div id="popupAnnullamento">
                                <div class="sezBtn"><a id="popupAnnullamentoClose"><img src="http://static.planetwin365.com/App_Themes/PlanetWin365/images/btn_close.gif" id="ac_w_PC_PC_Img1"></a></div>
                                <div>
                                    <iframe id="ifPopup" scrolling="no" src="" marginheight="0" marginwidth="0" frameborder="0" height="270px" width="600px">
                                    </iframe>
                                </div>
                            </div>
                            <div id="backgroundPopup"></div>
                        </div></td></tr>
                </tbody></table>

            <div class="spacer30"></div>
        </div>
    </div>









</div>
<!--FOOTER-->
<div id="divFooter">
    <div class="spacer13"></div>
    <div class="Main">
        <div class="Promo"><div style="margin: 0px; padding: 0px; width: 165px; height: 72px; position: relative;"><img border="0" height="95" src="http://ww3.365planetwinall.net/ImgCMS/dilivio_new.png" style="left: -228px; top: -23px; position: absolute;" width="393" /></div>
        </div>
        <div class="Txt">
            <div class="Terms">
                <ul><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=166')" >Termes et Conditions</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=284')" >Conditions d'Utilisation</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3')" >Règlement</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=163')" >Jeu Responsable</a></li><li><a title="" onclick="javascript:miniSitePopup('http://info.planet365win.com/index.php?lang=3&sid=164')" >Privacy</a></li><li><a title="" href="http://info.365planetwinall.com/index.php?lang=3" target="_blank" >Qui nous sommes</a></li><li><a title="" href="http://my.planetwin365.com/sport-rules-and-bet-types/bet-types/" target="_blank" ></a></li></ul>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    //<![CDATA[
    var Page_ValidationSummaries =  new Array(document.getElementById("h_w_PC_ctl02_vgHotWin"));
    var Page_Validators =  new Array(document.getElementById("h_w_cLogin_ctrlLogin_reqUsername"), document.getElementById("h_w_cLogin_ctrlLogin_RequiredFieldValidator1"), document.getElementById("h_w_PC_ctl02_checkQuotaDaRaggiungere"), document.getElementById("h_w_PC_ctl02_reqVincita"), document.getElementById("h_w_PC_ctl02_cmpVincita"), document.getElementById("h_w_PC_ctl02_reqGiocata"), document.getElementById("h_w_PC_ctl02_cmpGiocata"));
    //]]>
</script>

<script type="text/javascript">
    //<![CDATA[
    var h_w_cLogin_ctrlLogin_reqUsername = document.all ? document.all["h_w_cLogin_ctrlLogin_reqUsername"] : document.getElementById("h_w_cLogin_ctrlLogin_reqUsername");
    h_w_cLogin_ctrlLogin_reqUsername.controltovalidate = "h_w_cLogin_ctrlLogin_Username";
    h_w_cLogin_ctrlLogin_reqUsername.errormessage = "Champ usager non valorisé";
    h_w_cLogin_ctrlLogin_reqUsername.display = "Dynamic";
    h_w_cLogin_ctrlLogin_reqUsername.validationGroup = "Login";
    h_w_cLogin_ctrlLogin_reqUsername.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_cLogin_ctrlLogin_reqUsername.initialvalue = "";
    var h_w_cLogin_ctrlLogin_RequiredFieldValidator1 = document.all ? document.all["h_w_cLogin_ctrlLogin_RequiredFieldValidator1"] : document.getElementById("h_w_cLogin_ctrlLogin_RequiredFieldValidator1");
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.controltovalidate = "h_w_cLogin_ctrlLogin_Password";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.errormessage = "Champ mot de passe non valorisé";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.display = "Dynamic";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.validationGroup = "Login";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_cLogin_ctrlLogin_RequiredFieldValidator1.initialvalue = "";
    var h_w_PC_ctl02_vgHotWin = document.all ? document.all["h_w_PC_ctl02_vgHotWin"] : document.getElementById("h_w_PC_ctl02_vgHotWin");
    h_w_PC_ctl02_vgHotWin.showmessagebox = "True";
    h_w_PC_ctl02_vgHotWin.showsummary = "False";
    h_w_PC_ctl02_vgHotWin.validationGroup = "vHotWin";
    var h_w_PC_ctl02_checkQuotaDaRaggiungere = document.all ? document.all["h_w_PC_ctl02_checkQuotaDaRaggiungere"] : document.getElementById("h_w_PC_ctl02_checkQuotaDaRaggiungere");
    h_w_PC_ctl02_checkQuotaDaRaggiungere.controltovalidate = "h_w_PC_ctl02_txtVincita";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.errormessage = "Le multiplieur peut être seulement entre 10 et 20,000.";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.display = "Dynamic";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.validationGroup = "vHotWin";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.evaluationfunction = "CustomValidatorEvaluateIsValid";
    h_w_PC_ctl02_checkQuotaDaRaggiungere.clientvalidationfunction = "checkQuotaDaRaggiungere";
    var h_w_PC_ctl02_reqVincita = document.all ? document.all["h_w_PC_ctl02_reqVincita"] : document.getElementById("h_w_PC_ctl02_reqVincita");
    h_w_PC_ctl02_reqVincita.controltovalidate = "h_w_PC_ctl02_txtVincita";
    h_w_PC_ctl02_reqVincita.errormessage = "Erreur dans l\'insertion du gain!";
    h_w_PC_ctl02_reqVincita.display = "Dynamic";
    h_w_PC_ctl02_reqVincita.validationGroup = "vHotWin";
    h_w_PC_ctl02_reqVincita.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_PC_ctl02_reqVincita.initialvalue = "";
    var h_w_PC_ctl02_cmpVincita = document.all ? document.all["h_w_PC_ctl02_cmpVincita"] : document.getElementById("h_w_PC_ctl02_cmpVincita");
    h_w_PC_ctl02_cmpVincita.controltovalidate = "h_w_PC_ctl02_txtVincita";
    h_w_PC_ctl02_cmpVincita.errormessage = "Erreur dans l\'insertion du gain!";
    h_w_PC_ctl02_cmpVincita.display = "Dynamic";
    h_w_PC_ctl02_cmpVincita.validationGroup = "vHotWin";
    h_w_PC_ctl02_cmpVincita.type = "Double";
    h_w_PC_ctl02_cmpVincita.decimalchar = ",";
    h_w_PC_ctl02_cmpVincita.evaluationfunction = "CompareValidatorEvaluateIsValid";
    h_w_PC_ctl02_cmpVincita.operator = "DataTypeCheck";
    var h_w_PC_ctl02_reqGiocata = document.all ? document.all["h_w_PC_ctl02_reqGiocata"] : document.getElementById("h_w_PC_ctl02_reqGiocata");
    h_w_PC_ctl02_reqGiocata.controltovalidate = "h_w_PC_ctl02_txtGiocata";
    h_w_PC_ctl02_reqGiocata.errormessage = "Erreur dans l\'insertion du pari! ";
    h_w_PC_ctl02_reqGiocata.display = "Dynamic";
    h_w_PC_ctl02_reqGiocata.validationGroup = "vHotWin";
    h_w_PC_ctl02_reqGiocata.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
    h_w_PC_ctl02_reqGiocata.initialvalue = "";
    var h_w_PC_ctl02_cmpGiocata = document.all ? document.all["h_w_PC_ctl02_cmpGiocata"] : document.getElementById("h_w_PC_ctl02_cmpGiocata");
    h_w_PC_ctl02_cmpGiocata.controltovalidate = "h_w_PC_ctl02_txtGiocata";
    h_w_PC_ctl02_cmpGiocata.errormessage = "Erreur dans l\'insertion du pari! ";
    h_w_PC_ctl02_cmpGiocata.display = "Dynamic";
    h_w_PC_ctl02_cmpGiocata.validationGroup = "vHotWin";
    h_w_PC_ctl02_cmpGiocata.type = "Double";
    h_w_PC_ctl02_cmpGiocata.decimalchar = ",";
    h_w_PC_ctl02_cmpGiocata.evaluationfunction = "CompareValidatorEvaluateIsValid";
    h_w_PC_ctl02_cmpGiocata.operator = "DataTypeCheck";
    //]]>
</script>


<script type="text/javascript">
    //<![CDATA[
    checkLocation();$.event.trigger('CouponRefreshed');$(document).ready(function(){ $.event.trigger('CouponChanged');});
    var Page_ValidationActive = false;
    if (typeof(ValidatorOnLoad) == "function") {
        ValidatorOnLoad();
    }

    function ValidatorOnSubmit() {
        if (Page_ValidationActive) {
            return ValidatorCommonOnSubmit();
        }
        else {
            return true;
        }
    }

    document.getElementById('h_w_PC_ctl02_vgHotWin').dispose = function() {
        Array.remove(Page_ValidationSummaries, document.getElementById('h_w_PC_ctl02_vgHotWin'));
    }
    Sys.Application.initialize();

    document.getElementById('h_w_cLogin_ctrlLogin_reqUsername').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_cLogin_ctrlLogin_reqUsername'));
    }

    document.getElementById('h_w_cLogin_ctrlLogin_RequiredFieldValidator1').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_cLogin_ctrlLogin_RequiredFieldValidator1'));
    }
    Sys.Application.add_init(function() {
        $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":100,"dynamicLayout":true}, null, null, $get("h_w_ctl18_UpdateProgress"));
    });

    document.getElementById('h_w_PC_ctl02_checkQuotaDaRaggiungere').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_checkQuotaDaRaggiungere'));
    }

    document.getElementById('h_w_PC_ctl02_reqVincita').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_reqVincita'));
    }

    document.getElementById('h_w_PC_ctl02_cmpVincita').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_cmpVincita'));
    }

    document.getElementById('h_w_PC_ctl02_reqGiocata').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_reqGiocata'));
    }

    document.getElementById('h_w_PC_ctl02_cmpGiocata').dispose = function() {
        Array.remove(Page_Validators, document.getElementById('h_w_PC_ctl02_cmpGiocata'));
    }
    Sys.Application.add_init(function() {
        $create(Sys.UI._Timer, {"enabled":false,"interval":60000,"uniqueID":"h$w$PC$ctl10$tmrUpdateLive"}, null, null, $get("h_w_PC_ctl10_tmrUpdateLive"));
    });
    //]]>
</script>



<script type="text/javascript" src="http://planetwins365.tk/livechat/php/app.php?widget-init.js"></script>

<style>
img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {
    display: none;
}
</style>
</body>
</html>
