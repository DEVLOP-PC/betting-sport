<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:../login.php");
}

require_once('../db_connect.php');

$identificateur = $_SESSION['pw_logged_user'];

$gid = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
$row = mysqli_fetch_assoc($gid);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="h_w_h"><title>
        planetwin365
    </title><link rel="SHORTCUT ICON" href="http://planetwin365.com/App_Themes/PlanetWin365/Images/Icons/favicon.ico" type="text/css"></link><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/layout.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/calendar.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/coupon.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/download_card.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/quote.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/WebRadio.css" />



    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

    <script src="http://ww3.365planetwinall.net/Scripts/Flash.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Coupon.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Common.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/ClickBet.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/odds.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cookie.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.scrollable.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cycle.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.scrollTo-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.serialScroll-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.innerfade.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jcarousellite_1.0.1.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/swfobject.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Session.js" type="text/javascript"></script>




    <script language="javascript" type="text/javascript">
        // variabili specifihe per bookmaker
        var divCouponTopPosition = 0; //Posizione top del coupon, se <=0 disabilita scroll
        var heightFooter = 206 //Altezza footer per far in modo che il coupon non ci vada sopra
        var hideAgentSummary = 1; //1 nasconde inizialmente il riassunto nella defaultlogged
        var themeUrl = 'http://static.planetwin365.com/App_Themes/PlanetWin365/';
        var TVClientID = null;
        var TVClientLimiteCampionati = null;
        var TVClientLimiteCampionatiErr = null;
        var sepDec = ',';
        var ExpandSubEvent = 1;
        var isAnonymous = 'True';
        var bestsellerQT = false;
        var qtaDeleted = false;

        function OpenLiveChat() {
        }

        function OpenWebRadio(url, widthDiv, heightDiv) {
        }

        function scrollToCoupon() {
            setTimeout(function(){
                $('html, body').animate({
                    scrollTop: $("#divCoupon").offset().top }, 250);
                setTimeout(function(){
                    $(".CItems").effect("pulsate", { times:1 }, 2000);
                }, 250);
            }, 250);
        }

        function pulsateCoupon() {
        }


        $(document).ready(function() {

            $("a").on('click', function(e) {
                if( $(this).hasClass( "active" ) ) { }
                else {
                    e.preventDefault;
                    return false;
                }
            });

        });
    </script>

    <script type="text/javascript">
        var sBtnUpdateSaldo = 'h_w_cLogin_btnSaldo';
    </script>

    <script>
        $( document ).ready(function() {
            var isInputSupported = 'placeholder' in document.createElement('input');
            var isTextareaSupported = 'placeholder' in document.createElement('textarea');
            if (!isInputSupported || !isTextareaSupported) {
                $('[placeholder]').focus(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                        input.val('');
                        input.removeClass('placeholder');
                    }
                }).blur(function () {
                    var input = $(this);
                    if (input.val() == '') {
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                        input.data('placeholder', true);
                    } else {
                        input.data('placeholder', false);
                    }
                }).blur().parents('form').submit(function () {
                    $(this).find('[placeholder]').each(function () {
                        var input = $(this);
                        if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                            input.val('');
                        }
                    })
                });
            }

        });
        function pageLoad() {
            if ($('.txtLogin').length>0) {
                $('input:not(.txtLogin), select').bind("focus", function () {
                    preventSavingCredentials();
                });
            }
        }
        function preventSavingCredentials() {
            document.getElementsByClassName('RegTxtPwd')[0].children[0].value = document.getElementById('inputPassword').value;
            document.getElementsByClassName('RegTxtPwd')[0].children[0].type = "text";
            document.getElementById('fakePasswordTxt').value = "";
            document.getElementById('inputPassword').value = "";
        }
    </script>
</head>
<body class="bodyMain Anonymous fr-FR">


<div>

    <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="15C4A0A3" />
</div>
<div style="position:absolute; top:0; left:0; width:5px; height:5px;" title='SRVM-WEB09'></div>


<script type="text/javascript">
    $('.bodyMain').css('background-image', 'url(../1/1.jpg)');


</script>






<div id="sessionEndWarning"> </div>
<div class="divMainHome">
    <!--HEADER-->
    <?php include("../header.php");?>
    <!--MAIN-->








    <div id="divMain">
        <div id="divContent">

            <table id="tblMainContent" cellpadding="0" cellspacing="0">
                <tbody><tr><td><div class="spacer5"></div></td></tr>
                <tr><td class="tdCNMaxAccount"><div id="MainContent">

                            <script language="javascript" type="text/javascript">
                                $(document).ready(function() {
                                    initializePopup("popupAnnullamentoClose", "popupAnnullamento", "backgroundPopup");
                                });

                                function showPopup(IDCoupon) {

                                    centerPopup("popupAnnullamento", "backgroundPopup");

                                    var PathIndi;
                                    PathIndi = 'BetRefuse.aspx'



                                    $("iframe[id=ifPopup]").attr("src",PathIndi + "?IDCoupon=" + IDCoupon) ;

                                    loadPopup("popupAnnullamento", "backgroundPopup");

                                }

                            </script>



                           <div id="MainContent">
                    
   <div class="Riquadro"><div class="TopSX"><div class="TopDX"><h3>Access Logs</h3></div></div><div class="CntSX"><div class="CntDX"><div id="s_w_PC_PC_panelSquare">
	
		<div class="RiquadroSrc"><div class="TopSX"><div class="TopDX"></div></div><div class="Cnt"><div>
		
		<div id="s_w_PC_PC_panForm" onkeypress="javascript:return WebForm_FireDefaultButton(event, 's_w_PC_PC_btnAvanti')">
			
		<div id="s_w_PC_PC_valSummary" class="ValidationSummary" style="color:Red;display:none;">

			</div>

		<div class="SearchTitleStyle">
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody><tr> 
					<td>Filtres</td>
					<td class="SearchMinimizeStyle">
						<a href="javascript:ShowHideSearch('tblSearch', 's_w_PC_PC_imgHide', 's_w_PC_PC_imgShow');"><img id="s_w_PC_PC_imgHide" src="../App_Themes/PlanetWin365/Images/Icons/Minimizza_ico.png" style="border-width:0px;"><img id="s_w_PC_PC_imgShow" src="../App_Themes/PlanetWin365/Images/Icons/Ingrandire_ico.png" style="border-width:0px;display:none;"></a>
					</td>
				</tr>
			</tbody></table>           
		</div>
		<table id="tblSearch" class="SearchContainerStyle">
			<tbody><tr class="SearchSectionStyle">
				<td class="SearchDescStyle">
					Date de l'événememt
				</td>
				<td class="SearchControlsStyle">
					<table>
						<tbody><tr>
							<td width="20%" align="right">
								De
							</td>
							<td>      
								

<table cellpadding="0" cellspacing="0">
    <tbody><tr>
        <td>
            <input name="s$w$PC$PC$cpopDal$txtDate" type="text" value="05/03/2018" id="s_w_PC_PC_cpopDal_txtDate" class="textbox" style="width:75px;">
        </td>
        <td width="25px" align="center">
            <img id="s_w_PC_PC_cpopDal_imgCalendar" src="//static.planetwin365.com/App_Themes/PlanetWin365/Images/Buttons/Calendar.gif" alt="Voir calendrier" style="border-width:0px;cursor:pointer;">
        </td>
        <td>
            <span id="s_w_PC_PC_cpopDal_cmpDate" style="color:Red;display:none;">Le format de la date de début n'est pas valable </span>
            <span id="s_w_PC_PC_cpopDal_reqDate" class="validation-error" style="color:Red;display:none;">Insérer une date de début</span>

                <div id="s_w_PC_PC_cpopDal_pnlCalendar" class="popupControl" style="display: none; position: absolute;">
				
                    
                
                    <div id="s_w_PC_PC_cpopDal_UpdatePanel1">
					
                                
                                <table class="CalendarExternalTableStyle">
                                    <tbody><tr>
                                        <td align="left" style="padding:5px;width:30px">
                                            <a id="s_w_PC_PC_cpopDal_btnDecrYear" class="CalendarLinkButStyleW" href="javascript:__doPostBack('s$w$PC$PC$cpopDal$btnDecrYear','')">-</a>&nbsp;
                                        </td>
                                        <td align="center">
                                            <span id="s_w_PC_PC_cpopDal_lbYear">2018</span>
                                        </td>
                                        <td align="right" style="padding:5px;width:30px">
                                            &nbsp;<a id="s_w_PC_PC_cpopDal_btnAddYear" class="CalendarLinkButStyleW" href="javascript:__doPostBack('s$w$PC$PC$cpopDal$btnAddYear','')">+</a>
                                        </td>
                                    </tr>
                                    <tr><td colspan="3">
                                        <table id="s_w_PC_PC_cpopDal_cldSelectDate" class="CalendarStyle" cellspacing="0" cellpadding="2" title="Calendar" border="0" style="border-width:1px;border-style:solid;width:160px;border-collapse:collapse;">
						<tbody><tr><td colspan="7" style="background-color:Silver;"><table class="CalendarTitleStyle" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
							<tbody><tr><td class="CalendarNextPrevStyle" style="width:15%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','V6606')" style="color:Black" title="Go to the previous month">&lt;</a></td><td align="center" style="width:70%;">mars</td><td class="CalendarNextPrevStyle" align="right" style="width:15%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','V6665')" style="color:Black" title="Go to the next month">&gt;</a></td></tr>
						</tbody></table></td></tr><tr><th class="CalendarDayHeaderStyle" align="center" abbr="lundi" scope="col">lu</th><th class="CalendarDayHeaderStyle" align="center" abbr="mardi" scope="col">ma</th><th class="CalendarDayHeaderStyle" align="center" abbr="mercredi" scope="col">me</th><th class="CalendarDayHeaderStyle" align="center" abbr="jeudi" scope="col">je</th><th class="CalendarDayHeaderStyle" align="center" abbr="vendredi" scope="col">ve</th><th class="CalendarDayHeaderStyle" align="center" abbr="samedi" scope="col">sa</th><th class="CalendarDayHeaderStyle" align="center" abbr="dimanche" scope="col">di</th></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6631')" style="color:Gray" title="26 février">26</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6632')" style="color:Gray" title="27 février">27</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6633')" style="color:Gray" title="28 février">28</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6634')" style="color:Black" title="1 mars">1</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6635')" style="color:Black" title="2 mars">2</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6636')" style="color:Black" title="3 mars">3</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6637')" style="color:Black" title="4 mars">4</a></td></tr><tr><td align="center" style="color:Black;background-color:#D2F1F8;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6638')" style="color:Black" title="5 mars">5</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6639')" style="color:Black" title="6 mars">6</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6640')" style="color:Black" title="7 mars">7</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6641')" style="color:Black" title="8 mars">8</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6642')" style="color:Black" title="9 mars">9</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6643')" style="color:Black" title="10 mars">10</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6644')" style="color:Black" title="11 mars">11</a></td></tr><tr><td class="CalendarTodayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6645')" style="color:Black" title="12 mars">12</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6646')" style="color:Black" title="13 mars">13</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6647')" style="color:Black" title="14 mars">14</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6648')" style="color:Black" title="15 mars">15</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6649')" style="color:Black" title="16 mars">16</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6650')" style="color:Black" title="17 mars">17</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6651')" style="color:Black" title="18 mars">18</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6652')" style="color:Black" title="19 mars">19</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6653')" style="color:Black" title="20 mars">20</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6654')" style="color:Black" title="21 mars">21</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6655')" style="color:Black" title="22 mars">22</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6656')" style="color:Black" title="23 mars">23</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6657')" style="color:Black" title="24 mars">24</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6658')" style="color:Black" title="25 mars">25</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6659')" style="color:Black" title="26 mars">26</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6660')" style="color:Black" title="27 mars">27</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6661')" style="color:Black" title="28 mars">28</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6662')" style="color:Black" title="29 mars">29</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6663')" style="color:Black" title="30 mars">30</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6664')" style="color:Black" title="31 mars">31</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6665')" style="color:Gray" title="1 avril">1</a></td></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6666')" style="color:Gray" title="2 avril">2</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6667')" style="color:Gray" title="3 avril">3</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6668')" style="color:Gray" title="4 avril">4</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6669')" style="color:Gray" title="5 avril">5</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6670')" style="color:Gray" title="6 avril">6</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6671')" style="color:Gray" title="7 avril">7</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopDal$cldSelectDate','6672')" style="color:Gray" title="8 avril">8</a></td></tr>
					</tbody></table>
                                    </td>
                                    </tr>
                                </tbody></table>
                        
				</div> 
                
			</div> 
        </td>
        
    </tr>
</tbody></table>

    

							</td>
							<td width="20%" align="right">
								A
							</td>
							<td width="30%" align="left">
								

<table cellpadding="0" cellspacing="0">
    <tbody><tr>
        <td>
            <input name="s$w$PC$PC$cpopAl$txtDate" type="text" value="12/03/2018" id="s_w_PC_PC_cpopAl_txtDate" class="textbox" style="width:75px;">
        </td>
        <td width="25px" align="center">
            <img id="s_w_PC_PC_cpopAl_imgCalendar" src="//static.planetwin365.com/App_Themes/PlanetWin365/Images/Buttons/Calendar.gif" alt="Voir calendrier" style="border-width:0px;cursor:pointer;">
        </td>
        <td>
            <span id="s_w_PC_PC_cpopAl_cmpDate" style="color:Red;display:none;">Le format de la date de fin n'est pas valable</span>
            <span id="s_w_PC_PC_cpopAl_reqDate" class="validation-error" style="color:Red;display:none;">Insérer une date de fin période</span>

                <div id="s_w_PC_PC_cpopAl_pnlCalendar" class="popupControl" style="display: none; position: absolute;">
				
                    
                
                    <div id="s_w_PC_PC_cpopAl_UpdatePanel1">
					
                                
                                <table class="CalendarExternalTableStyle">
                                    <tbody><tr>
                                        <td align="left" style="padding:5px;width:30px">
                                            <a id="s_w_PC_PC_cpopAl_btnDecrYear" class="CalendarLinkButStyleW" href="javascript:__doPostBack('s$w$PC$PC$cpopAl$btnDecrYear','')">-</a>&nbsp;
                                        </td>
                                        <td align="center">
                                            <span id="s_w_PC_PC_cpopAl_lbYear">2018</span>
                                        </td>
                                        <td align="right" style="padding:5px;width:30px">
                                            &nbsp;<a id="s_w_PC_PC_cpopAl_btnAddYear" class="CalendarLinkButStyleW" href="javascript:__doPostBack('s$w$PC$PC$cpopAl$btnAddYear','')">+</a>
                                        </td>
                                    </tr>
                                    <tr><td colspan="3">
                                        <table id="s_w_PC_PC_cpopAl_cldSelectDate" class="CalendarStyle" cellspacing="0" cellpadding="2" title="Calendar" border="0" style="border-width:1px;border-style:solid;width:160px;border-collapse:collapse;">
						<tbody><tr><td colspan="7" style="background-color:Silver;"><table class="CalendarTitleStyle" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
							<tbody><tr><td class="CalendarNextPrevStyle" style="width:15%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','V6606')" style="color:Black" title="Go to the previous month">&lt;</a></td><td align="center" style="width:70%;">mars</td><td class="CalendarNextPrevStyle" align="right" style="width:15%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','V6665')" style="color:Black" title="Go to the next month">&gt;</a></td></tr>
						</tbody></table></td></tr><tr><th class="CalendarDayHeaderStyle" align="center" abbr="lundi" scope="col">lu</th><th class="CalendarDayHeaderStyle" align="center" abbr="mardi" scope="col">ma</th><th class="CalendarDayHeaderStyle" align="center" abbr="mercredi" scope="col">me</th><th class="CalendarDayHeaderStyle" align="center" abbr="jeudi" scope="col">je</th><th class="CalendarDayHeaderStyle" align="center" abbr="vendredi" scope="col">ve</th><th class="CalendarDayHeaderStyle" align="center" abbr="samedi" scope="col">sa</th><th class="CalendarDayHeaderStyle" align="center" abbr="dimanche" scope="col">di</th></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6631')" style="color:Gray" title="26 février">26</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6632')" style="color:Gray" title="27 février">27</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6633')" style="color:Gray" title="28 février">28</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6634')" style="color:Black" title="1 mars">1</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6635')" style="color:Black" title="2 mars">2</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6636')" style="color:Black" title="3 mars">3</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6637')" style="color:Black" title="4 mars">4</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6638')" style="color:Black" title="5 mars">5</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6639')" style="color:Black" title="6 mars">6</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6640')" style="color:Black" title="7 mars">7</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6641')" style="color:Black" title="8 mars">8</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6642')" style="color:Black" title="9 mars">9</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6643')" style="color:Black" title="10 mars">10</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6644')" style="color:Black" title="11 mars">11</a></td></tr><tr><td class="CalendarTodayStyle" align="center" style="color:Black;background-color:#D2F1F8;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6645')" style="color:Black" title="12 mars">12</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6646')" style="color:Black" title="13 mars">13</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6647')" style="color:Black" title="14 mars">14</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6648')" style="color:Black" title="15 mars">15</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6649')" style="color:Black" title="16 mars">16</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6650')" style="color:Black" title="17 mars">17</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6651')" style="color:Black" title="18 mars">18</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6652')" style="color:Black" title="19 mars">19</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6653')" style="color:Black" title="20 mars">20</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6654')" style="color:Black" title="21 mars">21</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6655')" style="color:Black" title="22 mars">22</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6656')" style="color:Black" title="23 mars">23</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6657')" style="color:Black" title="24 mars">24</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6658')" style="color:Black" title="25 mars">25</a></td></tr><tr><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6659')" style="color:Black" title="26 mars">26</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6660')" style="color:Black" title="27 mars">27</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6661')" style="color:Black" title="28 mars">28</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6662')" style="color:Black" title="29 mars">29</a></td><td align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6663')" style="color:Black" title="30 mars">30</a></td><td class="CalendarWeekendDayStyle" align="center" style="width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6664')" style="color:Black" title="31 mars">31</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6665')" style="color:Gray" title="1 avril">1</a></td></tr><tr><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6666')" style="color:Gray" title="2 avril">2</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6667')" style="color:Gray" title="3 avril">3</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6668')" style="color:Gray" title="4 avril">4</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6669')" style="color:Gray" title="5 avril">5</a></td><td align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6670')" style="color:Gray" title="6 avril">6</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6671')" style="color:Gray" title="7 avril">7</a></td><td class="CalendarWeekendDayStyle" align="center" style="color:Gray;width:14%;"><a href="javascript:__doPostBack('s$w$PC$PC$cpopAl$cldSelectDate','6672')" style="color:Gray" title="8 avril">8</a></td></tr>
					</tbody></table>
                                    </td>
                                    </tr>
                                </tbody></table>
                        
				</div> 
                
			</div> 
        </td>
        
    </tr>
</tbody></table>

    

							</td>
						</tr>
					</tbody></table>
				</td>
			</tr>
			
		</tbody></table>
   
		<table class="SearchButtonsStyle">
			<tbody><tr>
			   <td></td>
			   <td class="tdSrcSX">
				   <input type="submit" name="s$w$PC$PC$btnCancella" value="Annuler" id="s_w_PC_PC_btnCancella" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')">
				</td>
				<td class="tdSrcDX">
					<input type="submit" name="s$w$PC$PC$btnAvanti" value="Continuer" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;s$w$PC$PC$btnAvanti&quot;, &quot;&quot;, true, &quot;ricerca&quot;, &quot;&quot;, false, false))" id="s_w_PC_PC_btnAvanti" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')">
				</td>
			</tr>   
		</tbody></table>
		
		</div>
		
	</div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>
		<div class="divDg">
		<div>
		<table class="dgStyle" cellspacing="0" border="0" id="s_w_PC_PC_grid" style="border-width:0px;border-style:None;width:100%;border-collapse:collapse;">
			<tbody><tr class="dgHdrStyle">
				<th scope="col"><a href="javascript:__doPostBack('s$w$PC$PC$grid','Sort$IDAccesso')">ID</a></th><th scope="col">Date</th><th scope="col"><a href="javascript:__doPostBack('s$w$PC$PC$grid','Sort$TipoAccesso')">Type log</a></th><th scope="col"><a href="javascript:__doPostBack('s$w$PC$PC$grid','Sort$IndirizzoIP')">Adresse IP</a></th>
			</tr><tr class="dgItemStyle">
				<td align="center">691354776</td><td align="center">
							<span id="s_w_PC_PC_grid_ctl02_lblData">08/03/2018 17:14:54</span>
						</td><td align="center">LogIn</td><td align="center">102.158.144.225</td>
			</tr><tr class="dgAItemStyle">
				<td align="center">691358153</td><td align="center">
							<span id="s_w_PC_PC_grid_ctl03_lblData">08/03/2018 17:27:16</span>
						</td><td align="center">LogIn</td><td align="center">197.1.145.233  </td>
			</tr><tr class="dgItemStyle">
				<td align="center">691382466</td><td align="center">
							<span id="s_w_PC_PC_grid_ctl04_lblData">08/03/2018 18:38:46</span>
						</td><td align="center">LogOut</td><td align="center">197.1.145.233  </td>
			</tr><tr class="dgAItemStyle">
				<td align="center">692266845</td><td align="center">
							<span id="s_w_PC_PC_grid_ctl05_lblData">11/03/2018 15:20:57</span>
						</td><td align="center">LogIn</td><td align="center">41.226.140.117 </td>
			</tr><tr class="dgItemStyle">
				<td align="center">692616551</td><td align="center">
							<span id="s_w_PC_PC_grid_ctl06_lblData">12/03/2018 18:13:57</span>
						</td><td align="center">LogIn</td><td align="center">102.148.87.25  </td>
			</tr>
		</tbody></table>
	</div>
		</div> 
		  
   
</div></div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>


                </div>
</body>
</html>
