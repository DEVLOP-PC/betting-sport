<?php
echo "TheCracker";
?>




	
<html>
<head>
<title>TheCracker</title>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
<body bgcolor="black" background="http://im42.gulfup.com/hiPE1.gif" oncontextmenu="return true;" onkeydown="return true;" onmousedown="return true;" onselectstart="return true" ondragstart="return true">
<h3 align="center" class="style2">

<style>
/* CSS reset
 */body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,p,blockquote,th,td{margin:0;padding:0}
html,body{margin:0;padding:0;font-family: 'Black Ops One', cursive;}
table{border-collapse:collapse;border-spacing:0}
fieldset,img{border:0}
input{border:1px solid #b0b0b0;padding:3px 5px 4px;color:#979797;width:190px}
address,caption,cite,code,dfn,th,var{font-style:normal;font-weight:normal}
ol,ul{list-style:none}
caption,th{text-align:left}
h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal}
q:before,q:after{content:''}
abbr,acronym{border:0}
#unknown h2{position:absolute;top:50%;line-height:100px;height:100px;margin-top:-50px;font-size:100px;width:100%;text-align:center;color:transparent;-webkit-animation:blurFadeInOut 3s ease-in backwards;-moz-animation:blurFadeInOut 3s ease-in backwards;-ms-animation:blurFadeInOut 3s ease-in backwards;animation:blurFadeInOut 3s ease-in backwards}
#unknown h2.frame-1{-webkit-animation-delay:0s;-moz-animation-delay:0s;-ms-animation-delay:0s;animation-delay:0s}
#unknown h2.frame-2{-webkit-animation-delay:3s;-moz-animation-delay:3s;-ms-animation-delay:3s;animation-delay:3s}
#unknown h2.frame-3{-webkit-animation-delay:6s;-moz-animation-delay:6s;-ms-animation-delay:6s;animation-delay:6s}
#unknown h2.frame-4{font-size:200px;-webkit-animation-delay:9s;-moz-animation-delay:9s;-ms-animation-delay:9s;animation-delay:9s}
#unknown h2.frame-5{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none;color:transparent;text-shadow:0px 0px 1px #fff:margin-top:30px;}
#unknown h2.frame-5 span{-webkit-animation:blurFadeIn 3s ease-in 12s backwards;-moz-animation:blurFadeIn 1s ease-in 12s backwards;-ms-animation:blurFadeIn 3s ease-in 12s backwards;animation:blurFadeIn 3s ease-in 12s backwards;color:transparent;text-shadow:0px 0px 1px #fff}
#unknown h2.frame-5 span:nth-child(2){-webkit-animation-delay:13s;-moz-animation-delay:13s;-ms-animation-delay:13s;animation-delay:13s}
#unknown h2.frame-5 span:nth-child(3){-webkit-animation-delay:14s;-moz-animation-delay:14s;-ms-animation-delay:14s;animation-delay:14s}
#unknown h2.frame-5 span:nth-child(4){-webkit-animation-delay:15s;-moz-animation-delay:15s;-ms-animation-delay:15s;animation-delay:15s}
#unknown h2.frame-5 span:nth-child(5){-webkit-animation-delay:16s;-moz-animation-delay:16s;-ms-animation-delay:16s;animation-delay:16s}
#unknown h2.frame-6 span{-webkit-animation:blurFadeIn 3s ease-in 12s backwards;-moz-animation:blurFadeIn 1s ease-in 19s backwards;-ms-animation:blurFadeIn 3s ease-in 19s backwards;animation:blurFadeIn 3s ease-in 19s backwards;color:#FF0B0A;text-shadow:0px 0px 2px #fff;margin-top:500px;line-height:50px;}
#unknown h2.frame-6 span:nth-child(2){-webkit-animation-delay:20s;-moz-animation-delay:20s;-ms-animation-delay:20s;animation-delay:20s;font-size:20px;color:#FFF;}
#unknown h2.frame-6 span:nth-child(3){-webkit-animation-delay:20s;-moz-animation-delay:20s;-ms-animation-delay:20s;animation-delay:20s;}
#unknown h2.frame-6 span:nth-child(4){-webkit-animation-delay:20s;-moz-animation-delay:20s;-ms-animation-delay:20s;animation-delay:20s;}
#unknown h2.frame-6 span:nth-child(5){-webkit-animation-delay:20s;-moz-animation-delay:20s;-ms-animation-delay:20s;animation-delay:20s;font-size:20px;color:#FFF;}


.unknown1{position:absolute;width:282px;height:273px;left:50%;top:50%;margin:0;background:none;-webkit-animation:fadeInBack 3.6s linear 14s backwards;-moz-animation:fadeInBack 3.6s linear 14s backwards;-ms-animation:fadeInBack 3.6s linear 14s backwards;animation:fadeInBack 3.6s linear 14s backwards;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";filter:alpha(opacity=30);opacity:0.3;-webkit-transform:scale(2);-moz-transform:scale(2);-o-transform:scale(2);-ms-transform:scale(2);transform:scale(2)}
.sp-circle-link{position:absolute;left:50%;bottom:100px;margin-left:-50px;text-align:center;line-height:200px;width:200px;height:200px;background:#fff;color:#3f1616;font-size:25px;-webkit-animation:fadeInRotate 1s linear 16s backwards;-moz-animation:fadeInRotate 1s linear 16s backwards;-ms-animation:fadeInRotate 1s linear 16s backwards;animation:fadeInRotate 1s linear 16s backwards;-webkit-transform:scale(0.8) rotate(0deg);-moz-transform:scale(0.8) rotate(0deg);-o-transform:scale(0.8) rotate(0deg);-ms-transform:scale(0.8) rotate(0deg);transform:scale(0.8) rotate(0deg)}
.sp-circle-link:hover{background:#85373b;color:#fff}
/**/@-webkit-keyframes blurFadeInOut{0%{opacity:0;text-shadow:0px 0px 40px #fff;-webkit-transform:scale(1.3)}
20%,75%{opacity:1;text-shadow:0px 0px 1px #fff;-webkit-transform:scale(1)}
100%{opacity:0;text-shadow:0px 0px 50px #fff;-webkit-transform:scale(0)}
}
@-webkit-keyframes blurFadeIn{0%{opacity:0;text-shadow:0px 0px 40px #fff;-webkit-transform:scale(1.3)}
50%{opacity:0.5;text-shadow:0px 0px 10px #fff;-webkit-transform:scale(1.1)}
100%{opacity:1;text-shadow:0px 0px 1px #fff;-webkit-transform:scale(1)}
}
@-webkit-keyframes fadeInBack{0%{opacity:0;-webkit-transform:scale(0)}
50%{opacity:0.4;-webkit-transform:scale(1)}
100%{opacity:0.2;-webkit-transform:scale(2)}
}
@-webkit-keyframes fadeInRotate{0%{opacity:0;-webkit-transform:scale(0) rotate(360deg)}
100%{opacity:1;-webkit-transform:scale(1) rotate(0deg)}
}
/**/@-moz-keyframes blurFadeInOut{0%{opacity:0;text-shadow:0px 0px 40px #fff;-moz-transform:scale(1.3)}
20%,75%{opacity:1;text-shadow:0px 0px 1px #fff;-moz-transform:scale(1)}
100%{opacity:0;text-shadow:0px 0px 50px #fff;-moz-transform:scale(0)}
}
@-moz-keyframes blurFadeIn{0%{opacity:0;text-shadow:0px 0px 40px #fff;-moz-transform:scale(1.3)}
100%{opacity:1;text-shadow:0px 0px 1px #fff;-moz-transform:scale(1)}
}
@-moz-keyframes fadeInBack{0%{opacity:0;-moz-transform:scale(0)}
50%{opacity:0.4;-moz-transform:scale(1)}
100%{opacity:0.2;-moz-transform:scale(2)}
}
@-moz-keyframes fadeInRotate{0%{opacity:0;-moz-transform:scale(0) rotate(360deg)}
100%{opacity:1;-moz-transform:scale(1) rotate(0deg)}
}
/**/@keyframes blurFadeInOut{0%{opacity:0;text-shadow:0px 0px 40px #fff;transform:scale(1.3)}
20%,75%{opacity:1;text-shadow:0px 0px 1px #fff;transform:scale(1)}
100%{opacity:0;text-shadow:0px 0px 50px #fff;transform:scale(0)}
}
@keyframes blurFadeIn{0%{opacity:0;text-shadow:0px 0px 40px #fff;transform:scale(1.3)}
50%{opacity:0.5;text-shadow:0px 0px 10px #fff;transform:scale(1.1)}
55
100%{opacity:1;text-shadow:0px 0px 1px #fff;-webkit-transform:scale(1)}
56
}
57
@-webkit-keyframes fadeInBack{0%{opacity:0;-webkit-transform:scale(0)}
58
50%{opacity:0.4;-webkit-transform:scale(1)}
59
100%{opacity:0.2;-webkit-transform:scale(2)}
60
}
61
@-webkit-keyframes fadeInRotate{0%{opacity:0;-webkit-transform:scale(0) rotate(360deg)}
62
100%{opacity:1;-webkit-transform:scale(1) rotate(0deg)}
63
}
64
/**/@-moz-keyframes blurFadeInOut{0%{opacity:0;text-shadow:0px 0px 40px #fff;-moz-transform:scale(1.3)}
65
20%,75%{opacity:1;text-shadow:0px 0px 1px #fff;-moz-transform:scale(1)}
66
100%{opacity:0;text-shadow:0px 0px 50px #fff;-moz-transform:scale(0)}
67
}
68
@-moz-keyframes blurFadeIn{0%{opacity:0;text-shadow:0px 0px 40px #fff;-moz-transform:scale(1.3)}
69
100%{opacity:1;text-shadow:0px 0px 1px #fff;-moz-transform:scale(1)}
70
}
71
@-moz-keyframes fadeInBack{0%{opacity:0;-moz-transform:scale(0)}
72
50%{opacity:0.4;-moz-transform:scale(1)}
73
100%{opacity:0.2;-moz-transform:scale(2)}
74
}
75
@-moz-keyframes fadeInRotate{0%{opacity:0;-moz-transform:scale(0) rotate(360deg)}
76
100%{opacity:1;-moz-transform:scale(1) rotate(0deg)}
77
}
78
/**/@keyframes blurFadeInOut{0%{opacity:0;text-shadow:0px 0px 40px #fff;transform:scale(1.3)}
79
20%,75%{opacity:1;text-shadow:0px 0px 1px #fff;transform:scale(1)}
80
100%{opacity:0;text-shadow:0px 0px 50px #fff;transform:scale(0)}
81
}
82
@keyframes blurFadeIn{0%{opacity:0;text-shadow:0px 0px 40px #fff;transform:scale(1.3)}
83
50%{opacity:0.5;text-shadow:0px 0px 10px #fff;transform:scale(1.1)}
84
100%{opacity:1;text-shadow:0px 0px 1px #fff;transform:scale(1)}
100%{opacity:1;text-shadow:0px 0px 1px #fff;transform:scale(1)}
}
@keyframes fadeInBack{0%{opacity:0;transform:scale(0)}
50%{opacity:0.4;transform:scale(1)}
100%{opacity:0.2;transform:scale(2)}
}
@keyframes fadeInRotate{0%{opacity:0;transform:scale(0) rotate(360deg)}
100%{opacity:1;transform:scale(1) rotate(0deg)}
}
</style>
         <div class="container">
<div id='unknown'>

 <div class="unknown">
  <div class="unknown1">&nbsp;</div>
  <h2 class="frame-1">Offcial</h2>
  <h2 class="frame-2">PlanetWin365</h2>
  <h2 class="frame-3"> #Cracker</h2>
  <h2 class="frame-5"><span>Planet</span> <span>Win</span> <span>Virtuel</span><br/><span>By</span></h2>
  <h2 class="frame-6"><br/><br/><span lang="en-us"> <br><br>RHA-TheCracker</br></br> </span><br/><span> # </span></h2>
  
  
 </div>

 </div>
</div>


</script>
