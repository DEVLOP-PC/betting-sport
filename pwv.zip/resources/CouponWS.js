Type.registerNamespace('ISBets.WebPages.Controls');
ISBets.WebPages.Controls.CouponWS=function() {
ISBets.WebPages.Controls.CouponWS.initializeBase(this);
this._timeout = 0;
this._userContext = null;
this._succeeded = null;
this._failed = null;
}
ISBets.WebPages.Controls.CouponWS.prototype={
_get_path:function() {
 var p = this.get_path();
 if (p) return p;
 else return ISBets.WebPages.Controls.CouponWS._staticInstance.get_path();},
GetSaldo:function(IDUtente,succeededCallback, failedCallback, userContext) {
return this._invoke(this._get_path(), 'GetSaldo',true,{IDUtente:IDUtente},succeededCallback,failedCallback,userContext); },
GetDisbilitazioneGiroconti:function(IDUtente,succeededCallback, failedCallback, userContext) {
return this._invoke(this._get_path(), 'GetDisbilitazioneGiroconti',true,{IDUtente:IDUtente},succeededCallback,failedCallback,userContext); },
GetStatoCoupon:function(IDCoupon,succeededCallback, failedCallback, userContext) {
return this._invoke(this._get_path(), 'GetStatoCoupon',true,{IDCoupon:IDCoupon},succeededCallback,failedCallback,userContext); },
CouponPromozioneOK:function(IDCoupon,succeededCallback, failedCallback, userContext) {
return this._invoke(this._get_path(), 'CouponPromozioneOK',false,{IDCoupon:IDCoupon},succeededCallback,failedCallback,userContext); },
GetStatoCouponAsincrono:function(IDCouponAsincrono,succeededCallback, failedCallback, userContext) {
return this._invoke(this._get_path(), 'GetStatoCouponAsincrono',true,{IDCouponAsincrono:IDCouponAsincrono},succeededCallback,failedCallback,userContext); }}
ISBets.WebPages.Controls.CouponWS.registerClass('ISBets.WebPages.Controls.CouponWS',Sys.Net.WebServiceProxy);
ISBets.WebPages.Controls.CouponWS._staticInstance = new ISBets.WebPages.Controls.CouponWS();
ISBets.WebPages.Controls.CouponWS.set_path = function(value) { ISBets.WebPages.Controls.CouponWS._staticInstance.set_path(value); }
ISBets.WebPages.Controls.CouponWS.get_path = function() { return ISBets.WebPages.Controls.CouponWS._staticInstance.get_path(); }
ISBets.WebPages.Controls.CouponWS.set_timeout = function(value) { ISBets.WebPages.Controls.CouponWS._staticInstance.set_timeout(value); }
ISBets.WebPages.Controls.CouponWS.get_timeout = function() { return ISBets.WebPages.Controls.CouponWS._staticInstance.get_timeout(); }
ISBets.WebPages.Controls.CouponWS.set_defaultUserContext = function(value) { ISBets.WebPages.Controls.CouponWS._staticInstance.set_defaultUserContext(value); }
ISBets.WebPages.Controls.CouponWS.get_defaultUserContext = function() { return ISBets.WebPages.Controls.CouponWS._staticInstance.get_defaultUserContext(); }
ISBets.WebPages.Controls.CouponWS.set_defaultSucceededCallback = function(value) { ISBets.WebPages.Controls.CouponWS._staticInstance.set_defaultSucceededCallback(value); }
ISBets.WebPages.Controls.CouponWS.get_defaultSucceededCallback = function() { return ISBets.WebPages.Controls.CouponWS._staticInstance.get_defaultSucceededCallback(); }
ISBets.WebPages.Controls.CouponWS.set_defaultFailedCallback = function(value) { ISBets.WebPages.Controls.CouponWS._staticInstance.set_defaultFailedCallback(value); }
ISBets.WebPages.Controls.CouponWS.get_defaultFailedCallback = function() { return ISBets.WebPages.Controls.CouponWS._staticInstance.get_defaultFailedCallback(); }
ISBets.WebPages.Controls.CouponWS.set_path("/Controls/CouponWS.asmx");
ISBets.WebPages.Controls.CouponWS.GetSaldo= function(IDUtente,onSuccess,onFailed,userContext) {ISBets.WebPages.Controls.CouponWS._staticInstance.GetSaldo(IDUtente,onSuccess,onFailed,userContext); }
ISBets.WebPages.Controls.CouponWS.GetDisbilitazioneGiroconti= function(IDUtente,onSuccess,onFailed,userContext) {ISBets.WebPages.Controls.CouponWS._staticInstance.GetDisbilitazioneGiroconti(IDUtente,onSuccess,onFailed,userContext); }
ISBets.WebPages.Controls.CouponWS.GetStatoCoupon= function(IDCoupon,onSuccess,onFailed,userContext) {ISBets.WebPages.Controls.CouponWS._staticInstance.GetStatoCoupon(IDCoupon,onSuccess,onFailed,userContext); }
ISBets.WebPages.Controls.CouponWS.CouponPromozioneOK= function(IDCoupon,onSuccess,onFailed,userContext) {ISBets.WebPages.Controls.CouponWS._staticInstance.CouponPromozioneOK(IDCoupon,onSuccess,onFailed,userContext); }
ISBets.WebPages.Controls.CouponWS.GetStatoCouponAsincrono= function(IDCouponAsincrono,onSuccess,onFailed,userContext) {ISBets.WebPages.Controls.CouponWS._staticInstance.GetStatoCouponAsincrono(IDCouponAsincrono,onSuccess,onFailed,userContext); }
